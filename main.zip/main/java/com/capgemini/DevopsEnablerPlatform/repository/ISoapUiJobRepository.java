package com.capgemini.DevopsEnablerPlatform.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.SoapUiJobEntity;

public interface ISoapUiJobRepository extends PagingAndSortingRepository<SoapUiJobEntity, Integer> {

	
	@Query("SELECT j FROM SoapUiJobEntity j WHERE j.jobName=?")
	public List<SoapUiJobEntity> getDetailsByAppName(String appname);
	
	@Query("SELECT j.soapUiStatus FROM  SoapUiJobEntity j WHERE j.jobName=?")
	public String fetchjobstatus(String jobName);
}
