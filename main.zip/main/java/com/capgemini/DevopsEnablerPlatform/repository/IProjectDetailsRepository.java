
package com.capgemini.DevopsEnablerPlatform.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;


import com.capgemini.DevopsEnablerPlatform.reusable.entity.ProjectInformationEntity;

public interface IProjectDetailsRepository extends PagingAndSortingRepository<ProjectInformationEntity, Integer> {
	 @Query("select distinct j.accountName from ProjectInformationEntity j")
	  	public List<ProjectInformationEntity> fetchProjectInfo();
	 
	 @Query("select distinct j.subAccountName from ProjectInformationEntity j where j.accountName=?")
	  	public List<ProjectInformationEntity> fetchSubAccounts(String accountName);
	 
	 @Query("select j from ProjectInformationEntity j where j.subAccountName=?")
	  	public List<ProjectInformationEntity> fetchSubAccountDetails(Object object);
	 
	 @Query("select distinct j.projectId from ProjectInformationEntity j where j.subAccountName=?")
	  	public List<ProjectInformationEntity> fetchProjectId(Object object);
	 
	 @Query("select distinct j.applicationName from ProjectInformationEntity j where j.projectId=?")
	  	public List<ProjectInformationEntity> fetchApplicationName(Object object);
	 
	 @Query("select distinct j.projectName from ProjectInformationEntity j where j.subAccountName=?")
	  	public List<ProjectInformationEntity> fetchProjectName(Object object);
	 
	 @Query("select distinct j.releaseDate from ProjectInformationEntity j where j.applicationName=?")
	  	public List<ProjectInformationEntity> fetchReleaseDate(Object object);
	 
	 
	 @Query("select distinct j from ProjectInformationEntity j")
	  	public List<ProjectInformationEntity>fetchDistinctAccounts();
	 

	 
	 
	 @Query("select count(distinct j.applicationName) from ProjectInformationEntity j where j.accountName=?")
	  	public int fetchAppCount(Object accountName);
	 
	 @Query("select distinct j.accountName from ProjectInformationEntity j")
	  	public List<String> fetchProjectInfo1();
	 
	 @Query("select distinct j.webappsAndMicroservice from ProjectInformationEntity j where j.applicationName=?")
	  	public List<ProjectInformationEntity>fetchwebapps(Object object);

	 @Query("select distinct j.applicationName from ProjectInformationEntity j where j.subAccountName=?")
	  	public List<ProjectInformationEntity> fetchApplicationName1(Object object);

	 @Query("select distinct j.webappsAndMicroservice from ProjectInformationEntity j where j.applicationName=?1 and j.subAccountName=?2")
	public List<ProjectInformationEntity> fetchwebapps1(String applicationName, String subAccount);
	
	 @Query("select distinct j.projectId from ProjectInformationEntity j")
     public List<String> fetchProjectID();

@Query("select distinct j.applicationName from ProjectInformationEntity j where j.projectId=?1")
     public List<String> fetchAppByProjId(String projectId);
	
	
	 
	
}
