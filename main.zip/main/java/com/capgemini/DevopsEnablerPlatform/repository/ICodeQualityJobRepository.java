package com.capgemini.DevopsEnablerPlatform.repository;

import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.DevopsEnablerPlatform.reusable.entity.CodeQualityJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;



public interface ICodeQualityJobRepository extends PagingAndSortingRepository<CodeQualityJobEntity, Integer> {


	@Query("SELECT j FROM CodeQualityJobEntity j WHERE j.jobName=?")
	public List<CodeQualityJobEntity> getDetailsByAppName(String jobName);
	
	@Query("SELECT j FROM CodeQualityJobEntity j WHERE j.jobName=?")
	public CodeQualityJobEntity getDetailsByAppName1(String jobName);

	@Query("SELECT j.buildStatus FROM CodeQualityJobEntity j WHERE j.jobName=?")
	public String fetchjobstatus(String jobName);
	
	 @Query("SELECT j FROM CodeQualityJobEntity j WHERE j.jobName=?1")
	 public CodeQualityJobEntity ifappNameExists(String applicationName); 
	 
	 @Query("SELECT j.buildStatus FROM CodeQualityJobEntity j WHERE j.jobName=?1")
	 public String getBuildStatus(String jobName);
	 
	 
	  @Query("SELECT j.sonarAvgHealth FROM CodeQualityJobEntity j WHERE j.jobName=?1")
	  public double getSonarAvgHealth(String jobName);
	  
	  @Query("SELECT j.sonarAvgHealth FROM CodeQualityJobEntity j WHERE j.jobName=?1")
	  public String getSonarAvgHealth1(String jobName);

	  
	  
	
	
}
