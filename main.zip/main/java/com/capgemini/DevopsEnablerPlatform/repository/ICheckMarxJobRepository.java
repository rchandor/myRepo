package com.capgemini.DevopsEnablerPlatform.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.DevopsEnablerPlatform.reusable.entity.CheckMarxJobentity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.CodeQualityJobEntity;

@Repository
public interface ICheckMarxJobRepository extends PagingAndSortingRepository<CheckMarxJobentity, Integer >
{
	@Query("SELECT j FROM CheckMarxJobentity j WHERE j.jobName=?")
	public List<CheckMarxJobentity> getDetailsByAppName(String appname);
	
	
	@Query("SELECT j.buildStatus FROM  CheckMarxJobentity j WHERE j.jobName=?")
	public String fetchjobstatus(String jobName);
	
	 @Query("SELECT j.checkmarxBuildStatus FROM CheckMarxJobentity j WHERE j.jobName=?1")
	 public String getBuildStatus(String jobName);
}
