package com.capgemini.DevopsEnablerPlatform.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.PerformanceJobEntity;

public interface IPerformanceJobRepository extends PagingAndSortingRepository<PerformanceJobEntity, Integer>{

	@Query("SELECT j FROM PerformanceJobEntity j WHERE j.jobName=?")
	public List<PerformanceJobEntity> getDetailsByAppName(String appname);
	
	@Query("SELECT j.performanceBuildStatus FROM  PerformanceJobEntity j WHERE j.jobName=?")
	public String fetchjobstatus(String jobName);
	
	 @Query("SELECT j.performanceBuildStatus FROM PerformanceJobEntity j WHERE j.jobName=?1")
	 public String getBuildStatus(String jobName);
	 
	 @Query("SELECT j FROM PerformanceJobEntity j WHERE j.jobName=?")
		public PerformanceJobEntity getPerformanceDetails(String jobName);
	 
	 @Query("SELECT j.usedMemory FROM PerformanceJobEntity j WHERE j.applicationName=?")
		public String getPerformanceDetailsByAppName(String applicationName);
}
