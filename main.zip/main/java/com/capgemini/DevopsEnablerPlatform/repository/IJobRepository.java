package com.capgemini.DevopsEnablerPlatform.repository;
 
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
 
import com.capgemini.DevopsEnablerPlatform.dto.JobDTO;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.CodeQualityJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;
 
@Repository
public interface IJobRepository extends PagingAndSortingRepository<JobEntity, Long>
{
               
                @Query("SELECT j FROM JobEntity j")
                JobEntity getJobId(int jobId);
 
                @Query("SELECT j FROM JobEntity j ")
                JobEntity getApplicationName(int applicationName);
               
                @Query("SELECT j FROM JobEntity j ")
                JobEntity getProjectName(String projectName);
               
               
                /*String mainQuery = "Select e.jobId from JobEntity e where e.jobId=?1";
   @Query(mainQuery)
    JobEntity  getJobIddd(int mainQuery);*/
   
    @Query("SELECT j FROM JobEntity j WHERE j.jobId=?1")
    public JobEntity getJobEntity1(int jobId);
 
    @Query("select j.jobId from JobEntity j where j.jobId=?1")
                public long findByJobId(long jobId);
               
    @Query("select j.jobId, j.jobName, j.projectId, j.stage from JobEntity j order by j.jobId")
                public List<JobEntity> fetchusers();
 
    @Query("select j.jobId from JobEntity j where j.jobName=?1")
                public long findByAppName(String appName);
    
    
    @Query("select j.jobId from JobEntity j where j.applicationName=?")
  	public long getJobIdfor(String appName);

    @Query("select j.stage from JobEntity j where j.applicationName=?")
	public String getStage(String appName);
    
    @Query("SELECT j FROM JobEntity j WHERE j.jobName=?1")
	 public JobEntity findByAppName1(String applicationName); 
    
    @Query("SELECT j.jobId FROM JobEntity j WHERE j.jobName=?1")
	 public long fetchJobId(String jobname); 
    
    
    @Query("SELECT j.jobName FROM JobEntity j WHERE j.applicationName=?1")
	 public JSONArray getAllJobs(String applicationName); 
    
    
    @Query("SELECT j FROM JobEntity j WHERE j.jobName=?")
	public List<JobEntity> getDetailsByAppName(String jobName);
	
    
  
    
   
   
               
}