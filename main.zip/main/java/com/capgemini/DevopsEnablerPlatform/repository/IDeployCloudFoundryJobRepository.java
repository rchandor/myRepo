package com.capgemini.DevopsEnablerPlatform.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.DeployCloudFoundryJobEntity;

public interface IDeployCloudFoundryJobRepository extends PagingAndSortingRepository<DeployCloudFoundryJobEntity, Integer> {

	@Query("SELECT j FROM DeployCloudFoundryJobEntity j WHERE j.jobName=?")
	public List<DeployCloudFoundryJobEntity> getDetailsByAppName(String appname);
	
	@Query("SELECT j.deployBuildStatusCf FROM  DeployCloudFoundryJobEntity j WHERE j.jobName=?")
	public String fetchjobstatus(String jobName);
	
	
	 @Query("SELECT j.deployBuildStatusCf FROM DeployCloudFoundryJobEntity j WHERE j.jobName=?1")
	 public String getBuildStatus(String jobName);
}
