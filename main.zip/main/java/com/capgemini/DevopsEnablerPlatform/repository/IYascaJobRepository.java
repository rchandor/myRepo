package com.capgemini.DevopsEnablerPlatform.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.DevopsEnablerPlatform.reusable.entity.CodeQualityJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.YascaJobEntity;

public interface IYascaJobRepository extends PagingAndSortingRepository<YascaJobEntity, Integer> {

	@Query("SELECT j FROM YascaJobEntity j  WHERE j.jobName=?")
	public List<YascaJobEntity> getDetailsByAppName(String jobName);

	@Query("SELECT j.yascaBuildStatus FROM  YascaJobEntity j WHERE j.jobName=?")
	public String fetchjobstatus(String jobName);
	
	 @Query("SELECT j FROM YascaJobEntity j WHERE j.jobName=?1")
	 public YascaJobEntity ifappNameExists(String applicationName); 
	 
	 @Query("SELECT j.yascaBuildStatus FROM YascaJobEntity j WHERE j.jobName=?1")
	 public String getBuildStatus(String jobName);
	 
	 @Query("SELECT j FROM YascaJobEntity j  WHERE j.jobName=?")
		public YascaJobEntity getDetailsByAppName1(String appName);
	 
	 
	 @Query("SELECT j.yascaAvgHealth FROM YascaJobEntity j WHERE j.jobName=?1")
	  public String getYascaAvgHealth(String jobName);
	 
	 

}
