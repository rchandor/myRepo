package com.capgemini.DevopsEnablerPlatform.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.DevopsEnablerPlatform.reusable.entity.StageMasterEntity;

public interface IStageMasterRepository extends PagingAndSortingRepository<StageMasterEntity, String> {

	
}
