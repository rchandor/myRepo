package com.capgemini.DevopsEnablerPlatform.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.SahiJobEntity;

public interface ISahiJobRepository extends PagingAndSortingRepository<SahiJobEntity, Integer> {

	@Query("SELECT j FROM SahiJobEntity j WHERE j.jobName=?")
	public List<SahiJobEntity> getDetailsByAppName(String appname);
	
	@Query("SELECT j.sahiStatus FROM  SahiJobEntity j WHERE j.jobName=?")
	public String fetchjobstatus(String jobName);
}
