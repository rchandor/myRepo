package com.capgemini.DevopsEnablerPlatform.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.WorkflowMasterEntity;

public interface IWorkflowMasterRepository  extends PagingAndSortingRepository<WorkflowMasterEntity, Integer>{
	
	
	
	 
    @Query("SELECT j FROM WorkflowMasterEntity j WHERE j.workflowId=?1")
    public WorkflowMasterEntity getWorkflowProjectId(String work);
   
}
