package com.capgemini.DevopsEnablerPlatform.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.DevopsEnablerPlatform.reusable.entity.CodeQualityJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.RegressionJobEntity;

public interface IRegressionJobRepository extends PagingAndSortingRepository<RegressionJobEntity, Integer> {

	
	@Query("SELECT j FROM RegressionJobEntity j WHERE j.jobName=?")
	public List<RegressionJobEntity> getDetailsByAppName(String appname);
	
	@Query("SELECT j FROM RegressionJobEntity j WHERE j.jobName=?")
	public RegressionJobEntity getDetailsByAppName1(String jobName);
	
	@Query("SELECT j.regressionStatus FROM  RegressionJobEntity j WHERE j.jobName=?")
	public String fetchjobstatus(String jobName);
	
	@Query("SELECT j.regAvgHealth FROM RegressionJobEntity j WHERE j.jobName=?1")
	  public String getRegAvgHealth(String jobName);
}
