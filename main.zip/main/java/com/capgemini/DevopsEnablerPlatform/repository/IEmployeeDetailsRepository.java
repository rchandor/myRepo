package com.capgemini.DevopsEnablerPlatform.repository;

import org.springframework.data.repository.PagingAndSortingRepository;


import com.capgemini.DevopsEnablerPlatform.reusable.entity.EmployeeDetailsEntity;


public interface IEmployeeDetailsRepository extends PagingAndSortingRepository<EmployeeDetailsEntity, Integer>{

}
