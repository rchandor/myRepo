package com.capgemini.DevopsEnablerPlatform;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.DevopsEnablerPlatform.Ehcache.EhCache;
import com.capgemini.DevopsEnablerPlatform.dto.CodeQualityJobDTO;
import com.capgemini.DevopsEnablerPlatform.dto.MessageDTO;
import com.capgemini.DevopsEnablerPlatform.dto.YascaJobDTO;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.CheckMarxJobentity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.CodeQualityJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.DeployChefJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.DeployCloudFoundryJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.DeployJenkinsJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.PerformanceJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.ProjectInformationEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.RegressionJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.SahiJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.SoapUiJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.YascaJobEntity;
import com.capgemini.DevopsEnablerPlatform.service.IJobService;
import com.capgemini.DevopsEnablerPlatform.util.ImpersonateUtil;
import com.capgemini.DevopsEnablerPlatform.windowsSecurity.WindowsSecurity;

@RestController
@RequestMapping(value = "/kfcBrands")
public class DevopsController {

	@Autowired
	IJobService jobservice;

	@RequestMapping(value = "/createDevopsJob", method = RequestMethod.POST, produces = "application/json", consumes = "application/json", headers = "Accept=application/json")
	public MessageDTO createDevopsJob(@RequestBody JSONObject jsonObject) throws Exception {
		return jobservice.createJob(jsonObject);
	}

	@RequestMapping(value = "/buildDevopsJob", method = RequestMethod.POST, produces = "application/json", consumes = "application/json", headers = "Accept=application/json")

	public MessageDTO buildDevopsJob(@RequestBody JSONObject jsonObject) throws Exception {
		return jobservice.buildJob(jsonObject);
	}

	@RequestMapping(value = "/fetchjobs")
	public List<JobEntity> fetchjobs() throws SecurityException, IOException {

		// session.setAttribute("j_username", username);
		System.out.println("I am accepting :");
		return jobservice.fetchjobsofusers();
		// model.addAttribute("jsonObject", jsonObject);

	}

	// Fetching Details Of CodeQualityApplication
	@RequestMapping(value = "/fetchCodeQualityApplicationDetails")
	public List<CodeQualityJobEntity> fetchCodeQualityApplicationDetails(@RequestParam("jobName") String jobName)
			throws SecurityException, IOException {

		return jobservice.getCodeQualityApplicationDetails(jobName);
	}

	// Fetching Details Of fetchYascaApplicationDetails
	@RequestMapping(value = "/fetchYascaApplicationDetails")
	public List<YascaJobEntity> fetchYascaApplicationDetails(@RequestParam("jobName") String jobName)
			throws SecurityException, IOException {

		return jobservice.getYascaApplicationDetails(jobName);
	}

	// Fetching Details Of CodeQualityApplication
	@RequestMapping(value = "/fetchCQApplicationDetails")
	public List<CodeQualityJobEntity> fetchCQApplicationDetails(@RequestParam("applicationName") String jobName)
			throws SecurityException, IOException {

		System.out.println("I am accepting :" + jobName);
		return jobservice.fetchCodeQualityApplication(jobName);
	}
	
	// Fetching Details Of CodeQualityApplication
		@RequestMapping(value = "/fetchJunitDetails")
		public CodeQualityJobEntity fetchJunitDetails(@RequestParam("jobName") String jobName)
				throws SecurityException, IOException {

			System.out.println("I am accepting :" + jobName);
			return jobservice.fetchJunitDetails(jobName);
		}

	// Fetching Details Of YascaApplication
	@RequestMapping(value = "/fetchYApplicationDetails")
	public YascaJobEntity fetchYApplicationDetails(@RequestParam("j_applicactionname") String microservicename)
			throws SecurityException, IOException {

		System.out.println("I am accepting :" + microservicename);
		return jobservice.fetchYascaApplication(microservicename);
	}
	
	// Fetching Details Of Regression
			@RequestMapping(value = "/fetchRegressionDetails")
			public  RegressionJobEntity fetchRegressionDetails(@RequestParam("jobName") String jobName)
					throws SecurityException, IOException {

				System.out.println("I am accepting :" + jobName);
				return jobservice.getRegAvgHealth(jobName);
			}

	// Fetching Details Of CheckMarxApplication
	@RequestMapping(value = "/fetchCMApplicationDetails")
	public List<CheckMarxJobentity> fetchCMApplicationDetails(
			@RequestParam("j_applicactionname") String applicationName) throws SecurityException, IOException {

		System.out.println("I am accepting :" + applicationName);
		return jobservice.fetchCheckMarxApplication(applicationName);
	}

	// Fetching Details Of DeployChefApplication
	@RequestMapping(value = "/fetchDCApplicationDetails")
	public List<DeployChefJobEntity> fetchDCApplicationDetails(
			@RequestParam("j_applicactionname") String applicationName) throws SecurityException, IOException {

		System.out.println("I am accepting :" + applicationName);
		return jobservice.fetchDeployChefApplication(applicationName);
	}

	// Fetching Details Of DeployCloudFoundryApplication
	@RequestMapping(value = "/fetchDCFApplicationDetails")
	public List<DeployCloudFoundryJobEntity> fetchDCFApplicationDetails(
			@RequestParam("j_applicactionname") String applicationName) throws SecurityException, IOException {

		System.out.println("I am accepting :" + applicationName);
		return jobservice.fetchDeployCloudFoundryApplication(applicationName);
	}

	// Fetching Details Of DeployJenkinsFoundryApplication
	@RequestMapping(value = "/fetchDJApplicationDetails")
	public List<DeployJenkinsJobEntity> fetchDJApplicationDetails(
			@RequestParam("j_applicactionname") String applicationName) throws SecurityException, IOException {

		System.out.println("I am accepting :" + applicationName);
		return jobservice.fetchDeployJenkinsApplication(applicationName);
	}

	// Fetching Details Of PerformanceApplication
	@RequestMapping(value = "/fetchPApplicationDetails")
	public List<PerformanceJobEntity> fetchPApplicationDetails(
			@RequestParam("j_applicactionname") String applicationName) throws SecurityException, IOException {

		System.out.println("I am accepting :" + applicationName);
		return jobservice.fetchPerformanceApplication(applicationName);
	}

	// Fetching Details Of RegressionApplication
	@RequestMapping(value = "/fetchRApplicationDetails")
	public List<RegressionJobEntity> fetchRApplicationDetails(
			@RequestParam("j_applicactionname") String applicationName) throws SecurityException, IOException {

		System.out.println("I am accepting :" + applicationName);
		return jobservice.fetchRegressionApplication(applicationName);
	}

	// Fetching Details Of SahiApplication
	@RequestMapping(value = "/fetchSApplicationDetails")
	public List<SahiJobEntity> fetchSApplicationDetails(@RequestParam("j_applicactionname") String applicationName)
			throws SecurityException, IOException {

		System.out.println("I am accepting :" + applicationName);
		return jobservice.fetchSahiApplication(applicationName);
	}

	// Fetching Details Of SoapUiApplication
	@RequestMapping(value = "/fetchSUIApplicationDetails")
	public List<SoapUiJobEntity> fetchSUIApplicationDetails(@RequestParam("j_applicactionname") String applicationName)
			throws SecurityException, IOException {

		System.out.println("I am accepting :" + applicationName);
		return jobservice.fetchSoapUiApplication(applicationName);
	}

	@RequestMapping(value = "/isApplicationExists")
	public boolean isApplicationExists(@RequestBody JSONObject jsonObject) throws SecurityException, IOException {
		System.out.println("Inside Controller");
		String applicationName = null;
		String stage = null;

		applicationName = (String) jsonObject.get("jobName");
		stage = (String) jsonObject.get("Stage");
		System.out.println("Application Name :" + applicationName);
		System.out.println("Stage " + stage);
		return jobservice.isExists(applicationName, stage);

	}

	@RequestMapping(value = "/isJobExists")
	public JSONObject isJobExists(@RequestParam("jobName") String jobName) throws SecurityException, IOException {
		System.out.println("Inside Controller");
		System.out.println("Job Name :" + jobName);
		return jobservice.isJobExists(jobName);

	}

	@RequestMapping(value = "/fetchSubAccounts")
	public List<ProjectInformationEntity> fetchSubAccounts(@RequestParam("accountName") String accountName)
			throws SecurityException, IOException {

		System.out.println("Account Name is :" + accountName);
		return jobservice.getSubAccounts(accountName);
		// model.addAttribute("jsonObject", jsonObject);

	}

	@RequestMapping(value = "/fetchSubAccountsDetails")
	public List<ProjectInformationEntity> fetchSubAccountsDetails(@RequestParam("subAccountName") String subAccountName)
			throws SecurityException, IOException {

		System.out.println("Account Name is :" + subAccountName);
		return jobservice.getSubAccountDetails(subAccountName);
		// model.addAttribute("jsonObject", jsonObject);
	}

	@RequestMapping(value = "/fetchWebapps")
	public List<ProjectInformationEntity> fetchWebapps(@RequestParam("applicationName") String applicationName)
			throws SecurityException, IOException {

		System.out.println("Account Name is :" + applicationName);
		return jobservice.getWebapps(applicationName);
		// model.addAttribute("jsonObject", jsonObject);
	}

	@RequestMapping(value = "/fetchWebapps1")
	public List<ProjectInformationEntity> fetchWebapps1(@RequestParam("applicationName") String applicationName,
			@RequestParam("subAccount") String subAccount) throws SecurityException, IOException {

		System.out.println("Account Name is :" + applicationName);
		System.out.println("Sub Account Name is :" + subAccount);
		return jobservice.getWebapps1(applicationName, subAccount);
		// model.addAttribute("jsonObject", jsonObject);
	}

	@RequestMapping(value = "/fetchProjectID")
	public List<ProjectInformationEntity> fetchProjectID(@RequestParam("subAccountName") String subAccountName)
			throws SecurityException, IOException {

		System.out.println("Account Name is :" + subAccountName);
		return jobservice.getProjectID(subAccountName);
		// model.addAttribute("jsonObject", jsonObject);
	}

	@RequestMapping(value = "/fetchProjectName")
	public List<ProjectInformationEntity> fetchProjectName(@RequestParam("subAccountName") String subAccountName)
			throws SecurityException, IOException {

		System.out.println("Account Name is :" + subAccountName);
		return jobservice.getProjectName(subAccountName);
		// model.addAttribute("jsonObject", jsonObject);
	}

	@RequestMapping(value = "/fetchReleaseDate")
	public List<ProjectInformationEntity> fetchReleaseDate(@RequestParam("applicationName") String applicationName)
			throws SecurityException, IOException {

		System.out.println("Application Name is :" + applicationName);
		return jobservice.getProjectReleaseDate(applicationName);
		// model.addAttribute("jsonObject", jsonObject);
	}

	@RequestMapping(value = "/fetchProjectDetails")
	public List<ProjectInformationEntity> fetchProjectDetails() throws SecurityException, IOException {

		return jobservice.fetchProjectDetails();
		// model.addAttribute("jsonObject", jsonObject);

	}

	@RequestMapping(value = "/fetchAppsCount")
	public int fetchAppsCount(@RequestParam("accountname") String accountname) throws SecurityException, IOException {

		return jobservice.fetchAppsCount(accountname);
		// model.addAttribute("jsonObject", jsonObject);

	}

	@RequestMapping(value = "/fetchApplicationName")
	public List<ProjectInformationEntity> fetchApplicationName(@RequestParam("projectId") String projectId)
			throws SecurityException, IOException {

		System.out.println("Account Name is :" + projectId);
		System.out.println(jobservice.getApplicationName(projectId));
		return jobservice.getApplicationName(projectId);
		// model.addAttribute("jsonObject", jsonObject);
	}

	@RequestMapping(value = "/fetchApplicationName1")
	public List<ProjectInformationEntity> fetchApplicationName1(@RequestParam("subAccountName") String subAccountName)
			throws SecurityException, IOException {

		System.out.println("Account Name is :" + subAccountName);
		System.out.println(jobservice.getApplicationName1(subAccountName));
		return jobservice.getApplicationName1(subAccountName);
		// model.addAttribute("jsonObject", jsonObject);
	}

	// Email Code here

	@RequestMapping(value = "/getBuildStatus")
	public String getBuildStatus(@RequestParam("jobName") String jobName, @RequestParam("stage") String stage)
			throws SecurityException, IOException {
		System.out.println("Status is:" + jobservice.getBuildStatus(jobName, stage));
		return jobservice.getBuildStatus(jobName, stage);
	}

	@RequestMapping(value = "/getAllJobs")
	public double getAllJobs(@RequestParam("j_applicactionname") String applicationName)
			throws SecurityException, IOException {

		/*
		 * System.out.println("I am accepting :"+applicationName); JSONArray
		 * myArray = jobservice.getAllJobs(applicationName);
		 * 
		 * 
		 * 
		 * for (int i = 0; i < myArray.size(); i++) {
		 * System.out.println(myArray.get(i)); } double appHealth = 0;
		 * System.out.println(myArray.size());
		 * 
		 * for (int i = 0; i < myArray.size(); i++) { String
		 * jobName=myArray.get(i).toString(); double
		 * jobHealth=jobservice.getSonarAvgHealth(jobName);
		 * 
		 * appHealth=appHealth+jobHealth;
		 * 
		 * System.out.println(jobservice.getSonarAvgHealth(jobName)); }
		 * 
		 * System.out.println(appHealth); return myArray;
		 */

		jobservice.getSonarAvgHealth(applicationName);
		return jobservice.getSonarAvgHealth(applicationName);

	}

	// Getting Application Health for all Stages
	@RequestMapping(value = "/getApplicationHealth")
	public JSONObject getApplicationHealth(@RequestParam("applicationName") String applicationName)
			throws SecurityException, IOException {

		return jobservice.fetchApplicationHealth(applicationName);
	}

	@RequestMapping(value = "/validateUser")
	public MessageDTO validateUser(@RequestBody JSONObject jsonObject)
			throws ClassNotFoundException {

		
		
		String username,password;
		username=(String) jsonObject.get("username");
		password=(String) jsonObject.get("password");
		
		String employeeName = null;
		String userType = null;
		JSONObject jobBean = new JSONObject();
		//model.addAttribute("jobbean", jobBean);
		String status = null;
		String empMangerName = null;
		String approvedFlag = "new user";
		MessageDTO message = new MessageDTO();
		//session.setAttribute("j_username", username);
		//session.setAttribute("j_password", password);

		// EmployeeDetailsEntity empDetailEntity= new EmployeeDetailsEntity();
		String empIds = username;
		String isAdminManager = "no";
		Boolean checkStatus = false;
		WindowsSecurity windowsSecurity = new WindowsSecurity();

		try {

			// log.fatal("validateUser (checkPassword) Method Controller " +
			// empIds);
			System.out.println("validateUser (checkPassword) Method Controller " + empIds);
			checkStatus = windowsSecurity.checkPassword(username, password);
			System.out.println("checkstatus=" + checkStatus);
			System.out.println("Password is " + password);
		} catch (NoSuchFieldException e) {
			e.printStackTrace();

		} catch (RuntimeException e) {
			e.printStackTrace();

		}

		if (checkStatus == false) {
			message.setMsg("Invalid Credentials");
			//model.addAttribute("error", "Invalid Credentials");
			return message;
		} else {}

		message.setMsg("Logged in");
		return message;

	}

	@RequestMapping(value = { "/", "/home" })
	public String home(Model model, HttpSession session)
			throws NumberFormatException, ClassNotFoundException, SQLException {
		JSONObject jsonObject = new JSONObject();
		model.addAttribute("jobbean", jsonObject);
		JobEntity jjob = new JobEntity();
		String isAdminManager = "no";
		String empId = (String) session.getAttribute("employeeId");
		System.out.println("user id = " + empId);
		String userType = (String) session.getAttribute("userType");

		// log.fatal("home (selectAllJobsFromParentDatabase) Controller" +
		// empId);
		// List<JSONObject> list =
		// jobservice.selectAllJobsFromParentDatabase(empId);

		// for (JSONObject jsonObject1 : list) {
		// System.out.println(jjob.getProjectId());
		// }
		// DashboardBean bean = null;
		List<JSONObject> buildStatus = new ArrayList<JSONObject>();
		/*
		 * for (JSONObject jsonObject2 : list) { //bean = new DashboardBean();
		 * jjob = jobservice.getBuildStatusAndAppName(Integer.parseInt(jjob.
		 * getProjectId().toString())); buildStatus.add(bean);
		 * 
		 * }
		 */
		model.addAttribute("buildStatus", buildStatus);
		isAdminManager = (String) session.getAttribute("isAdminManager");
		System.out.println(" admin manager ---------------> " + isAdminManager);
		int flag = 0;
		if (flag == 1)
			model.addAttribute("success", "Jenkins User Id is Successfully Created");
		flag = 0;
		model.addAttribute("isAdminManager", isAdminManager);
		model.addAttribute("userType", userType);
		// model.addAttribute("listOfProjects", list);

		return "landing_page";
	}

	// Email Code Here

	@RequestMapping(value = "/fetchYascaAverage")
	public double fetchYascaAverage(@RequestParam("applicationName") String applicationName)
			throws SecurityException, IOException {
		System.out.println(applicationName);
		return jobservice.fetchYascaAverage(applicationName);
	}

	@RequestMapping(value = "/fetchPerformanceDetails")
	public PerformanceJobEntity fetchPerformanceDetails(@RequestParam("jobName") String jobName)
			throws SecurityException, IOException {
		System.out.println(jobName);
		return jobservice.fetchPerformanceDetails(jobName);
		
		
	}
	
	
	 @RequestMapping(value = "/fetchProjectId")
     public List<String> fetchProjectId() throws SecurityException, IOException {

            return jobservice.fetchProjectId();
            // model.addAttribute("jsonObject", jsonObject);

     }
    
    
     @RequestMapping(value = "/fetchApplicationNameById")
     public List<String> fetchApplicationNameById(@RequestParam("projectId") String projectId)
                   throws SecurityException, IOException {
            //System.out.println(jobName);
            return jobservice.fetchAppByProjId(projectId);
           
           
     }
     @RequestMapping(value = "/getCompleteAppHealth")
     public double getCompleteAppHealth(@RequestParam("applicationName") String applicationName)
                   throws SecurityException, IOException {

            return jobservice.fetchCompleteAppHealth(applicationName);
     }

	
}
