package com.capgemini.DevopsEnablerPlatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


@SpringBootApplication
@EntityScan(basePackages = ("com.capgemini.**"))
@EnableJpaRepositories("com.capgemini.DevopsEnablerPlatform.repository.**")
@Import({ com.capgemini.DevopsEnablerPlatform.Filter.CorsFilter.class }) 


public class DevopsMainClass 
{
	public static void main(String[] args)
	{
		SpringApplication.run(DevopsMainClass.class, args);
	}

}
