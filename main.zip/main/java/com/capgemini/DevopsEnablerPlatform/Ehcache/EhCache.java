package com.capgemini.DevopsEnablerPlatform.Ehcache;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.Calendar;

import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.DevopsEnablerPlatform.EmployeeDetails;
import com.capgemini.DevopsEnablerPlatform.util.PropertyUtil;
import com.mysql.jdbc.PreparedStatement;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

public class EhCache {

	

	CacheManager cm = CacheManager.getInstance();

	String url = PropertyUtil.getPropValue("db_url_1");
	String user = PropertyUtil.getPropValue("jdbc_user");
	String password = PropertyUtil.getPropValue("jdbc_pwd");
	
	private static org.apache.log4j.Logger log = Logger.getLogger(EhCache.class);
	
	
	public String FetchRoleFromDatabase(String EmpId) throws ClassNotFoundException, SQLException{
		
		EmployeeDetails employeeDetails;
		
		Cache cache=null;
		if(!cm.cacheExists("cache2")){
			cm.addCache("cache2");

		}
		
		cache = cm.getCache("cache2");

		String role=null;
		String employeeId=null;
		String level=null;
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");    
		Connection conn = DriverManager.getConnection("jdbc:sqlserver://3.209.30.143;user=intrareadusr;password=read#234$;database=INTRANET_USER");
		
		if(conn!=null){}
			
		Statement sta = conn.createStatement();
		String Sql = "select * from CDB_GE_AD_ATTRIBS_vw ";
		ResultSet rs = sta.executeQuery(Sql);
		while (rs.next()) {
			employeeDetails=new EmployeeDetails();
			role=rs.getString(8);
			employeeId=rs.getString(2);
			employeeDetails.setEmpId(employeeId);
			employeeDetails.setEmpName(rs.getString(3)+" "+rs.getString(4));
			employeeDetails.setUser_role(role);
			employeeDetails.setLevel(rs.getString(15));
			employeeDetails.setEmpManager(rs.getString(13));
			employeeDetails.setEmailAddress(rs.getString(5));
			
			
			cache.put(new Element(employeeId,employeeDetails));
		}




		Element ele = cache.get(EmpId);

		employeeDetails=new EmployeeDetails();
		employeeDetails=(EmployeeDetails) ele.getObjectValue();
		
		level=employeeDetails.getLevel();
		String levelNumber=level.substring(6,level.length());
		int levelNo=Integer.parseInt(levelNumber);
		
		String output=employeeDetails.getUser_role();
		
		if(levelNo > 6){
			log.fatal("FetchRoleFromDatabase Method EhCache " + EmpId);
			return "admin";
		}else {
			log.fatal("FetchRoleFromDatabase Method EhCache " +EmpId);
			return "user";
		}
		

	}

	public String FetchEmpManager(String EmpId){
		
		String output=null;
		String empMangerName=null;
		try{
			Cache cache12 = cm.getCache("cache2");

			
			Element ele = cache12.get(EmpId);
			EmployeeDetails employeeDetails=new EmployeeDetails();
			employeeDetails=(EmployeeDetails) ele.getObjectValue();
			empMangerName=employeeDetails.getEmpManager();
		}catch(NullPointerException e){
			log.error(e);
			output="no records";
		}




		
		log.fatal("FetchEmpManager Method EhCache " +EmpId);
		return empMangerName;

	}

	public String FetchEmpEmailId(String EmpId){
		
		String output=null;
		String empEmailId=null;
		try{
			
			Cache cache12 = cm.getCache("cache2");

			
			Element ele = cache12.get(EmpId);
			EmployeeDetails employeeDetails=new EmployeeDetails();
			
			employeeDetails=(EmployeeDetails) ele.getObjectValue();
			empEmailId=employeeDetails.getEmailAddress();
			
		}catch(NullPointerException e){
			log.error(e);
			output="no records";
		}




		
		log.fatal("FetchEmpEmailId Method EhCache " +EmpId + " " + empEmailId);
		return empEmailId;

	}
	public String FetchRoleFromEhCache(String EmpId){
		
		String output=null;
		String empName=null;
		try{
			Cache cache12 = cm.getCache("cache2");


			Element ele = cache12.get(EmpId);
			EmployeeDetails employeeDetails=new EmployeeDetails();
			employeeDetails=(EmployeeDetails) ele.getObjectValue();
			empName=employeeDetails.getEmpName();
		}catch(NullPointerException e){
			log.error(e);
			output="no records";
		}


		
		log.fatal("FetchRoleFromEhCache Method EhCache " +EmpId + " " + empName);
		return empName;
	}

	public void addUser(String username,String password){
		cm.addCache("cache2");
		Cache cache2 = cm.getCache("cache2");
		cache2.put(new Element(username,password));
		
		log.fatal("addUser Method EhCache ");
	}

	public String getUser(String username){
		
		Cache cache = cm.getCache("cache2");
		String output=null;
		Element ele=null;
		try{
			ele = cache.get(username);
		}catch(NullPointerException e){
			log.error(e);
			return "no records";
		}
		if(ele==null)
			return "no records";
		output = (ele == null ? null : ele.getObjectValue().toString());
		
		log.fatal("getUser Method EhCache " + username);
		return output;
	}

	public void addUserInDatabase(String usename,String empManager) throws ClassNotFoundException{
	
		java.sql.Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		
		
		String role="user";
		EmployeeDetails employeeDetails=new EmployeeDetails();
		String output=null;
		try{
			
			Cache cache12 = cm.getCache("cache2");

		
			Element ele = cache12.get(usename);
			employeeDetails=(EmployeeDetails) ele.getObjectValue();
			output=employeeDetails.getUser_role();
			
		}catch(NullPointerException e){
			log.error(e);
			output="no records";
		}

		String level=employeeDetails.getLevel();
		String levelNumber=level.substring(6,level.length());
		int levelNo=Integer.parseInt(levelNumber);
		if(levelNo > 6){
			role="admin";
		}else{
			role="user";
		}
		

		try {
			String myDriver = "com.mysql.jdbc.Driver";
			Class.forName(myDriver);
			con = DriverManager.getConnection(url, user, password);
			
			Calendar calendar = Calendar.getInstance();
			java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
			String query = " insert into emp_details (emp_id , emp_name , password , created_on , created_by ,lastUpdated_on ," +
			"lastUpdated_by ,delete_flag ,user_role,is_approved,emp_manager )"
			+ " values (?, ?, ?, ?, ?,?,?,?,?,?,?)";

			
			pst = (PreparedStatement) con.prepareStatement(query);
			pst.setString (1, usename);
			pst.setString (2, employeeDetails.getEmpName());
			pst.setString   (3, "xyz");
			pst.setDate(4, startDate);
			pst.setString   (5, "xyz");
			pst.setDate(6, startDate);
			pst.setString   (7, "xyz");
			pst.setBoolean(8, false);
			pst.setString    (9, role);
			pst.setString(10, "On hold");
			pst.setString(11, empManager);
			
			boolean i= pst.execute();
			
			con.close();
		}catch (SQLException ex) {
			log.error(ex);

		} 

		log.fatal("addUserInDatabase Method EhCache " + "usename " + usename + " Manager " +empManager);

	}

	public String isApprove(String usename) throws ClassNotFoundException, SQLException{
		java.sql.Connection con = null;
		PreparedStatement pst = null;

		
	
	
		int emp_id=Integer.parseInt(usename);
		String isApprove="not approved";
		
		try {
			String myDriver = "org.gjt.mm.mysql.Driver";
			Class.forName(myDriver);
			con = DriverManager.getConnection(url, user, password);
			Calendar calendar = Calendar.getInstance();
			java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
			String query = " Select * From emp_details WHERE emp_id=?";


			pst = (PreparedStatement) con.prepareStatement(query);
			pst.setInt (1, emp_id);


			ResultSet rst= pst.executeQuery();
			if(rst.next())
			{
				isApprove=rst.getString(10);
			}

		}catch (SQLException ex) {
			log.error(ex);
		} 

		con.close();
		log.fatal("isApprove Method EhCache ");
		return isApprove;
	}

	public List<String> getListOfOnhold(String empManager) throws ClassNotFoundException, SQLException{
		List<String> list=new LinkedList<String>();
		java.sql.Connection con = null;
		PreparedStatement pst = null;

	
		
		

		String userId=null;
		try {
			String myDriver = "org.gjt.mm.mysql.Driver";
			Class.forName(myDriver);
			con = DriverManager.getConnection(url, user, password);
			Calendar calendar = Calendar.getInstance();
			java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
			String query = " Select * From emp_details WHERE emp_manager=? AND is_approved='On hold' or is_approved='Rejected'";


			pst = (PreparedStatement) con.prepareStatement(query);
			pst.setString(1, empManager);


			ResultSet rst= pst.executeQuery();
			while(rst.next())
			{
				userId=rst.getString(1);
				list.add(userId);
			}

		}catch (SQLException ex) {
			log.error(ex);
		} 
		for(String obj:list){
			
		}
		con.close();
		
		log.fatal("getListOfOnhold Method EhCache ");
		return list;
	}

	public Boolean addStatus(String status,String employeeId) throws ClassNotFoundException, SQLException{
		List<String> list=new LinkedList<String>();
		java.sql.Connection con = null;
		PreparedStatement pst = null;

		
		
		
		boolean result=false;
		int userId=Integer.parseInt(employeeId);
		
		try {
			String myDriver = "org.gjt.mm.mysql.Driver";
			Class.forName(myDriver);
			con = DriverManager.getConnection(url, user, password);
			
			Calendar calendar = Calendar.getInstance();
			java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
			String query = " update emp_details set is_approved=? where emp_id=?;";


			
			pst = (PreparedStatement) con.prepareStatement(query);
			pst.setString(1, status);
			pst.setInt(2, userId);

			
			result= pst.execute();
			

		}catch (SQLException ex) {
			log.error(ex);

		} 
		for(String obj:list){
			
		}
		con.close();
		log.fatal("addStatus Method EhCache " + employeeId);
		return result;
	}

	public EmployeeDetails countUsers(String empManager) throws SQLException, ClassNotFoundException{
		java.sql.Connection con = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		PreparedStatement pst3 = null;
		PreparedStatement pst4 = null;
		int count1=0;
		int count2=0;
		int count3=0;
		int count4=0;
		
		
	
		EmployeeDetails employeeDetails=new EmployeeDetails();
		String userId=null;
		
		try {
			String myDriver = "org.gjt.mm.mysql.Driver";
			Class.forName(myDriver);
			con = DriverManager.getConnection(url, user, password);
			

			String query1 = " Select count(*) AS total From emp_details WHERE emp_manager=?";
			String query2 = " Select count(*) AS total From emp_details WHERE is_approved='On hold' AND emp_manager=? ";  
			String query3 = " Select count(*) AS total From emp_details WHERE is_approved='Rejected' AND emp_manager=?";  
			String query4 = " Select count(*) AS total From emp_details WHERE is_approved='Approved' AND emp_manager=?"; 
			
			pst1 = (PreparedStatement) con.prepareStatement(query1);
			pst1.setString(1, empManager);

			pst2= (PreparedStatement) con.prepareStatement(query2);
			pst2.setString(1, empManager);

			pst3 = (PreparedStatement) con.prepareStatement(query3);
			pst3.setString(1, empManager);

			pst4 = (PreparedStatement) con.prepareStatement(query4);
			pst4.setString(1, empManager);

			
			ResultSet rst1= pst1.executeQuery();
			ResultSet rst2= pst2.executeQuery();
			ResultSet rst3= pst3.executeQuery();
			ResultSet rst4= pst4.executeQuery();
			while(rst1.next()){
				count1=rst1.getInt("total");
			}

			while(rst2.next()){
				count2=rst2.getInt("total");
			}
			while(rst3.next()){
				count3=rst3.getInt("total");
			}
			while(rst4.next()){
				count4=rst4.getInt("total");
			}

		}catch (SQLException ex) {
			log.error(ex);

		} 
		
		employeeDetails.setTotalEmployees(count1);
		employeeDetails.setApprovedEmployees(count4);
		employeeDetails.setOnHoldEmployees(count2);
		employeeDetails.setRejectedEmployees(count3);
		con.close();
		log.fatal("countUsers Method EhCache ");
		return employeeDetails;
	}

	public List<EmployeeDetails> getUsers(String status) throws SQLException, ClassNotFoundException{
		java.sql.Connection con = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		PreparedStatement pst3 = null;
		PreparedStatement pst4 = null;
		int employeeId=0;
		EmployeeDetails employeeDetails;
		List<EmployeeDetails> userList=new ArrayList<EmployeeDetails>();

	
	
		

		String userId=null;
		
		try {
			String myDriver = "org.gjt.mm.mysql.Driver";
			Class.forName(myDriver);
			con = DriverManager.getConnection(url, user, password);
			
			String query1 = " Select *  From emp_details ";
			String query2 = " Select *  From emp_details WHERE is_approved='On hold' ";  
			String query3 = " Select *  From emp_details WHERE is_approved='Rejected' ";  
			String query4 = " Select *  From emp_details WHERE is_approved='Approved' "; 
			pst1 = (PreparedStatement) con.prepareStatement(query1);
			pst2= (PreparedStatement) con.prepareStatement(query2);
			pst3 = (PreparedStatement) con.prepareStatement(query3);
			pst4 = (PreparedStatement) con.prepareStatement(query4);

			
			ResultSet rst1= pst1.executeQuery();
			ResultSet rst2= pst2.executeQuery();
			ResultSet rst3= pst3.executeQuery();
			ResultSet rst4= pst4.executeQuery();
			if("all_users".equals(status)){
				while(rst1.next()){
					employeeDetails=new EmployeeDetails();
					employeeId  =rst1.getInt(1);
					
					String empID=Integer.toString(employeeId);
					employeeDetails.setEmpId(empID);
					userList.add(employeeDetails);
				}
			}
			if("onhold_users".equals(status)){
				while(rst2.next()){
					employeeDetails=new EmployeeDetails();
					employeeId  =rst2.getInt(1);
					String empID=Integer.toString(employeeId);
					employeeDetails.setEmpId(empID);
					userList.add(employeeDetails);
				}
			}
			if("rejected_users".equals(status)){
				while(rst3.next()){
					employeeDetails=new EmployeeDetails();
					employeeId  =rst3.getInt(1);
					String empID=Integer.toString(employeeId);
					employeeDetails.setEmpId(empID);
					userList.add(employeeDetails);
				}
			}
			if("approved_users".equals(status)){
				while(rst4.next()){
					employeeDetails=new EmployeeDetails();
					employeeId  =rst4.getInt(1);
					String empID=Integer.toString(employeeId);
					employeeDetails.setEmpId(empID);
					userList.add(employeeDetails);
				}
			}
		}catch (SQLException ex) {
			log.error(ex);

		} 
		
		con.close();
		log.fatal("getUsers Method EhCache ");
		return userList;
	}

	public String FetchEmpLevel(String EmpId){
		String output=null;
		String emplevel=null;
		try{
			Cache cache12 = cm.getCache("cache2");

			

			Element ele = cache12.get(EmpId);
			EmployeeDetails employeeDetails=new EmployeeDetails();
			
			employeeDetails=(EmployeeDetails) ele.getObjectValue();
			emplevel=employeeDetails.getLevel();
			
		}catch(NullPointerException e){
			log.error(e);
			output="no records";
		}

		
		log.fatal("FetchEmpLevel Method EhCache " + EmpId + " level " + emplevel);
		return emplevel;

	}
}
