package com.capgemini.DevopsEnablerPlatform.service;


import java.sql.SQLException;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.capgemini.DevopsEnablerPlatform.dto.CodeQualityJobDTO;
import com.capgemini.DevopsEnablerPlatform.dto.MessageDTO;
import com.capgemini.DevopsEnablerPlatform.dto.YascaJobDTO;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.CheckMarxJobentity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.CodeQualityJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.DeployChefJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.DeployCloudFoundryJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.DeployJenkinsJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.PerformanceJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.ProjectInformationEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.RegressionJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.SahiJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.SoapUiJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.YascaJobEntity;







public interface IJobService 
{
	public MessageDTO createJob(JSONObject jsonObject);

	public MessageDTO submitNewBatchJob1(JSONObject jsonObject);
	public MessageDTO buildMavenJob(JSONObject jsonObject);
	public MessageDTO submitNewMicroserviceJob(JSONObject jsonObject);
	public MessageDTO submitNewYascaJob(JSONObject jsonObject);
	public MessageDTO submitNewCheckmarx(JSONObject jsonObject);
	public MessageDTO submitDeploy(JSONObject jsonObject) ;
	public MessageDTO submitNewPerformanceJob(JSONObject jsonObject);
	public MessageDTO submitNewRegressionJob(JSONObject jsonObject);
	public MessageDTO buildJob(JSONObject jsonObject);
	public MessageDTO viewReports(JSONObject jsonObject);
	public MessageDTO fetchJunitSonarReport(String projectName);
	public MessageDTO getPolymerReports(JSONObject jsonObject);
	public void fetchYascaMetrixReport(JSONObject jsonObject, String projectName);
	public void fetchRegressionTestReport(JSONObject jsonObject, String projectName);
	public void fetchRegressionBuildStatus(JSONObject jsonObject, String projectName);
	public void getPerformanceJobName(JSONObject jsonObject, String projectName);
	public MessageDTO buildDeployJob(JSONObject jsonObject,String projectName);
	public MessageDTO createDeployChefJob(JSONObject jsonObject);
	public MessageDTO submitDeployCfJob(JSONObject jsonObject);
	public MessageDTO buildDeployCfJob(JSONObject jsonObject,String projectName);

	public boolean isTCGUser(String username);

	public void saveEmployeeInformation(String username, String password) throws ClassNotFoundException, SQLException;

	
	public List<JobEntity> fetchjobsofusers() ;
	
	public JSONArray getAllJobs(String applicationName) ;

	public List<ProjectInformationEntity> fetchProjectDetails();
	
	//public CodeQualityJobDTO fetchCodeQuality1Application(String microservicename) ;
	
	//public YascaJobDTO fetchYascaApplication(String microservicename) ;
	
	public List<CheckMarxJobentity> fetchCheckMarxApplication(String applicationName) ;
	
	public List<DeployChefJobEntity> fetchDeployChefApplication(String applicationName) ;
	
	public List<DeployCloudFoundryJobEntity> fetchDeployCloudFoundryApplication(String applicationName) ;
	
	public List<DeployJenkinsJobEntity> fetchDeployJenkinsApplication(String applicationName) ;
	
	public List<PerformanceJobEntity> fetchPerformanceApplication(String applicationName) ;
	
	public List<RegressionJobEntity> fetchRegressionApplication(String applicationName) ;
	
	public List<SahiJobEntity> fetchSahiApplication(String applicationName) ;
	
	public List<SoapUiJobEntity> fetchSoapUiApplication(String applicationName) ;
	
	public boolean isExists(String appName,String stage);
	
	public List<ProjectInformationEntity> getSubAccounts(String accountName);
	
	public List<ProjectInformationEntity> getSubAccountDetails(String subAccountName);
	
	public List<ProjectInformationEntity> getProjectID(String subAccountName);
	
	public List<ProjectInformationEntity> getProjectName(String subAccountName);

	public List<ProjectInformationEntity> getProjectReleaseDate(String applicationName);

	public int fetchAppsCount(String accountname);

	List<ProjectInformationEntity> getApplicationName(String subAccountName);

	public List<ProjectInformationEntity> getWebapps(String applicationName);

	public JSONObject isJobExists(String jobName);

	List<ProjectInformationEntity> getApplicationName1(String subAccountName);

	public List<ProjectInformationEntity> getWebapps1(String applicationName, String subAccount);
	
	public String getBuildStatus(String jobName,String stage);

	public double fetchYascaAverage(String applicationname);
	
	public double getSonarAvgHealth(String object);
	
	
	public List<CodeQualityJobEntity> fetchCodeQualityApplication(String microservicename) ;
	
	public YascaJobEntity fetchYascaApplication(String microservicename) ;

	public CodeQualityJobEntity fetchJunitDetails(String microservicename) ;
	
	
	public JSONObject fetchApplicationHealth(String applicationName);
	
	public List<CodeQualityJobEntity> getCodeQualityApplicationDetails(String jobName);

	public List<YascaJobEntity> getYascaApplicationDetails(String jobName);
	
	public RegressionJobEntity getRegAvgHealth(String jobName);

    public PerformanceJobEntity fetchPerformanceDetails(String jobName);
	
	public String fetchPerformanceDetailsByAppName(String applicationName);
	
	public List<String> fetchProjectId();
     
	 public List<String> fetchAppByProjId(String projectId);
	
	 public double fetchCompleteAppHealth(String applicationName);
}
