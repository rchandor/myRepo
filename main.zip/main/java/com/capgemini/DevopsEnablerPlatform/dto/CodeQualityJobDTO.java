package com.capgemini.DevopsEnablerPlatform.dto;

public class CodeQualityJobDTO {

	private int jobId;

	private int codequalityId;
	
	private String batchFileName;
	
	
	private String blockCoverage;
	
	private String blocker;
	
	private String buildNumber;

	private String appHealth;
	
	private double avgHealth;
	
	private String buildStatus;
	
	
	private String classCoverage;
	
	private String comments;
	
	private String count;
	
	private String critical;
	
	private String deployCheck;
	
	
	private String deploymentType;
	
	private String duplicateLines;
	
	private String emmaCoverageReport;
	
	
	
	private int empId;
	
	private String info;
	
	
	private String ipAddress;
	
	private String issues;
	
	private String lineCoverage;
	
	
	private String locationType;
	
	private String mainClassName;
	
	
	private String major;
	
	private String methodCoverage;
	
	private String minor;

	
	private String passCount;
	
	
	private String projectId;
	
	private String projectName;
	
	private String projectType;
	
	
	private String skipCount;
	
	private String sourceCode;
	
	
	private String submit;
	
	private String tagName;
	
	private String techDept;

	
	private String wasCheck ;
	
	
	private String currentState;
	
	private String buildNumberCodeQuality;
	
	
	private String projectBranch;
	
	private String applicationType;
	
	private String microserviceName;

	
	private String polymerReport ;


	
	
	public String getAppHealth() {
		return appHealth;
	}


	public void setAppHealth(String appHealth) {
		this.appHealth = appHealth;
	}


	public double getAvgHealth() {
		return avgHealth;
	}


	public void setAvgHealth(double avgHealth) {
		this.avgHealth = avgHealth;
	}


	public int getJobId() {
		return jobId;
	}


	public void setJobId(int jobId) {
		this.jobId = jobId;
	}


	public int getCodequalityId() {
		return codequalityId;
	}


	public void setCodequalityId(int codequalityId) {
		this.codequalityId = codequalityId;
	}


	public String getBatchFileName() {
		return batchFileName;
	}


	public void setBatchFileName(String batchFileName) {
		this.batchFileName = batchFileName;
	}


	public String getBlockCoverage() {
		return blockCoverage;
	}


	public void setBlockCoverage(String blockCoverage) {
		this.blockCoverage = blockCoverage;
	}


	public String getBlocker() {
		return blocker;
	}


	public void setBlocker(String blocker) {
		this.blocker = blocker;
	}


	public String getBuildNumber() {
		return buildNumber;
	}


	public void setBuildNumber(String buildNumber) {
		this.buildNumber = buildNumber;
	}


	public String getBuildStatus() {
		return buildStatus;
	}


	public void setBuildStatus(String buildStatus) {
		this.buildStatus = buildStatus;
	}


	public String getClassCoverage() {
		return classCoverage;
	}


	public void setClassCoverage(String classCoverage) {
		this.classCoverage = classCoverage;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public String getCount() {
		return count;
	}


	public void setCount(String count) {
		this.count = count;
	}


	public String getCritical() {
		return critical;
	}


	public void setCritical(String critical) {
		this.critical = critical;
	}


	public String getDeployCheck() {
		return deployCheck;
	}


	public void setDeployCheck(String deployCheck) {
		this.deployCheck = deployCheck;
	}


	public String getDeploymentType() {
		return deploymentType;
	}


	public void setDeploymentType(String deploymentType) {
		this.deploymentType = deploymentType;
	}


	public String getDuplicateLines() {
		return duplicateLines;
	}


	public void setDuplicateLines(String duplicateLines) {
		this.duplicateLines = duplicateLines;
	}


	public String getEmmaCoverageReport() {
		return emmaCoverageReport;
	}


	public void setEmmaCoverageReport(String emmaCoverageReport) {
		this.emmaCoverageReport = emmaCoverageReport;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getInfo() {
		return info;
	}


	public void setInfo(String info) {
		this.info = info;
	}


	public String getIpAddress() {
		return ipAddress;
	}


	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}


	public String getIssues() {
		return issues;
	}


	public void setIssues(String issues) {
		this.issues = issues;
	}


	public String getLineCoverage() {
		return lineCoverage;
	}


	public void setLineCoverage(String lineCoverage) {
		this.lineCoverage = lineCoverage;
	}


	public String getLocationType() {
		return locationType;
	}


	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}


	public String getMainClassName() {
		return mainClassName;
	}


	public void setMainClassName(String mainClassName) {
		this.mainClassName = mainClassName;
	}


	public String getMajor() {
		return major;
	}


	public void setMajor(String major) {
		this.major = major;
	}


	public String getMethodCoverage() {
		return methodCoverage;
	}


	public void setMethodCoverage(String methodCoverage) {
		this.methodCoverage = methodCoverage;
	}


	public String getMinor() {
		return minor;
	}


	public void setMinor(String minor) {
		this.minor = minor;
	}


	public String getPassCount() {
		return passCount;
	}


	public void setPassCount(String passCount) {
		this.passCount = passCount;
	}


	public String getProjectId() {
		return projectId;
	}


	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}


	public String getProjectName() {
		return projectName;
	}


	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}


	public String getProjectType() {
		return projectType;
	}


	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}


	public String getSkipCount() {
		return skipCount;
	}


	public void setSkipCount(String skipCount) {
		this.skipCount = skipCount;
	}


	public String getSourceCode() {
		return sourceCode;
	}


	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}


	public String getSubmit() {
		return submit;
	}


	public void setSubmit(String submit) {
		this.submit = submit;
	}


	public String getTagName() {
		return tagName;
	}


	public void setTagName(String tagName) {
		this.tagName = tagName;
	}


	public String getTechDept() {
		return techDept;
	}


	public void setTechDept(String techDept) {
		this.techDept = techDept;
	}


	public String getWasCheck() {
		return wasCheck;
	}


	public void setWasCheck(String wasCheck) {
		this.wasCheck = wasCheck;
	}


	public String getCurrentState() {
		return currentState;
	}


	public void setCurrentState(String currentState) {
		this.currentState = currentState;
	}


	public String getBuildNumberCodeQuality() {
		return buildNumberCodeQuality;
	}


	public void setBuildNumberCodeQuality(String buildNumberCodeQuality) {
		this.buildNumberCodeQuality = buildNumberCodeQuality;
	}


	public String getProjectBranch() {
		return projectBranch;
	}


	public void setProjectBranch(String projectBranch) {
		this.projectBranch = projectBranch;
	}


	public String getApplicationType() {
		return applicationType;
	}


	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}


	public String getMicroserviceName() {
		return microserviceName;
	}


	public void setMicroserviceName(String microserviceName) {
		this.microserviceName = microserviceName;
	}


	public String getPolymerReport() {
		return polymerReport;
	}


	public void setPolymerReport(String polymerReport) {
		this.polymerReport = polymerReport;
	}





}
