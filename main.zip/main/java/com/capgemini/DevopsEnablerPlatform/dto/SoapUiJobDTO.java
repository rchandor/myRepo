package com.capgemini.DevopsEnablerPlatform.dto;

public class SoapUiJobDTO {
	
	private int jobId;

	
private int soapUiJobId;
	
	
	
	private String buildNumberSoapUi;
	
	

	
	private int empId;
	
	private String projectId;
	

	private String soapUiProjectName;
	
	
	private String soapUiStatus;
	
	private String soapUiXmlPath;
	
	
	private String soapUiProjectId;
	
	private String submit;
		
	private String soapUiLocationType;
	
	
	private String soapUiSourcecode;
	
	private String soapUiFailCount;
	
	
	private String soapUiModule;
	
	private String soapUiPassCount;
	

	private String soapUiSkipCount;

	private String svnUrl;
	
	private String localModuleDirectory;
	
	
	private String cvsRoot;
	
	private String cvsPassword;
	
	private String cvsLocation;

			
	private String gitUrl;
	
	private String gitBranch;

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public int getSoapUiJobId() {
		return soapUiJobId;
	}

	public void setSoapUiJobId(int soapUiJobId) {
		this.soapUiJobId = soapUiJobId;
	}

	public String getBuildNumberSoapUi() {
		return buildNumberSoapUi;
	}

	public void setBuildNumberSoapUi(String buildNumberSoapUi) {
		this.buildNumberSoapUi = buildNumberSoapUi;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getSoapUiProjectName() {
		return soapUiProjectName;
	}

	public void setSoapUiProjectName(String soapUiProjectName) {
		this.soapUiProjectName = soapUiProjectName;
	}

	public String getSoapUiStatus() {
		return soapUiStatus;
	}

	public void setSoapUiStatus(String soapUiStatus) {
		this.soapUiStatus = soapUiStatus;
	}

	public String getSoapUiXmlPath() {
		return soapUiXmlPath;
	}

	public void setSoapUiXmlPath(String soapUiXmlPath) {
		this.soapUiXmlPath = soapUiXmlPath;
	}

	public String getSoapUiProjectId() {
		return soapUiProjectId;
	}

	public void setSoapUiProjectId(String soapUiProjectId) {
		this.soapUiProjectId = soapUiProjectId;
	}

	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}

	public String getSoapUiLocationType() {
		return soapUiLocationType;
	}

	public void setSoapUiLocationType(String soapUiLocationType) {
		this.soapUiLocationType = soapUiLocationType;
	}

	public String getSoapUiSourcecode() {
		return soapUiSourcecode;
	}

	public void setSoapUiSourcecode(String soapUiSourcecode) {
		this.soapUiSourcecode = soapUiSourcecode;
	}

	public String getSoapUiFailCount() {
		return soapUiFailCount;
	}

	public void setSoapUiFailCount(String soapUiFailCount) {
		this.soapUiFailCount = soapUiFailCount;
	}

	public String getSoapUiModule() {
		return soapUiModule;
	}

	public void setSoapUiModule(String soapUiModule) {
		this.soapUiModule = soapUiModule;
	}

	public String getSoapUiPassCount() {
		return soapUiPassCount;
	}

	public void setSoapUiPassCount(String soapUiPassCount) {
		this.soapUiPassCount = soapUiPassCount;
	}

	public String getSoapUiSkipCount() {
		return soapUiSkipCount;
	}

	public void setSoapUiSkipCount(String soapUiSkipCount) {
		this.soapUiSkipCount = soapUiSkipCount;
	}

	public String getSvnUrl() {
		return svnUrl;
	}

	public void setSvnUrl(String svnUrl) {
		this.svnUrl = svnUrl;
	}

	public String getLocalModuleDirectory() {
		return localModuleDirectory;
	}

	public void setLocalModuleDirectory(String localModuleDirectory) {
		this.localModuleDirectory = localModuleDirectory;
	}

	public String getCvsRoot() {
		return cvsRoot;
	}

	public void setCvsRoot(String cvsRoot) {
		this.cvsRoot = cvsRoot;
	}

	public String getCvsPassword() {
		return cvsPassword;
	}

	public void setCvsPassword(String cvsPassword) {
		this.cvsPassword = cvsPassword;
	}

	public String getCvsLocation() {
		return cvsLocation;
	}

	public void setCvsLocation(String cvsLocation) {
		this.cvsLocation = cvsLocation;
	}

	public String getGitUrl() {
		return gitUrl;
	}

	public void setGitUrl(String gitUrl) {
		this.gitUrl = gitUrl;
	}

	public String getGitBranch() {
		return gitBranch;
	}

	public void setGitBranch(String gitBranch) {
		this.gitBranch = gitBranch;
	}

	

}
