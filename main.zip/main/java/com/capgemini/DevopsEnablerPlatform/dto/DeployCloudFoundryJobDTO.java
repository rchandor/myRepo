package com.capgemini.DevopsEnablerPlatform.dto;


import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;

public class DeployCloudFoundryJobDTO 
{

	private int deployJobIdCf;
	
	private String buildNumberDeployCf;

	private String contextPathCf;

	private String deployBuildStatusCf;

	private String deployCfSeverType;

	private String deployCfsourceCode;

	private String deployRadioButtonCf;

	private JobEntity jobEntity;

	private int empId;

	private String projectId;

	private String managerPassWordCf;

	private String managerPassWordJbossCf;

	private String managerUserNameCf;

	private String managerUserNameJbossCf;

	private String moduleCf;

	private String organisationDeployCf;

	private String passwordDeployCf;

	private String projectNameDeployCf;

	private String tomCatUrlCf;

	private String urlDeployCf;

	private String userNameDeployCf;

	private String warCf;

	private String spaceDeployCf;

	private String serviceNameDeployCf;

	private String servicePlanDeployCf;

	private String serviceTypeDeployCf;

	private String moduleDeployCf;

	private String nameDeploycf;

	private String planDeployCf;

	private String typeDeploycf;

	private String manifestDeployCf;

	private String deployCfconfig;

	private String applicationDeployCf;

	private String custombuildpackDeployCf;

	private String customstackDeployCf;

	private String hostnameDeployCf;

	private String instancesDeployCf;

	private String memoryDeployCf;

	private String timeoutDeployCf;

	private String svnUrl;

	private String localModuleDirectory;

	private String cvsRoot;

	private String cvsPassword;

	private String cvsLocation;

	private String gitUrl;

	private String gitBranch;

	public int getDeployJobIdCf() {
		return deployJobIdCf;
	}

	public void setDeployJobIdCf(int deployJobIdCf) {
		this.deployJobIdCf = deployJobIdCf;
	}

	public String getBuildNumberDeployCf() {
		return buildNumberDeployCf;
	}

	public void setBuildNumberDeployCf(String buildNumberDeployCf) {
		this.buildNumberDeployCf = buildNumberDeployCf;
	}

	public String getContextPathCf() {
		return contextPathCf;
	}

	public void setContextPathCf(String contextPathCf) {
		this.contextPathCf = contextPathCf;
	}

	public String getDeployBuildStatusCf() {
		return deployBuildStatusCf;
	}

	public void setDeployBuildStatusCf(String deployBuildStatusCf) {
		this.deployBuildStatusCf = deployBuildStatusCf;
	}

	public String getDeployCfSeverType() {
		return deployCfSeverType;
	}

	public void setDeployCfSeverType(String deployCfSeverType) {
		this.deployCfSeverType = deployCfSeverType;
	}

	public String getDeployCfsourceCode() {
		return deployCfsourceCode;
	}

	public void setDeployCfsourceCode(String deployCfsourceCode) {
		this.deployCfsourceCode = deployCfsourceCode;
	}

	public String getDeployRadioButtonCf() {
		return deployRadioButtonCf;
	}

	public void setDeployRadioButtonCf(String deployRadioButtonCf) {
		this.deployRadioButtonCf = deployRadioButtonCf;
	}

	public JobEntity getJobEntity() {
		return jobEntity;
	}

	public void setJobEntity(JobEntity jobEntity) {
		this.jobEntity = jobEntity;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getManagerPassWordCf() {
		return managerPassWordCf;
	}

	public void setManagerPassWordCf(String managerPassWordCf) {
		this.managerPassWordCf = managerPassWordCf;
	}

	public String getManagerPassWordJbossCf() {
		return managerPassWordJbossCf;
	}

	public void setManagerPassWordJbossCf(String managerPassWordJbossCf) {
		this.managerPassWordJbossCf = managerPassWordJbossCf;
	}

	public String getManagerUserNameCf() {
		return managerUserNameCf;
	}

	public void setManagerUserNameCf(String managerUserNameCf) {
		this.managerUserNameCf = managerUserNameCf;
	}

	public String getManagerUserNameJbossCf() {
		return managerUserNameJbossCf;
	}

	public void setManagerUserNameJbossCf(String managerUserNameJbossCf) {
		this.managerUserNameJbossCf = managerUserNameJbossCf;
	}

	public String getModuleCf() {
		return moduleCf;
	}

	public void setModuleCf(String moduleCf) {
		this.moduleCf = moduleCf;
	}

	public String getOrganisationDeployCf() {
		return organisationDeployCf;
	}

	public void setOrganisationDeployCf(String organisationDeployCf) {
		this.organisationDeployCf = organisationDeployCf;
	}

	public String getPasswordDeployCf() {
		return passwordDeployCf;
	}

	public void setPasswordDeployCf(String passwordDeployCf) {
		this.passwordDeployCf = passwordDeployCf;
	}

	public String getProjectNameDeployCf() {
		return projectNameDeployCf;
	}

	public void setProjectNameDeployCf(String projectNameDeployCf) {
		this.projectNameDeployCf = projectNameDeployCf;
	}

	public String getTomCatUrlCf() {
		return tomCatUrlCf;
	}

	public void setTomCatUrlCf(String tomCatUrlCf) {
		this.tomCatUrlCf = tomCatUrlCf;
	}

	public String getUrlDeployCf() {
		return urlDeployCf;
	}

	public void setUrlDeployCf(String urlDeployCf) {
		this.urlDeployCf = urlDeployCf;
	}

	public String getUserNameDeployCf() {
		return userNameDeployCf;
	}

	public void setUserNameDeployCf(String userNameDeployCf) {
		this.userNameDeployCf = userNameDeployCf;
	}

	public String getWarCf() {
		return warCf;
	}

	public void setWarCf(String warCf) {
		this.warCf = warCf;
	}

	public String getSpaceDeployCf() {
		return spaceDeployCf;
	}

	public void setSpaceDeployCf(String spaceDeployCf) {
		this.spaceDeployCf = spaceDeployCf;
	}

	public String getServiceNameDeployCf() {
		return serviceNameDeployCf;
	}

	public void setServiceNameDeployCf(String serviceNameDeployCf) {
		this.serviceNameDeployCf = serviceNameDeployCf;
	}

	public String getServicePlanDeployCf() {
		return servicePlanDeployCf;
	}

	public void setServicePlanDeployCf(String servicePlanDeployCf) {
		this.servicePlanDeployCf = servicePlanDeployCf;
	}

	public String getServiceTypeDeployCf() {
		return serviceTypeDeployCf;
	}

	public void setServiceTypeDeployCf(String serviceTypeDeployCf) {
		this.serviceTypeDeployCf = serviceTypeDeployCf;
	}

	public String getModuleDeployCf() {
		return moduleDeployCf;
	}

	public void setModuleDeployCf(String moduleDeployCf) {
		this.moduleDeployCf = moduleDeployCf;
	}

	public String getNameDeploycf() {
		return nameDeploycf;
	}

	public void setNameDeploycf(String nameDeploycf) {
		this.nameDeploycf = nameDeploycf;
	}

	public String getPlanDeployCf() {
		return planDeployCf;
	}

	public void setPlanDeployCf(String planDeployCf) {
		this.planDeployCf = planDeployCf;
	}

	public String getTypeDeploycf() {
		return typeDeploycf;
	}

	public void setTypeDeploycf(String typeDeploycf) {
		this.typeDeploycf = typeDeploycf;
	}

	public String getManifestDeployCf() {
		return manifestDeployCf;
	}

	public void setManifestDeployCf(String manifestDeployCf) {
		this.manifestDeployCf = manifestDeployCf;
	}

	public String getDeployCfconfig() {
		return deployCfconfig;
	}

	public void setDeployCfconfig(String deployCfconfig) {
		this.deployCfconfig = deployCfconfig;
	}

	public String getApplicationDeployCf() {
		return applicationDeployCf;
	}

	public void setApplicationDeployCf(String applicationDeployCf) {
		this.applicationDeployCf = applicationDeployCf;
	}

	public String getCustombuildpackDeployCf() {
		return custombuildpackDeployCf;
	}

	public void setCustombuildpackDeployCf(String custombuildpackDeployCf) {
		this.custombuildpackDeployCf = custombuildpackDeployCf;
	}

	public String getCustomstackDeployCf() {
		return customstackDeployCf;
	}

	public void setCustomstackDeployCf(String customstackDeployCf) {
		this.customstackDeployCf = customstackDeployCf;
	}

	public String getHostnameDeployCf() {
		return hostnameDeployCf;
	}

	public void setHostnameDeployCf(String hostnameDeployCf) {
		this.hostnameDeployCf = hostnameDeployCf;
	}

	public String getInstancesDeployCf() {
		return instancesDeployCf;
	}

	public void setInstancesDeployCf(String instancesDeployCf) {
		this.instancesDeployCf = instancesDeployCf;
	}

	public String getMemoryDeployCf() {
		return memoryDeployCf;
	}

	public void setMemoryDeployCf(String memoryDeployCf) {
		this.memoryDeployCf = memoryDeployCf;
	}

	public String getTimeoutDeployCf() {
		return timeoutDeployCf;
	}

	public void setTimeoutDeployCf(String timeoutDeployCf) {
		this.timeoutDeployCf = timeoutDeployCf;
	}

	public String getSvnUrl() {
		return svnUrl;
	}

	public void setSvnUrl(String svnUrl) {
		this.svnUrl = svnUrl;
	}

	public String getLocalModuleDirectory() {
		return localModuleDirectory;
	}

	public void setLocalModuleDirectory(String localModuleDirectory) {
		this.localModuleDirectory = localModuleDirectory;
	}

	public String getCvsRoot() {
		return cvsRoot;
	}

	public void setCvsRoot(String cvsRoot) {
		this.cvsRoot = cvsRoot;
	}

	public String getCvsPassword() {
		return cvsPassword;
	}

	public void setCvsPassword(String cvsPassword) {
		this.cvsPassword = cvsPassword;
	}

	public String getCvsLocation() {
		return cvsLocation;
	}

	public void setCvsLocation(String cvsLocation) {
		this.cvsLocation = cvsLocation;
	}

	public String getGitUrl() {
		return gitUrl;
	}

	public void setGitUrl(String gitUrl) {
		this.gitUrl = gitUrl;
	}

	public String getGitBranch() {
		return gitBranch;
	}

	public void setGitBranch(String gitBranch) {
		this.gitBranch = gitBranch;
	}


}
