package com.capgemini.DevopsEnablerPlatform.dto;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;

public class DeployChefJobDTO 
{
	
	private int deployJobIdChef;


	private String buildNumberDeployChef;

	private String contextPathChef;

	private String deployBuildStatusChef;

	private String deployChefSeverType;

	private String deployCheflocationType;

	private String deployChefsourceCode;

	private JobEntity jobEntity;

	private int empId;

	private String projectId;

	private String jbossUrlChef;

	private String managerPassWordChef;

	private String managerPassWordJbossChef;

	private String managerUserNameChef;

	private String managerUserNameJbossChef;

	private String moduleChefStaging;

	private String projectNameDeployChef;

	private String tomCatUrlChef;

	private String urlDeployChef;

	private String warChef;

	private String moduleChef;

	private String deployRadioButtonChef;

	private String deployRadioButton ;

	private String credentialsDeployCf;

	private String organisationDeployCf;

	private String targetDeployCf;

	private String passwordDeployCf;

	private String userNameDeployCf;

	private String svnUrl;

	private String localModuleDirectory;

	private String cvsRoot;

	private String cvsPassword;

	private String cvsLocation;
	
	private String gitUrl;
	
	private String gitBranch;

	public int getDeployJobIdChef() {
		return deployJobIdChef;
	}

	public void setDeployJobIdChef(int deployJobIdChef) {
		this.deployJobIdChef = deployJobIdChef;
	}

	public String getBuildNumberDeployChef() {
		return buildNumberDeployChef;
	}

	public void setBuildNumberDeployChef(String buildNumberDeployChef) {
		this.buildNumberDeployChef = buildNumberDeployChef;
	}

	public String getContextPathChef() {
		return contextPathChef;
	}

	public void setContextPathChef(String contextPathChef) {
		this.contextPathChef = contextPathChef;
	}

	public String getDeployBuildStatusChef() {
		return deployBuildStatusChef;
	}

	public void setDeployBuildStatusChef(String deployBuildStatusChef) {
		this.deployBuildStatusChef = deployBuildStatusChef;
	}

	public String getDeployChefSeverType() {
		return deployChefSeverType;
	}

	public void setDeployChefSeverType(String deployChefSeverType) {
		this.deployChefSeverType = deployChefSeverType;
	}

	public String getDeployCheflocationType() {
		return deployCheflocationType;
	}

	public void setDeployCheflocationType(String deployCheflocationType) {
		this.deployCheflocationType = deployCheflocationType;
	}

	public String getDeployChefsourceCode() {
		return deployChefsourceCode;
	}

	public void setDeployChefsourceCode(String deployChefsourceCode) {
		this.deployChefsourceCode = deployChefsourceCode;
	}

	public JobEntity getJobEntity() {
		return jobEntity;
	}

	public void setJobEntity(JobEntity jobEntity) {
		this.jobEntity = jobEntity;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getJbossUrlChef() {
		return jbossUrlChef;
	}

	public void setJbossUrlChef(String jbossUrlChef) {
		this.jbossUrlChef = jbossUrlChef;
	}

	public String getManagerPassWordChef() {
		return managerPassWordChef;
	}

	public void setManagerPassWordChef(String managerPassWordChef) {
		this.managerPassWordChef = managerPassWordChef;
	}

	public String getManagerPassWordJbossChef() {
		return managerPassWordJbossChef;
	}

	public void setManagerPassWordJbossChef(String managerPassWordJbossChef) {
		this.managerPassWordJbossChef = managerPassWordJbossChef;
	}

	public String getManagerUserNameChef() {
		return managerUserNameChef;
	}

	public void setManagerUserNameChef(String managerUserNameChef) {
		this.managerUserNameChef = managerUserNameChef;
	}

	public String getManagerUserNameJbossChef() {
		return managerUserNameJbossChef;
	}

	public void setManagerUserNameJbossChef(String managerUserNameJbossChef) {
		this.managerUserNameJbossChef = managerUserNameJbossChef;
	}

	public String getModuleChefStaging() {
		return moduleChefStaging;
	}

	public void setModuleChefStaging(String moduleChefStaging) {
		this.moduleChefStaging = moduleChefStaging;
	}

	public String getProjectNameDeployChef() {
		return projectNameDeployChef;
	}

	public void setProjectNameDeployChef(String projectNameDeployChef) {
		this.projectNameDeployChef = projectNameDeployChef;
	}

	public String getTomCatUrlChef() {
		return tomCatUrlChef;
	}

	public void setTomCatUrlChef(String tomCatUrlChef) {
		this.tomCatUrlChef = tomCatUrlChef;
	}

	public String getUrlDeployChef() {
		return urlDeployChef;
	}

	public void setUrlDeployChef(String urlDeployChef) {
		this.urlDeployChef = urlDeployChef;
	}

	public String getWarChef() {
		return warChef;
	}

	public void setWarChef(String warChef) {
		this.warChef = warChef;
	}

	public String getModuleChef() {
		return moduleChef;
	}

	public void setModuleChef(String moduleChef) {
		this.moduleChef = moduleChef;
	}

	public String getDeployRadioButtonChef() {
		return deployRadioButtonChef;
	}

	public void setDeployRadioButtonChef(String deployRadioButtonChef) {
		this.deployRadioButtonChef = deployRadioButtonChef;
	}

	public String getDeployRadioButton() {
		return deployRadioButton;
	}

	public void setDeployRadioButton(String deployRadioButton) {
		this.deployRadioButton = deployRadioButton;
	}

	public String getCredentialsDeployCf() {
		return credentialsDeployCf;
	}

	public void setCredentialsDeployCf(String credentialsDeployCf) {
		this.credentialsDeployCf = credentialsDeployCf;
	}

	public String getOrganisationDeployCf() {
		return organisationDeployCf;
	}

	public void setOrganisationDeployCf(String organisationDeployCf) {
		this.organisationDeployCf = organisationDeployCf;
	}

	public String getTargetDeployCf() {
		return targetDeployCf;
	}

	public void setTargetDeployCf(String targetDeployCf) {
		this.targetDeployCf = targetDeployCf;
	}

	public String getPasswordDeployCf() {
		return passwordDeployCf;
	}

	public void setPasswordDeployCf(String passwordDeployCf) {
		this.passwordDeployCf = passwordDeployCf;
	}

	public String getUserNameDeployCf() {
		return userNameDeployCf;
	}

	public void setUserNameDeployCf(String userNameDeployCf) {
		this.userNameDeployCf = userNameDeployCf;
	}

	public String getSvnUrl() {
		return svnUrl;
	}

	public void setSvnUrl(String svnUrl) {
		this.svnUrl = svnUrl;
	}

	public String getLocalModuleDirectory() {
		return localModuleDirectory;
	}

	public void setLocalModuleDirectory(String localModuleDirectory) {
		this.localModuleDirectory = localModuleDirectory;
	}

	public String getCvsRoot() {
		return cvsRoot;
	}

	public void setCvsRoot(String cvsRoot) {
		this.cvsRoot = cvsRoot;
	}

	public String getCvsPassword() {
		return cvsPassword;
	}

	public void setCvsPassword(String cvsPassword) {
		this.cvsPassword = cvsPassword;
	}

	public String getCvsLocation() {
		return cvsLocation;
	}

	public void setCvsLocation(String cvsLocation) {
		this.cvsLocation = cvsLocation;
	}

	public String getGitUrl() {
		return gitUrl;
	}

	public void setGitUrl(String gitUrl) {
		this.gitUrl = gitUrl;
	}

	public String getGitBranch() {
		return gitBranch;
	}

	public void setGitBranch(String gitBranch) {
		this.gitBranch = gitBranch;
	}
}
