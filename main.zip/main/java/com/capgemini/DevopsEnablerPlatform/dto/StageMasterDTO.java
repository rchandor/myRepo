package com.capgemini.DevopsEnablerPlatform.dto;

public class StageMasterDTO {

	private String stageId;
	
	private String stageName;

	public String getStageId() {
		return stageId;
	}

	public void setStageId(String stageId) {
		this.stageId = stageId;
	}

	public String getStageName() {
		return stageName;
	}

	public void setStageName(String stageName) {
		this.stageName = stageName;
	}

	
	


}
