package com.capgemini.DevopsEnablerPlatform.dto;

public class PerformanceJobDTO {

	private int jobId;
private int performanceId;
	

	private int empId;
	
	private String projectId;

	
	private String childPerformanceName;

	
	private String finalMaxMamory;
	
	private String jmxFile;

	
	private String loadedClassesCount;
	
	
	private String maxPerGenMemory;
	
	private String memoryDetails;
	
	
	private String performanceBuildStatus;

	
	
	private String performancePdfName;
	
	private String performanceLocationType;
	
	
	private String performanceSourcecode;
	
	
	private String reportModule;

	
	private String reportName;
	
	private String reportUrl;

	
	private String usedMemory;
	
	
	private String usedNonHeapMemory;
	
	private String usedPhysicalMemorySize;
	
	
	private String usedSwapSpaceSize;
	
	private String buildNumberPerformance;
	
	private String deploymentRadioButtonPerformance;
	
	private String svnUrl;
	
	private String localModuleDirectory;
	
	
	private String cvsRoot;
	
	private String cvsPassword;
	
	private String cvsLocation;

			
	private String gitUrl;
	
	private String gitBranch;

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public int getPerformanceId() {
		return performanceId;
	}

	public void setPerformanceId(int performanceId) {
		this.performanceId = performanceId;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getChildPerformanceName() {
		return childPerformanceName;
	}

	public void setChildPerformanceName(String childPerformanceName) {
		this.childPerformanceName = childPerformanceName;
	}

	public String getFinalMaxMamory() {
		return finalMaxMamory;
	}

	public void setFinalMaxMamory(String finalMaxMamory) {
		this.finalMaxMamory = finalMaxMamory;
	}

	public String getJmxFile() {
		return jmxFile;
	}

	public void setJmxFile(String jmxFile) {
		this.jmxFile = jmxFile;
	}

	public String getLoadedClassesCount() {
		return loadedClassesCount;
	}

	public void setLoadedClassesCount(String loadedClassesCount) {
		this.loadedClassesCount = loadedClassesCount;
	}

	public String getMaxPerGenMemory() {
		return maxPerGenMemory;
	}

	public void setMaxPerGenMemory(String maxPerGenMemory) {
		this.maxPerGenMemory = maxPerGenMemory;
	}

	public String getMemoryDetails() {
		return memoryDetails;
	}

	public void setMemoryDetails(String memoryDetails) {
		this.memoryDetails = memoryDetails;
	}

	public String getPerformanceBuildStatus() {
		return performanceBuildStatus;
	}

	public void setPerformanceBuildStatus(String performanceBuildStatus) {
		this.performanceBuildStatus = performanceBuildStatus;
	}

	public String getPerformancePdfName() {
		return performancePdfName;
	}

	public void setPerformancePdfName(String performancePdfName) {
		this.performancePdfName = performancePdfName;
	}

	public String getPerformanceLocationType() {
		return performanceLocationType;
	}

	public void setPerformanceLocationType(String performanceLocationType) {
		this.performanceLocationType = performanceLocationType;
	}

	public String getPerformanceSourcecode() {
		return performanceSourcecode;
	}

	public void setPerformanceSourcecode(String performanceSourcecode) {
		this.performanceSourcecode = performanceSourcecode;
	}

	public String getReportModule() {
		return reportModule;
	}

	public void setReportModule(String reportModule) {
		this.reportModule = reportModule;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getReportUrl() {
		return reportUrl;
	}

	public void setReportUrl(String reportUrl) {
		this.reportUrl = reportUrl;
	}

	public String getUsedMemory() {
		return usedMemory;
	}

	public void setUsedMemory(String usedMemory) {
		this.usedMemory = usedMemory;
	}

	public String getUsedNonHeapMemory() {
		return usedNonHeapMemory;
	}

	public void setUsedNonHeapMemory(String usedNonHeapMemory) {
		this.usedNonHeapMemory = usedNonHeapMemory;
	}

	public String getUsedPhysicalMemorySize() {
		return usedPhysicalMemorySize;
	}

	public void setUsedPhysicalMemorySize(String usedPhysicalMemorySize) {
		this.usedPhysicalMemorySize = usedPhysicalMemorySize;
	}

	public String getUsedSwapSpaceSize() {
		return usedSwapSpaceSize;
	}

	public void setUsedSwapSpaceSize(String usedSwapSpaceSize) {
		this.usedSwapSpaceSize = usedSwapSpaceSize;
	}

	public String getBuildNumberPerformance() {
		return buildNumberPerformance;
	}

	public void setBuildNumberPerformance(String buildNumberPerformance) {
		this.buildNumberPerformance = buildNumberPerformance;
	}

	public String getDeploymentRadioButtonPerformance() {
		return deploymentRadioButtonPerformance;
	}

	public void setDeploymentRadioButtonPerformance(
			String deploymentRadioButtonPerformance) {
		this.deploymentRadioButtonPerformance = deploymentRadioButtonPerformance;
	}

	public String getSvnUrl() {
		return svnUrl;
	}

	public void setSvnUrl(String svnUrl) {
		this.svnUrl = svnUrl;
	}

	public String getLocalModuleDirectory() {
		return localModuleDirectory;
	}

	public void setLocalModuleDirectory(String localModuleDirectory) {
		this.localModuleDirectory = localModuleDirectory;
	}

	public String getCvsRoot() {
		return cvsRoot;
	}

	public void setCvsRoot(String cvsRoot) {
		this.cvsRoot = cvsRoot;
	}

	public String getCvsPassword() {
		return cvsPassword;
	}

	public void setCvsPassword(String cvsPassword) {
		this.cvsPassword = cvsPassword;
	}

	public String getCvsLocation() {
		return cvsLocation;
	}

	public void setCvsLocation(String cvsLocation) {
		this.cvsLocation = cvsLocation;
	}

	public String getGitUrl() {
		return gitUrl;
	}

	public void setGitUrl(String gitUrl) {
		this.gitUrl = gitUrl;
	}

	public String getGitBranch() {
		return gitBranch;
	}

	public void setGitBranch(String gitBranch) {
		this.gitBranch = gitBranch;
	}


}
