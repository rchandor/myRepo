package com.capgemini.DevopsEnablerPlatform.dto;

import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;

public class SahiJobDTO {

	private int jobId;

	
private int sahiId;
	
	
	
	private JobEntity jobEntity;

	
	private int empId;
	
	private String projectId;
	
	
	private String sahiHostScript;

	
	private String sahiHtmlReportLocationScript;
	
	private String sahiLocationScript;

	
	private String sahiProjectName;
	
	
	private String sahiStatus;
	
	private String sahiSourcecode;
	
	
	private String buildNumberSahi;
	
	private String sahiModule;
	
	private String svnUrl;
	
	private String localModuleDirectory;
	
	
	private String cvsRoot;
	
	private String cvsPassword;
	
	private String cvsLocation;

			
	private String gitUrl;
	
	private String gitBranch;

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public int getSahiId() {
		return sahiId;
	}

	public void setSahiId(int sahiId) {
		this.sahiId = sahiId;
	}

	public JobEntity getJobEntity() {
		return jobEntity;
	}

	public void setJobEntity(JobEntity jobEntity) {
		this.jobEntity = jobEntity;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getSahiHostScript() {
		return sahiHostScript;
	}

	public void setSahiHostScript(String sahiHostScript) {
		this.sahiHostScript = sahiHostScript;
	}

	public String getSahiHtmlReportLocationScript() {
		return sahiHtmlReportLocationScript;
	}

	public void setSahiHtmlReportLocationScript(String sahiHtmlReportLocationScript) {
		this.sahiHtmlReportLocationScript = sahiHtmlReportLocationScript;
	}

	public String getSahiLocationScript() {
		return sahiLocationScript;
	}

	public void setSahiLocationScript(String sahiLocationScript) {
		this.sahiLocationScript = sahiLocationScript;
	}

	public String getSahiProjectName() {
		return sahiProjectName;
	}

	public void setSahiProjectName(String sahiProjectName) {
		this.sahiProjectName = sahiProjectName;
	}

	public String getSahiStatus() {
		return sahiStatus;
	}

	public void setSahiStatus(String sahiStatus) {
		this.sahiStatus = sahiStatus;
	}

	public String getSahiSourcecode() {
		return sahiSourcecode;
	}

	public void setSahiSourcecode(String sahiSourcecode) {
		this.sahiSourcecode = sahiSourcecode;
	}

	public String getBuildNumberSahi() {
		return buildNumberSahi;
	}

	public void setBuildNumberSahi(String buildNumberSahi) {
		this.buildNumberSahi = buildNumberSahi;
	}

	public String getSahiModule() {
		return sahiModule;
	}

	public void setSahiModule(String sahiModule) {
		this.sahiModule = sahiModule;
	}

	public String getSvnUrl() {
		return svnUrl;
	}

	public void setSvnUrl(String svnUrl) {
		this.svnUrl = svnUrl;
	}

	public String getLocalModuleDirectory() {
		return localModuleDirectory;
	}

	public void setLocalModuleDirectory(String localModuleDirectory) {
		this.localModuleDirectory = localModuleDirectory;
	}

	public String getCvsRoot() {
		return cvsRoot;
	}

	public void setCvsRoot(String cvsRoot) {
		this.cvsRoot = cvsRoot;
	}

	public String getCvsPassword() {
		return cvsPassword;
	}

	public void setCvsPassword(String cvsPassword) {
		this.cvsPassword = cvsPassword;
	}

	public String getCvsLocation() {
		return cvsLocation;
	}

	public void setCvsLocation(String cvsLocation) {
		this.cvsLocation = cvsLocation;
	}

	public String getGitUrl() {
		return gitUrl;
	}

	public void setGitUrl(String gitUrl) {
		this.gitUrl = gitUrl;
	}

	public String getGitBranch() {
		return gitBranch;
	}

	public void setGitBranch(String gitBranch) {
		this.gitBranch = gitBranch;
	}


	

}
