package com.capgemini.DevopsEnablerPlatform.dto;


import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;

public class CheckMarxJobDTO 
{

	private int checkmarxJobId;
	
	private String checkmarxBuildStatus;
	
	private String checkmarxModule;
	
	private String checkmarxlocationType;
	
	private String checkmarxsourceCode;
	
	private String highRiskVulnerabilities;
	
	private String infoRiskVulnerabilities;
	
	private String lowRiskVulnerabilities;
	
	private String mediumRiskVulnerabilities;
	
	private String presetCheckmarx;
	
	private String projectNameCheckmarx;
	
	private String sourceCharacterEncoding;
	
	private String teamcheckmarx;
	
	private String urlCheckmarx;
	
	private String buildNumberCheckmarx;
	
	private String applicationId;
	
	private String applicationName;
	
	private String codeChanges;
	
	private JobEntity jobEntity;
	
	private int empId;
	
	private String projectId;
	
	private String projectName;
	
	private String ssdApplicable;
	
	private String account;
	
	private String subAccount;
	
	private String accountName;
	
	private String subAccountName;
	
	private String deploymentRadioButton;
	
	private String checkmarxServerPassword;
	
	private String checkmarxServerUsername;
	
	private String previousProjectId;

	public int getCheckmarxJobId() {
		return checkmarxJobId;
	}

	public void setCheckmarxJobId(int checkmarxJobId) {
		this.checkmarxJobId = checkmarxJobId;
	}

	public String getCheckmarxBuildStatus() {
		return checkmarxBuildStatus;
	}

	public void setCheckmarxBuildStatus(String checkmarxBuildStatus) {
		this.checkmarxBuildStatus = checkmarxBuildStatus;
	}

	public String getCheckmarxModule() {
		return checkmarxModule;
	}

	public void setCheckmarxModule(String checkmarxModule) {
		this.checkmarxModule = checkmarxModule;
	}

	public String getCheckmarxlocationType() {
		return checkmarxlocationType;
	}

	public void setCheckmarxlocationType(String checkmarxlocationType) {
		this.checkmarxlocationType = checkmarxlocationType;
	}

	public String getCheckmarxsourceCode() {
		return checkmarxsourceCode;
	}

	public void setCheckmarxsourceCode(String checkmarxsourceCode) {
		this.checkmarxsourceCode = checkmarxsourceCode;
	}

	public String getHighRiskVulnerabilities() {
		return highRiskVulnerabilities;
	}

	public void setHighRiskVulnerabilities(String highRiskVulnerabilities) {
		this.highRiskVulnerabilities = highRiskVulnerabilities;
	}

	public String getInfoRiskVulnerabilities() {
		return infoRiskVulnerabilities;
	}

	public void setInfoRiskVulnerabilities(String infoRiskVulnerabilities) {
		this.infoRiskVulnerabilities = infoRiskVulnerabilities;
	}

	public String getLowRiskVulnerabilities() {
		return lowRiskVulnerabilities;
	}

	public void setLowRiskVulnerabilities(String lowRiskVulnerabilities) {
		this.lowRiskVulnerabilities = lowRiskVulnerabilities;
	}

	public String getMediumRiskVulnerabilities() {
		return mediumRiskVulnerabilities;
	}

	public void setMediumRiskVulnerabilities(String mediumRiskVulnerabilities) {
		this.mediumRiskVulnerabilities = mediumRiskVulnerabilities;
	}

	public String getPresetCheckmarx() {
		return presetCheckmarx;
	}

	public void setPresetCheckmarx(String presetCheckmarx) {
		this.presetCheckmarx = presetCheckmarx;
	}

	public String getProjectNameCheckmarx() {
		return projectNameCheckmarx;
	}

	public void setProjectNameCheckmarx(String projectNameCheckmarx) {
		this.projectNameCheckmarx = projectNameCheckmarx;
	}

	public String getSourceCharacterEncoding() {
		return sourceCharacterEncoding;
	}

	public void setSourceCharacterEncoding(String sourceCharacterEncoding) {
		this.sourceCharacterEncoding = sourceCharacterEncoding;
	}

	public String getTeamcheckmarx() {
		return teamcheckmarx;
	}

	public void setTeamcheckmarx(String teamcheckmarx) {
		this.teamcheckmarx = teamcheckmarx;
	}

	public String getUrlCheckmarx() {
		return urlCheckmarx;
	}

	public void setUrlCheckmarx(String urlCheckmarx) {
		this.urlCheckmarx = urlCheckmarx;
	}

	public String getBuildNumberCheckmarx() {
		return buildNumberCheckmarx;
	}

	public void setBuildNumberCheckmarx(String buildNumberCheckmarx) {
		this.buildNumberCheckmarx = buildNumberCheckmarx;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getCodeChanges() {
		return codeChanges;
	}

	public void setCodeChanges(String codeChanges) {
		this.codeChanges = codeChanges;
	}

	public JobEntity getJobEntity() {
		return jobEntity;
	}

	public void setJobEntity(JobEntity jobEntity) {
		this.jobEntity = jobEntity;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getSsdApplicable() {
		return ssdApplicable;
	}

	public void setSsdApplicable(String ssdApplicable) {
		this.ssdApplicable = ssdApplicable;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getSubAccount() {
		return subAccount;
	}

	public void setSubAccount(String subAccount) {
		this.subAccount = subAccount;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getSubAccountName() {
		return subAccountName;
	}

	public void setSubAccountName(String subAccountName) {
		this.subAccountName = subAccountName;
	}

	public String getDeploymentRadioButton() {
		return deploymentRadioButton;
	}

	public void setDeploymentRadioButton(String deploymentRadioButton) {
		this.deploymentRadioButton = deploymentRadioButton;
	}

	public String getCheckmarxServerPassword() {
		return checkmarxServerPassword;
	}

	public void setCheckmarxServerPassword(String checkmarxServerPassword) {
		this.checkmarxServerPassword = checkmarxServerPassword;
	}

	public String getCheckmarxServerUsername() {
		return checkmarxServerUsername;
	}

	public void setCheckmarxServerUsername(String checkmarxServerUsername) {
		this.checkmarxServerUsername = checkmarxServerUsername;
	}

	public String getPreviousProjectId() {
		return previousProjectId;
	}

	public void setPreviousProjectId(String previousProjectId) {
		this.previousProjectId = previousProjectId;
	}
	

}
