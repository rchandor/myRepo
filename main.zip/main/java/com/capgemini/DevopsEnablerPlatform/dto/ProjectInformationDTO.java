package com.capgemini.DevopsEnablerPlatform.dto;

import java.util.List;

import org.json.simple.JSONObject;

public class ProjectInformationDTO 
{

    private long projectKey;
   
    private String accountName;
   
    private List<SubAccountDto> subAccountName;
   
    private String projectId;
   
    private String applicationName;
   
    private String projectName;
   
    private String projectManager;
   
    private String accountManager;
  
    private String releaseDate;
   
    private String webappsAndMicroservice;
    

	public long getProjectKey() {
		return projectKey;
	}

	public void setProjectKey(long projectKey) {
		this.projectKey = projectKey;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public List<SubAccountDto> getSubAccountName() {
		return subAccountName;
	}

	public void setSubAccountName(List<SubAccountDto> subAccountName) {
		this.subAccountName = subAccountName;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectManager() {
		return projectManager;
	}

	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}

	public String getAccountManager() {
		return accountManager;
	}

	public void setAccountManager(String accountManager) {
		this.accountManager = accountManager;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getWebappsAndMicroservice() {
		return webappsAndMicroservice;
	}

	public void setWebappsAndMicroservice(String webappsAndMicroservice) {
		this.webappsAndMicroservice = webappsAndMicroservice;
	}
    
    

}
