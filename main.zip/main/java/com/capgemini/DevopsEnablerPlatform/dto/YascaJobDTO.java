package com.capgemini.DevopsEnablerPlatform.dto;

public class YascaJobDTO {
	private int yascaJobId;
	
	
	private String stageId;
	
	private int jobId;

	private String appHealth;
	
	private int empId;
	
	private double avgHealth;


	private String projectId;
	
	private String severityCritical;

	
	private String severityHigh;
	


	private String severityInformational;
	
	
	private String severityLow;
	
	private String severityWarning;
	
	private String yascaBuildStatus;

	
	private String yascaJobName;
	

	private String yascaLocationType;

	
	private String yascaModule;



	private String yascaSourcecode;

	
	private String buildNumberYasca;
	

	private String previousProjectID;


	
	public double getAvgHealth() {
		return avgHealth;
	}


	public void setAvgHealth(double avgHealth) {
		this.avgHealth = avgHealth;
	}


	public int getYascaJobId() {
		return yascaJobId;
	}


	public void setYascaJobId(int yascaJobId) {
		this.yascaJobId = yascaJobId;
	}


	public String getStageId() {
		return stageId;
	}


	public void setStageId(String stageId) {
		this.stageId = stageId;
	}


	public int getJobId() {
		return jobId;
	}


	public void setJobId(int jobId) {
		this.jobId = jobId;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getProjectId() {
		return projectId;
	}


	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}


	public String getSeverityCritical() {
		return severityCritical;
	}


	public void setSeverityCritical(String severityCritical) {
		this.severityCritical = severityCritical;
	}


	public String getSeverityHigh() {
		return severityHigh;
	}


	public void setSeverityHigh(String severityHigh) {
		this.severityHigh = severityHigh;
	}


	public String getSeverityInformational() {
		return severityInformational;
	}


	public void setSeverityInformational(String severityInformational) {
		this.severityInformational = severityInformational;
	}


	public String getSeverityLow() {
		return severityLow;
	}


	public void setSeverityLow(String severityLow) {
		this.severityLow = severityLow;
	}


	public String getSeverityWarning() {
		return severityWarning;
	}


	public void setSeverityWarning(String severityWarning) {
		this.severityWarning = severityWarning;
	}


	public String getYascaBuildStatus() {
		return yascaBuildStatus;
	}


	public void setYascaBuildStatus(String yascaBuildStatus) {
		this.yascaBuildStatus = yascaBuildStatus;
	}


	public String getYascaJobName() {
		return yascaJobName;
	}


	public void setYascaJobName(String yascaJobName) {
		this.yascaJobName = yascaJobName;
	}


	public String getYascaLocationType() {
		return yascaLocationType;
	}


	public void setYascaLocationType(String yascaLocationType) {
		this.yascaLocationType = yascaLocationType;
	}


	public String getYascaModule() {
		return yascaModule;
	}


	public void setYascaModule(String yascaModule) {
		this.yascaModule = yascaModule;
	}


	public String getYascaSourcecode() {
		return yascaSourcecode;
	}


	public void setYascaSourcecode(String yascaSourcecode) {
		this.yascaSourcecode = yascaSourcecode;
	}


	public String getBuildNumberYasca() {
		return buildNumberYasca;
	}


	public void setBuildNumberYasca(String buildNumberYasca) {
		this.buildNumberYasca = buildNumberYasca;
	}


	public String getPreviousProjectID() {
		return previousProjectID;
	}


	public void setPreviousProjectID(String previousProjectID) {
		this.previousProjectID = previousProjectID;
	}


	public String getAppHealth() {
		return appHealth;
	}


	public void setAppHealth(String appHealth) {
		this.appHealth = appHealth;
	}
	
	
	
}
