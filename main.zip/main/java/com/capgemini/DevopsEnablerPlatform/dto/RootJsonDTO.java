package com.capgemini.DevopsEnablerPlatform.dto;

import java.util.List;

public class RootJsonDTO {

	
	private String id;
	private String key;
	private String name;
	private String qualifier;
	private List<MeasuresDTO> measures;
	private boolean error;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}
	public List<MeasuresDTO> getMeasures() {
		return measures;
	}
	public void setMeasures(List<MeasuresDTO> measures) {
		this.measures = measures;
	}
	public boolean isError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	
	
	
}
