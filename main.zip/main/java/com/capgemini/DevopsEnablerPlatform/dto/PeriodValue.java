package com.capgemini.DevopsEnablerPlatform.dto;

public class PeriodValue {

	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	private String index;
	private String value;
}
