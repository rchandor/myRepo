package com.capgemini.DevopsEnablerPlatform.dto;

public class SubAccountDto {
	private long applicationNumber;

	public long getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(long applicationNumber) {
		this.applicationNumber = applicationNumber;
	}
	
}