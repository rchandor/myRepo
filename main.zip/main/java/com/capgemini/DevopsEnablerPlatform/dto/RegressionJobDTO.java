package com.capgemini.DevopsEnablerPlatform.dto;

public class RegressionJobDTO {

	private int regressionId;


	private int jobId;



	private int empId;

	private String projectId;

	private String regressionFailCount;


	private String regressionModule;

	private String regressionPassCount;


	private String regressionProjectName;


	private String regressionSkipCount;


	private String regressionStatus;

	private String regressionSourcecode;


	private String buildNumberRegression;

	private String svnUrl;

	private String localModuleDirectory;


	private String cvsRoot;

	private String cvsPassword;

	private String cvsLocation;


	private String gitUrl;

	public String getAppHealth() {
		return appHealth;
	}

	public void setAppHealth(String appHealth) {
		this.appHealth = appHealth;
	}

	public double getRegAvgHealth() {
		return regAvgHealth;
	}

	public void setRegAvgHealth(double regAvgHealth) {
		this.regAvgHealth = regAvgHealth;
	}

	private String gitBranch;
	
	private String appHealth;
	
	private double regAvgHealth;

	public int getRegressionId() {
		return regressionId;
	}

	public void setRegressionId(int regressionId) {
		this.regressionId = regressionId;
	}

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getRegressionFailCount() {
		return regressionFailCount;
	}

	public void setRegressionFailCount(String regressionFailCount) {
		this.regressionFailCount = regressionFailCount;
	}

	public String getRegressionModule() {
		return regressionModule;
	}

	public void setRegressionModule(String regressionModule) {
		this.regressionModule = regressionModule;
	}

	public String getRegressionPassCount() {
		return regressionPassCount;
	}

	public void setRegressionPassCount(String regressionPassCount) {
		this.regressionPassCount = regressionPassCount;
	}

	public String getRegressionProjectName() {
		return regressionProjectName;
	}

	public void setRegressionProjectName(String regressionProjectName) {
		this.regressionProjectName = regressionProjectName;
	}

	public String getRegressionSkipCount() {
		return regressionSkipCount;
	}

	public void setRegressionSkipCount(String regressionSkipCount) {
		this.regressionSkipCount = regressionSkipCount;
	}

	public String getRegressionStatus() {
		return regressionStatus;
	}

	public void setRegressionStatus(String regressionStatus) {
		this.regressionStatus = regressionStatus;
	}

	public String getRegressionSourcecode() {
		return regressionSourcecode;
	}

	public void setRegressionSourcecode(String regressionSourcecode) {
		this.regressionSourcecode = regressionSourcecode;
	}

	public String getBuildNumberRegression() {
		return buildNumberRegression;
	}

	public void setBuildNumberRegression(String buildNumberRegression) {
		this.buildNumberRegression = buildNumberRegression;
	}

	public String getSvnUrl() {
		return svnUrl;
	}

	public void setSvnUrl(String svnUrl) {
		this.svnUrl = svnUrl;
	}

	public String getLocalModuleDirectory() {
		return localModuleDirectory;
	}

	public void setLocalModuleDirectory(String localModuleDirectory) {
		this.localModuleDirectory = localModuleDirectory;
	}

	public String getCvsRoot() {
		return cvsRoot;
	}

	public void setCvsRoot(String cvsRoot) {
		this.cvsRoot = cvsRoot;
	}

	public String getCvsPassword() {
		return cvsPassword;
	}

	public void setCvsPassword(String cvsPassword) {
		this.cvsPassword = cvsPassword;
	}

	public String getCvsLocation() {
		return cvsLocation;
	}

	public void setCvsLocation(String cvsLocation) {
		this.cvsLocation = cvsLocation;
	}

	public String getGitUrl() {
		return gitUrl;
	}

	public void setGitUrl(String gitUrl) {
		this.gitUrl = gitUrl;
	}

	public String getGitBranch() {
		return gitBranch;
	}

	public void setGitBranch(String gitBranch) {
		this.gitBranch = gitBranch;
	}



}
