package com.capgemini.DevopsEnablerPlatform.dto;

import java.util.List;

public class MeasuresDTO {

	private List<MeasureValues> measureValues;

	public List<MeasureValues> getMeasureValues() {
		return measureValues;
	}

	public void setMeasureValues(List<MeasureValues> measureValues) {
		this.measureValues = measureValues;
	}

	@Override
	public String toString() {
		return "MeasuresDTO [measureValues=" + measureValues + ", getMeasureValues()=" + getMeasureValues()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	
	
	
}
