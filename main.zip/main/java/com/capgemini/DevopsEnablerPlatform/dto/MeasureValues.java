package com.capgemini.DevopsEnablerPlatform.dto;

import java.util.List;

public class MeasureValues {

	private String metric;
	private float metricValue;
	public String getMetric() {
		return metric;
	}
	public void setMetric(String metric) {
		this.metric = metric;
	}
	public float getMetricValue() {
		return metricValue;
	}
	public void setMetricValue(float metricValue) {
		this.metricValue = metricValue;
	}
	public List<PeriodValue> getPeriodValue() {
		return periodValue;
	}
	public void setPeriodValue(List<PeriodValue> periodValue) {
		this.periodValue = periodValue;
	}
	private List<PeriodValue> periodValue;
	
}
