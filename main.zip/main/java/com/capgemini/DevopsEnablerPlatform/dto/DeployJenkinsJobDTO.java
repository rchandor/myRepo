package com.capgemini.DevopsEnablerPlatform.dto;

import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;

public class DeployJenkinsJobDTO 
{
	
		private int deployJobIdChef;
				
		private JobEntity jobEntity;
		
		private int empId;
		
		private String projectId;
		
		private String svnUrl;
		
		private String localModuleDirectory;
		
		private String cvsRoot;
		
		private String cvsPassword;
		
		private String cvsLocation;
		
		private String gitUrl;
		
		private String gitBranch;
		
		private String managerPassWordJboss;
		
		private String managerUserNameJboss;
		
		private String jbossUrl;
		
		private String tomcatUsername;
		
		private String tomcatPassword;
		
		private String tomcatUrl;

		public int getDeployJobIdChef() {
			return deployJobIdChef;
		}

		public void setDeployJobIdChef(int deployJobIdChef) {
			this.deployJobIdChef = deployJobIdChef;
		}

		public JobEntity getJobEntity() {
			return jobEntity;
		}

		public void setJobEntity(JobEntity jobEntity) {
			this.jobEntity = jobEntity;
		}
		public int getEmpId() {
			return empId;
		}

		public void setEmpId(int empId) {
			this.empId = empId;
		}

		public String getProjectId() {
			return projectId;
		}

		public void setProjectId(String projectId) {
			this.projectId = projectId;
		}

		public String getSvnUrl() {
			return svnUrl;
		}

		public void setSvnUrl(String svnUrl) {
			this.svnUrl = svnUrl;
		}

		public String getLocalModuleDirectory() {
			return localModuleDirectory;
		}

		public void setLocalModuleDirectory(String localModuleDirectory) {
			this.localModuleDirectory = localModuleDirectory;
		}

		public String getCvsRoot() {
			return cvsRoot;
		}

		public void setCvsRoot(String cvsRoot) {
			this.cvsRoot = cvsRoot;
		}

		public String getCvsPassword() {
			return cvsPassword;
		}

		public void setCvsPassword(String cvsPassword) {
			this.cvsPassword = cvsPassword;
		}

		public String getCvsLocation() {
			return cvsLocation;
		}

		public void setCvsLocation(String cvsLocation) {
			this.cvsLocation = cvsLocation;
		}

		public String getGitUrl() {
			return gitUrl;
		}

		public void setGitUrl(String gitUrl) {
			this.gitUrl = gitUrl;
		}

		public String getGitBranch() {
			return gitBranch;
		}

		public void setGitBranch(String gitBranch) {
			this.gitBranch = gitBranch;
		}

		public String getManagerPassWordJboss() {
			return managerPassWordJboss;
		}

		public void setManagerPassWordJboss(String managerPassWordJboss) {
			this.managerPassWordJboss = managerPassWordJboss;
		}

		public String getManagerUserNameJboss() {
			return managerUserNameJboss;
		}

		public void setManagerUserNameJboss(String managerUserNameJboss) {
			this.managerUserNameJboss = managerUserNameJboss;
		}

		public String getJbossUrl() {
			return jbossUrl;
		}

		public void setJbossUrl(String jbossUrl) {
			this.jbossUrl = jbossUrl;
		}

		public String getTomcatUsername() {
			return tomcatUsername;
		}

		public void setTomcatUsername(String tomcatUsername) {
			this.tomcatUsername = tomcatUsername;
		}

		public String getTomcatPassword() {
			return tomcatPassword;
		}

		public void setTomcatPassword(String tomcatPassword) {
			this.tomcatPassword = tomcatPassword;
		}

		public String getTomcatUrl() {
			return tomcatUrl;
		}

		public void setTomcatUrl(String tomcatUrl) {
			this.tomcatUrl = tomcatUrl;
		}
		
		
		
	

}
