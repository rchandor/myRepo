package com.capgemini.DevopsEnablerPlatform.windowsSecurity;


import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.ResourceBundle;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;


import org.apache.log4j.Logger;





public class WindowsSecurity {
	public static final int HASH_MAP_ARG_ONE = 5;

	
	public static final float HASH_MAP_ARG_TWO = 0.75f;

	private static org.apache.log4j.Logger log = Logger.getLogger(WindowsSecurity.class);
	public final  boolean checkPassword(final String user, final String password )
			throws RuntimeException, NoSuchFieldException {
		log.fatal("checkPassword Method WindowsSecurity");
		if (password.length() == 0) {
			return false;
		}
		boolean checkFlag = false;
		Map<String, String> map = new HashMap<String, String>();
		ResourceBundle ldapADAttributes = ResourceBundle.getBundle("Ldap");
     
		try {
			map = this.isIGateCorp(ldapADAttributes, user, password);
			
			checkFlag=true;
			
			
			
		} catch (Exception e) {
			
			log.error(e);
			checkFlag=false;
			
			try {
			
			} catch (Exception e1) {
				log.error(e);
				checkFlag = false;
				
			}
		}
return checkFlag;
		
	}

	
	private void checkNTAuthProperty() {
		log.fatal("checkNTAuthProperty Method WindowsSecurity");
		if (System.getProperty("java.security.auth.login.config") == null) {
			System.setProperty("java.security.auth.login.config",
					"ntauth.config");
		}
	}

	@SuppressWarnings("unchecked")
	private Map<String, String> isIGateCorp(ResourceBundle ldapADAttributes,
			final String user, final String password) throws Exception {
		
		
         final String ldapSearchBase = "dc=igatecorp,dc=com";
         Map<String, String> map = new HashMap<String, String>();
		String loginName = user + ldapADAttributes.getString("domainPattern");
		//System.out.println("Login name is +"+loginName);
		//System.out.println("LDAP Atrributes are :"+ldapADAttributes);
		Hashtable env = new Hashtable(HASH_MAP_ARG_ONE, HASH_MAP_ARG_TWO);
	
		DirContext dirCtx = null;
		String ldapCtxFactory = ldapADAttributes.getString("ldapCtxFactory");
		String authentication = ldapADAttributes.getString("authentication");
		String domainController = ldapADAttributes
				.getString("domainController");
		//System.out.println("1:"+ldapCtxFactory);
		//System.out.println("2:"+authentication);
		//System.out.println("3:"+domainController);
		env.put(Context.INITIAL_CONTEXT_FACTORY, ldapCtxFactory);
		env.put(Context.SECURITY_AUTHENTICATION, authentication);
		env.put(Context.SECURITY_PRINCIPAL, loginName);
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.PROVIDER_URL, domainController);
		
		dirCtx = new InitialDirContext(env);
		//System.out.println("Env here is "+env.toString());
		
		
		 
		
		 String searchFilter = "(&(objectClass=user)(sAMAccountName=))";
		 
		 SearchControls searchControls = new SearchControls();
	     searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	     //System.out.println("searchControls returning attributes"+searchControls);
	    // System.out.println("searchControls to String"+searchControls.toString());
	     log.fatal("isIGateCorp (searchControls) Method WindowsSecurity");
	        NamingEnumeration<SearchResult> results = dirCtx.search(ldapSearchBase, searchFilter, searchControls);
	        System.out.println("results are here :"+results);
	        SearchResult searchResult = null;
	       
	        if(results.hasMoreElements()) {
	            searchResult = (SearchResult) results.nextElement();
	           // System.out.println("Search Result Attributes are :"+searchResult.getAttributes());
	            String name=(searchResult.getAttributes().get("name").toString().split(":"))[1];
	            String title=(searchResult.getAttributes().get("title").toString().split(":"))[1];
	            String department=(searchResult.getAttributes().get("department").toString().split(":"))[1];
	            String mobile=(searchResult.getAttributes().get("mobile").toString().split(":"))[1];
	            String streetAddress=(searchResult.getAttributes().get("streetAddress").toString().split(":"))[1];


	            map.put("Name", name);
	            map.put("Title", title);
	            map.put("Department", department);
	            map.put("Mobile", mobile);
	            map.put("StreetAddress", streetAddress);
	            
              	
              	
              	
            	
            	
	            //make sure there is not another item available, there should be only 1 match
	            if(results.hasMoreElements()) {
	                System.err.println("Matched multiple users for the accountName: ");
	               
	            }
	        }
	        log.fatal("isIGateCorp (end) Method WindowsSecurity");
	return map;

}

}
