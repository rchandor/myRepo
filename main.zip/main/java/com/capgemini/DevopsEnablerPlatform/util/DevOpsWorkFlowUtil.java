package com.capgemini.DevopsEnablerPlatform.util;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpMethodBase;
import org.apache.commons.httpclient.HttpURL;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.w3c.dom.Document;

import com.capgemini.DevopsEnablerPlatform.dto.RootJsonDTO;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.YascaJobEntity;
import com.google.gson.Gson;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.*;








public class DevOpsWorkFlowUtil {
	
	private static org.apache.log4j.Logger log = Logger.getLogger(DevOpsWorkFlowUtil.class);
	
	private String jenkinsUsername;
	private static String jenkinsPassword;
	
	public DevOpsWorkFlowUtil(String jenkinsUsername, String jenkinsPassword) {
		super();
		this.jenkinsUsername = jenkinsUsername;
		this.jenkinsPassword = jenkinsPassword;
	}

	public String getJenkinsUsername() {
		return jenkinsUsername;
	}

	public void setJenkinsUsername(String jenkinsUsername) {
		this.jenkinsUsername = jenkinsUsername;
	}

	public String getJenkinsPassword() {
		return jenkinsPassword;
	}

	public void setJenkinsPassword(String jenkinsPassword) {
		this.jenkinsPassword = jenkinsPassword;
	}

	private static String convertDocumentToString(Document doc) {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
           
            return writer.getBuffer().toString();
        } catch (TransformerException e) {
        	log.error(e);
        }
		return jenkinsPassword;
         
       
    }	
	
	public boolean postXML(String jenkinsUrl,Document doc) throws FileNotFoundException{
		
		boolean status = false;
		String docString = null;
		String username = getJenkinsUsername();
		String password = getJenkinsPassword();
		
		try {
		    

		    docString = convertDocumentToString(doc);
		    

		
		String strURL = jenkinsUrl;
		DefaultHttpClient http = new DefaultHttpClient();
		HttpPost post = new HttpPost(strURL);
		UsernamePasswordCredentials creds = new UsernamePasswordCredentials(
		                    username, 
		                    password);
		post.addHeader( BasicScheme.authenticate(creds,"US-ASCII",false) );
		StringEntity entity = new StringEntity( docString );
		entity.setContentType("text/xml");
		post.setEntity( entity );
		org.apache.http.HttpResponse response = http.execute( post );
		
		int result = response.getStatusLine().getStatusCode();
		if(result==200){
			System.out.println(result+"result****");
			status=true;
		}
		
		} catch (Exception e) {
			log.error(e);	
		}
		System.out.println(status+"status***  *");
		return status;
		
	}
	
	public String postURL(String jenkinsUrl) throws IOException{
		
		String username = getJenkinsUsername();
		String password = getJenkinsPassword();
		try {
		String strURL = jenkinsUrl;
		//HttpClient client = new HttpClient();
		DefaultHttpClient http = new DefaultHttpClient();
		HttpPost post = new HttpPost(strURL);
		UsernamePasswordCredentials creds = new UsernamePasswordCredentials(
		                    username, 
		                    password);
		post.addHeader( BasicScheme.authenticate(creds,"US-ASCII",false) );
		post.addHeader("Content-type","application/xml");
		
		org.apache.http.HttpResponse response = http.execute(post);
		
		
		int result = response.getStatusLine().getStatusCode();
		System.out.println("Result is "+result);
		if(result==200||result==201){
			BufferedReader rd = new BufferedReader(
                    new InputStreamReader(response.getEntity().getContent()));
				System.out.println("Buffer read done");
    StringBuffer content = new StringBuffer();
    String line = "";
    while ((line = rd.readLine()) != null) {
    	content.append(line);
    }
    		System.out.println("Content is :"+content);
    		
			return content.toString();
	
			
		}else{
			
			return "error";
		}
		
		} catch (Exception e) {
			log.error(e);	
		}
		
		
		return "error";
	}
	
	
public JSONObject postURLJson(String jenkinsUrl) throws IOException{
		
		String username = "admin";//getJenkinsUsername();
		String password = "admin";//getJenkinsPassword();
		try {
		String strURL = jenkinsUrl;
		//HttpClient client = new HttpClient();
		DefaultHttpClient http = new DefaultHttpClient();
		HttpPost post = new HttpPost(strURL);
		UsernamePasswordCredentials creds = new UsernamePasswordCredentials(
		                    username, 
		                    password);
		post.addHeader( BasicScheme.authenticate(creds,"US-ASCII",false) );
		post.addHeader("Content-type","application/json");
		
		org.apache.http.HttpResponse response = http.execute(post);
		
		
		int result = response.getStatusLine().getStatusCode();
		System.out.println("Result is "+result);
		if(result==200||result==201){
			BufferedReader rd = new BufferedReader(
                    new InputStreamReader(response.getEntity().getContent()));
				System.out.println("Buffer read done");
    StringBuffer content = new StringBuffer();
    String line = "";
    while ((line = rd.readLine()) != null) {
    	content.append(line);
    }
    		System.out.println("Content is :"+content);
    		
    		JSONParser parser = new JSONParser();
    		JSONObject json = (JSONObject) parser.parse(content.toString());
    		 Gson gson = new Gson();        
    		 RootJsonDTO page = gson.fromJson(content.toString(), RootJsonDTO.class);
    		 System.out.println(page.toString());
			return json;
			
	
			
		}else{
			JSONObject newError = new JSONObject();
			//newError.setError(true);
			return newError;
		}
		
		} catch (Exception e) {
			log.error(e);	
		}
		
		JSONObject newError = new JSONObject();
		//newError.setError(true);
		return newError;
	}
	

	
	/**********/
	public BufferedReader postURL3(String jenkinsUrl) throws IOException{
		
		String username = getJenkinsUsername();
		String password = getJenkinsPassword();
		BufferedReader rd = null;
		
		try {
	
		String strURL = jenkinsUrl;
		DefaultHttpClient http = new DefaultHttpClient();
		HttpPost post = new HttpPost(strURL);
		UsernamePasswordCredentials creds = new UsernamePasswordCredentials(
		                    username, 
		                    password);
		post.addHeader( BasicScheme.authenticate(creds,"US-ASCII",false) );
		post.addHeader("Content-type",
			"application/xml");
		org.apache.http.HttpResponse response = http.execute( post );
		
		
		int result = response.getStatusLine().getStatusCode();
		if(result==200||result==201){
			rd = new BufferedReader(
                    new InputStreamReader(response.getEntity().getContent()));

    StringBuffer content = new StringBuffer();
    String line = "";
    
    
    
    
    
    BufferedWriter output = null;
    try {
        File file = new File("C:/Users/nt831459/Desktop/csvTest.txt");
        output = new BufferedWriter(new FileWriter(file));
        while (rd.readLine() != null) {
        output.write(rd.readLine());
        }
    } catch ( IOException e ) {
    	log.error(e);
        
    } finally {
        if ( output != null )
                    try {
                          output.close();
                    } catch (IOException e) {
                    	log.error(e);  
                    }
    }

    
    
    
    
    
    
    
    
    
    
    
    
   
    
    return rd;
			
		}
		
		
		} catch (Exception e) {
			log.error(e);	
		}
		return rd;
		
	}
	
	
	
	
	public boolean postXML2(String jenkinsUrl,String xmlConfig) throws FileNotFoundException{
	boolean status=false;
	String strURL =jenkinsUrl;
	
	
	String strXMLFilename =xmlConfig;
	File input = new File(strXMLFilename);

	PostMethod post = new PostMethod(strURL);

	// Request content will be retrieved directly
	// from the input stream
	// Per default, the request content needs to be buffered
	// in order to determine its length.
	// Request body buffering can be avoided when
	// content length is explicitly specified
	post.setRequestEntity(new InputStreamRequestEntity(new FileInputStream(
			input), input.length()));

	// Specify content type and encoding
	// If content encoding is not explicitly specified
	// ISO-8859-1 is assumed
	post.setRequestHeader("Content-type",
			"application/xml; charset=ISO-8859-1");

	// Get HTTP client
	HttpClient httpclient = new HttpClient();

	// Execute request
	try {

		int result = httpclient.executeMethod(post);

		// Display status code
		
		if(result==200){
			status=true;
		}

		// Display response
		

	} catch (Exception e) {
		log.error(e);
	} finally {

		// Release current connection to the connection pool
		// once you are done
		post.releaseConnection();
	}
	return status;
	}
	
	
	public String postURL2(String jenkinsUrl) throws IOException{
	
	String strURL =jenkinsUrl;
	
	// Get file to be posted
	
	
	
	
	
	// Prepare HTTP post
	PostMethod post= new PostMethod(strURL);

	
	
	
	// Request content will be retrieved directly
	// from the input stream
	// Per default, the request content needs to be buffered
	// in order to determine its length.
	// Request body buffering can be avoided when
	// content length is explicitly specified
	

	// Specify content type and encoding
	// If content encoding is not explicitly specified
	// ISO-8859-1 is assumed
	post.setRequestHeader("Content-type",
			"application/xml; charset=ISO-8859-1");

	// Get HTTP client
	HttpClient httpclient = new HttpClient();
	int result = 0;
	// Execute request
	try {

		result = httpclient.executeMethod(post);

		// Display status code
		

		// Display response
	
	

	} catch (Exception e) {
		log.error(e);
	} finally {

		// Release current connection to the connection pool
		// once you are done
		post.releaseConnection();
	}
	
	if(result==200||result==201){
	
		return post.getResponseBodyAsString();
		
	}else{
		return "error";
	}
	}

	/* Method to encrypt password in deploy Job */
	
	
public boolean postJenkinsUrl(String jenkinsScriptUrl) throws FileNotFoundException{
		
		boolean status = false;
		String username = getJenkinsUsername();
		String password = getJenkinsPassword();
		
		try {		
		String strURL = jenkinsScriptUrl;
		DefaultHttpClient http = new DefaultHttpClient();
		HttpPost post = new HttpPost(strURL);
		UsernamePasswordCredentials creds = new UsernamePasswordCredentials(
		                    username, 
		                    password);
		post.addHeader( BasicScheme.authenticate(creds,"US-ASCII",false) );
		
		org.apache.http.HttpResponse response = http.execute( post );
		
		int result = response.getStatusLine().getStatusCode();
		if(result==200){
			status=true;
		}
		
		} catch (Exception e) {
			log.error(e);	
		}
		return status;
		
	}


 
 public String impersonator(String username) throws IOException{
 	BufferedReader br = null;
	FileReader fr = null;
	String sCurrentLine = null;
	String empid = "";
	String impersonate = "";
	try {

		fr = new FileReader("/home/automation/tomcat_webapplications/devops/config/impersonator.properties");
		br = new BufferedReader(fr);
		//br = new BufferedReader(new FileReader("C://Users//sb843685//workspace//DevOpsWorkFlowSample//config//impersonator.properties"));
		System.out.println(fr);
		int count = 0;
		
		while ((sCurrentLine = br.readLine()) != null) {
			
			if(count == 2){
				break;
			}
			if(count == 1){
				impersonate = empid;
			}
			//System.out.println(sCurrentLine);
			String words[]=sCurrentLine.split("=");
			for(int i = 0;i< words.length;i++){
				empid = words[1];		
			}
			
			//System.out.println(s);
			/*String[] lineVariables = sCurrentLine.equalsIgnoreCase("yes");
			System.out.println(lineVariables);*/
			count++;
		}

	} catch (IOException e) {
		e.printStackTrace();
	}
	System.out.println(impersonate);
	System.out.println(empid);
	/*if(impersonate.equalsIgnoreCase("yes")){
		username = empid;
		System.out.println(username);
	}*/
	return impersonate;
 }
 

 public YascaJobEntity postURL5(String jenkinsUrl, YascaJobEntity yenti) throws IOException{

	//JobBean jobBean=new JobBean();
	
	int warning1=0;
	int high1=0;
	int low1=0;
	int critical1=0;
	int informational1=0;

	int incrementedCritical=0;
	int incrementedHigh=0;
	int incrementedLow=0;
	int incrementedWarning=0;
	int incrementedInformational=0;

	final String critical = "Critical";
	final String high = "High";
	final String low = "Low";
	final String warning = "Warning";
	final String informational = "Informational";

	String username = getJenkinsUsername();
	String password = getJenkinsPassword();
	System.out.println(" username pass"+username+password);
	try {
		System.out.println("jenkinsUrl--"+jenkinsUrl+" username pass"+username+password);  
		String strURL = jenkinsUrl;
		DefaultHttpClient http = new DefaultHttpClient();
		HttpPost post = new HttpPost(strURL);
		UsernamePasswordCredentials creds = new UsernamePasswordCredentials(
				username, 
				password);
		post.addHeader( BasicScheme.authenticate(creds,"US-ASCII",false) );
		post.addHeader("Content-type",
		"application/xml");
		org.apache.http.HttpResponse response = http.execute( post );

		System.out.println("Response Code : " + 
				response.getStatusLine().getStatusCode());
		int result = response.getStatusLine().getStatusCode();
		if(result==200||result==201){
			System.out.println("result in util is---"+result);
			BufferedReader rd = new BufferedReader(
					new InputStreamReader(response.getEntity().getContent()));

			StringBuffer content = new StringBuffer();
			String line = "";

			String lineToString;
			String string;
			String resultString;

			//System.out.println("buffered reader--"+rd.readLine().toString());
			// warning1=StringUtils.countMatches(line.toString(), warning);
			while ((line = rd.readLine()) != null) {
				//str=content.append(line);
				lineToString=line.toString();
				
				line=null;
				//System.out.println("--"+lineToString);

				string = lineToString.replace('"',',');
				resultString = string.replace(",", " ");
				//System.out.println("$$$$$$$$$$$$$$$"+resultString);
				//output.setText( line );

				critical1=StringUtils.
						countMatches(resultString, critical);
				if(critical1==1){
					incrementedCritical++;
				}

				high1=StringUtils.countMatches(resultString, high);
				if(high1==1){
					incrementedHigh++;
				}
				low1=StringUtils.countMatches(resultString, low);
				if(low1==1){
					incrementedLow++;
				}
				warning1=StringUtils.countMatches(resultString, warning);
				if(warning1==1){
					incrementedWarning++;
				} 
				informational1=StringUtils.countMatches(resultString, informational);
				if(informational1==1){
					incrementedInformational++;
				}
				

			}

			String criticalStr=Integer.toString(incrementedCritical);
			String highStr=Integer.toString(incrementedHigh);
			String lowStr=Integer.toString(incrementedLow);
			String warningStr=Integer.toString(incrementedWarning);
			String informationalStr=Integer.toString(incrementedInformational);

			yenti.setSeverityCritical(criticalStr);
			yenti.setSeverityHigh(highStr);
			yenti.setSeverityWarning(warningStr);
			yenti.setSeverityLow(lowStr);
			yenti.setSeverityInformational(informationalStr);



		}


	} catch (Exception e) {
		log.error(e);

	}

	return yenti;
}
}


