package com.capgemini.DevopsEnablerPlatform.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.json.simple.JSONObject;

import com.capgemini.DevopsEnablerPlatform.dto.MeasureValues;
import com.capgemini.DevopsEnablerPlatform.dto.MeasuresDTO;
import com.capgemini.DevopsEnablerPlatform.dto.RootJsonDTO;
import com.google.gson.JsonObject;
public class SearchJson {
	
	public static String searchJson(String testKey, JSONObject rootJsonDTO){
		ArrayList<JSONObject> list = (ArrayList) ((HashMap) rootJsonDTO.get("component")).get("measures");
		for( JSONObject obj :list){
			
			
				if(obj.get("metric").equals(testKey)){
					
					return ""+obj.get("value");
							
				}
			
		}
		
		
		return "ok";
	}

}
