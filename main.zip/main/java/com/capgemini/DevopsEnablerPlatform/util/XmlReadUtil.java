package com.capgemini.DevopsEnablerPlatform.util;


import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.*;
public class XmlReadUtil {
	
	public String readTestXML(String xmlRecords,String rootNode,String node)throws IOException, ParserConfigurationException, SAXException{
		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		InputSource is = new InputSource();
		is.setCharacterStream(new StringReader(xmlRecords));

		Document doc = db.parse(is);
		NodeList nodes = doc.getElementsByTagName(rootNode);

		
		
			Element element = (Element) nodes.item(0);

			NodeList failCount = element.getElementsByTagName(node);
			Element line = (Element) failCount.item(0);
			String count=getCharacterDataFromElement(line);
			
			
			
				

			
			
			
			
           return  count; 
			

	

	}
	
public String readRegressionTestXML(String xmlRecords,String rootNode,String node)throws IOException, ParserConfigurationException, SAXException{
		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		InputSource is = new InputSource();
		is.setCharacterStream(new StringReader(xmlRecords));

		Document doc = db.parse(is);
		NodeList nodes = doc.getElementsByTagName(rootNode);

		
		// iterate the employees
		
			Element element = (Element) nodes.item(0);

			NodeList failCount = element.getElementsByTagName(node);
			Element line = (Element) failCount.item(0);
			String count=getCharacterDataFromElement(line);
			
           return  count; 
			



	}





    public String readSonarXML(String xmlRecords,String childNode)throws IOException, ParserConfigurationException, SAXException{
		System.out.println("Beginning");
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		InputSource is = new InputSource();
		is.setCharacterStream(new StringReader(xmlRecords));
		String count = null;
		System.out.println("Middle");
		Document doc = db.parse(is);
		NodeList nodes = doc.getElementsByTagName("msr");

		System.out.println("msr ending");
		// iterate the employees
		for (int i = 0; i < nodes.getLength(); i++){
			Element element = (Element) nodes.item(i);
			System.out.println("Middle in Iterator"+i);
			NodeList failCount = element.getElementsByTagName("key");
			Element line = (Element) failCount.item(0);
			
			
			if(getCharacterDataFromElement(line).equals(childNode)){
			
			NodeList value = element.getElementsByTagName("frmt_val");
			line = (Element) value.item(0);
			count=getCharacterDataFromElement(line);
		
			}
System.out.println("Ending");
		}
       return count;
	}

	
	

	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return "?";
	}

}
