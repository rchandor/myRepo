package com.capgemini.DevopsEnablerPlatform.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class PropertyUtil {


    public static String getPropValue(String key) {
 
        Properties prop = new Properties();
        String propFileName = "location.properties";
 
        InputStream inputStream;
		try {
			inputStream = PropertyUtil.class.getClassLoader().getResourceAsStream(propFileName);
		System.out.println("done1");
			 prop.load(inputStream);
			 System.out.println("done2");
		} catch (FileNotFoundException e) {
			String ex =com.capgemini.DevopsEnablerPlatform.util.ExceptionUtil.stackTraceToString(e); 
		
		} catch (IOException e) {
			String ex = com.capgemini.DevopsEnablerPlatform.util.ExceptionUtil.stackTraceToString(e); 
			
		}
      
       
        return prop.getProperty(key);
    }
    
  
}
