package com.capgemini.DevopsEnablerPlatform.util;

import org.apache.log4j.Logger;


public class ExceptionUtil {
	private static org.apache.log4j.Logger log = Logger.getLogger(ExceptionUtil.class);
	/*public static void main(String[] args) {
		
		try{
		}catch (Exception e) {
			log.error(e);
		}
	}
*/
	public static String stackTraceToString(Throwable e) {
	    StringBuilder sb = new StringBuilder();
	    for (StackTraceElement element : e.getStackTrace()) {
	        sb.append(element.toString());
	        sb.append("\n");
	    }
	    return sb.toString();

	}
	
}
