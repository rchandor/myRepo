package com.capgemini.DevopsEnablerPlatform.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ImpersonateUtil {
	
	
	 public static String getPropValue(String key) {
		 
	        Properties prop = new Properties();
	        
	        String propFileName = "impersonator.properties";
	 
	        InputStream inputStream;
	        //String inputStream;
			try {
				//inputStream = PropertyUtil.class.getResourceAsStream("C:\\Users\\aishshar\\Documents\\My documents\\DevOpsEnablerPlatform\\devops-operation-microservice\\config\\impersonator.properties").getFile();
				//inputStream = PropertyUtil.class.getResource("\\workspace\\DevOpsWorkFlowSample\\config\\impersonator.properties").getFile());
				inputStream = PropertyUtil.class.getClassLoader().getResourceAsStream(propFileName);
				 prop.load(inputStream);
			} catch (FileNotFoundException e) {
				String ex =com.capgemini.DevopsEnablerPlatform.util.ExceptionUtil.stackTraceToString(e); 
			
			} catch (IOException e) {
				String ex = com.capgemini.DevopsEnablerPlatform.util.ExceptionUtil.stackTraceToString(e); 
				
			}
	      
	       
	        return prop.getProperty(key);
	    }
	    
	  
	}
