package com.capgemini.DevopsEnablerPlatform;




public class EmployeeDetails {
	
	
	private String empId=null;
private String empName=null;
private String user_role=null;
private String createdBy=null;
private String updatedBy=null;
private String is_approved=null;
private int totalEmployees=0;
private String level;
private String  empManager=null;
private String emailAddress=null;

private int approvedEmployees=0;
private int onHoldEmployees=0;
private int rejectedEmployees=0;

public String getEmailAddress() {
	return emailAddress;
}
public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
}
public String getEmpManager() {
	return empManager;
}
public void setEmpManager(String empManager) {
	this.empManager = empManager;
}

public String getLevel() {
	return level;
}
public void setLevel(String level) {
	this.level = level;
}
public String getIs_approved() {
	return is_approved;
}
public void setIs_approved(String is_approved) {
	this.is_approved = is_approved;
}


public int getTotalEmployees() {
	return totalEmployees;
}
public void setTotalEmployees(int totalEmployees) {
	this.totalEmployees = totalEmployees;
}
public int getApprovedEmployees() {
	return approvedEmployees;
}
public void setApprovedEmployees(int approvedEmployees) {
	this.approvedEmployees = approvedEmployees;
}
public int getOnHoldEmployees() {
	return onHoldEmployees;
}
public void setOnHoldEmployees(int onHoldEmployees) {
	this.onHoldEmployees = onHoldEmployees;
}
public int getRejectedEmployees() {
	return rejectedEmployees;
}
public void setRejectedEmployees(int rejectedEmployees) {
	this.rejectedEmployees = rejectedEmployees;
}
public String getEmpId() {
	return empId;
}
public void setEmpId(String empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getUser_role() {
	return user_role;
}
public void setUser_role(String user_role) {
	this.user_role = user_role;
}
public String getCreatedBy() {
	return createdBy;
}
public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}
public String getUpdatedBy() {
	return updatedBy;
}
public void setUpdatedBy(String updatedBy) {
	this.updatedBy = updatedBy;
}
	

}
