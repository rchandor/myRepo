package com.capgemini.DevopsEnablerPlatform.serviceImpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.capgemini.DevopsEnablerPlatform.dto.CodeQualityJobDTO;
import com.capgemini.DevopsEnablerPlatform.dto.MessageDTO;
import com.capgemini.DevopsEnablerPlatform.dto.RootJsonDTO;
import com.capgemini.DevopsEnablerPlatform.dto.YascaJobDTO;
import com.capgemini.DevopsEnablerPlatform.repository.ICheckMarxJobRepository;
import com.capgemini.DevopsEnablerPlatform.repository.ICodeQualityJobRepository;
import com.capgemini.DevopsEnablerPlatform.repository.IDeployChefJobRepository;
import com.capgemini.DevopsEnablerPlatform.repository.IDeployCloudFoundryJobRepository;
import com.capgemini.DevopsEnablerPlatform.repository.IDeployJenkinsJobRepository;
import com.capgemini.DevopsEnablerPlatform.repository.IEmployeeDetailsRepository;
import com.capgemini.DevopsEnablerPlatform.repository.IJobRepository;
import com.capgemini.DevopsEnablerPlatform.repository.IPerformanceJobRepository;
import com.capgemini.DevopsEnablerPlatform.repository.IProjectDetailsRepository;
import com.capgemini.DevopsEnablerPlatform.repository.IRegressionJobRepository;
import com.capgemini.DevopsEnablerPlatform.repository.ISahiJobRepository;
import com.capgemini.DevopsEnablerPlatform.repository.ISoapUiJobRepository;
import com.capgemini.DevopsEnablerPlatform.repository.IWorkflowMasterRepository;
import com.capgemini.DevopsEnablerPlatform.repository.IYascaJobRepository;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.CheckMarxJobentity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.CodeQualityJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.DeployChefJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.DeployCloudFoundryJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.DeployJenkinsJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.EmployeeDetailsEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.JobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.PerformanceJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.ProjectInformationEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.RegressionJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.SahiJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.SoapUiJobEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.WorkflowMasterEntity;
import com.capgemini.DevopsEnablerPlatform.reusable.entity.YascaJobEntity;
import com.capgemini.DevopsEnablerPlatform.service.IJobService;
import com.capgemini.DevopsEnablerPlatform.util.DevOpsWorkFlowUtil;
import com.capgemini.DevopsEnablerPlatform.util.PropertyUtil;
import com.capgemini.DevopsEnablerPlatform.util.SearchJson;
import com.capgemini.DevopsEnablerPlatform.util.XmlReadUtil;
import com.google.gson.JsonArray;



@Service
@Transactional
public class JobServiceImpl implements IJobService {
       private static final String selectSQLIsTCGUser = "select group_id from access_control where employee_id=?";
	private static final String ManagerUserName = null;
	private static final String ManagerPassWord = null;
       private EntityManager entityManager;
       private Connection conn = null;

       private static org.apache.log4j.Logger log = Logger.getLogger(JobServiceImpl.class);

       private PreparedStatement statement = null;

       private java.sql.ResultSet resultSet = null;

       PerformanceJobEntity pEntity= new PerformanceJobEntity();
       
       @Autowired
    IJobRepository jobRepo;
    @Autowired
    IEmployeeDetailsRepository empRepo;
    @Autowired
    ICodeQualityJobRepository cRepo;
    @Autowired
    IWorkflowMasterRepository wRepo;
    @Autowired
    IYascaJobRepository yRepo;
    @Autowired
    IRegressionJobRepository rRepo;
    @Autowired
    IProjectDetailsRepository pRepo;
    @Autowired
    ICheckMarxJobRepository cmRepo;
    @Autowired
    IDeployChefJobRepository dcRepo;
    @Autowired
       ICheckMarxJobRepository chRepo; 
    @Autowired
    IDeployCloudFoundryJobRepository dcfRepo;
    
    @Autowired
    IDeployJenkinsJobRepository djRepo;
    @Autowired
    IPerformanceJobRepository perRepo;
    
    @Autowired
    ISahiJobRepository sRepo;
    
    @Autowired
    ISoapUiJobRepository suiRepo;


       MessageDTO messageDTO = new MessageDTO();
       JobEntity incidentEntity = new JobEntity();
       CodeQualityJobEntity newCodeQualityEntity = new CodeQualityJobEntity();
       CheckMarxJobentity chekcEntity = new CheckMarxJobentity();
       EmployeeDetailsEntity empentity = new EmployeeDetailsEntity();
       ProjectInformationEntity pentity=new ProjectInformationEntity();
       @Override
       public void saveEmployeeInformation(String username, String password) throws ClassNotFoundException, SQLException {

              /**/

              // System.out.println("a="+a+",b="+employeeId+",c="+empFirstName+",d="+empLastName+",e="+emailId+",f="+location+",g="+country+",h="+role);
              // System.out.println("emailId="+emailId+",i="+i+",j="+projectName+
              // ",k="+k+",l="+l+",m="+managerName+",n="+n+
              // ",o="+o);
              // empentity.setEmpID(employeeId);
              empentity.setEmpID(username);
              // empRepo.save(empentity);
              // employeeDetails.setEmpId(employeeId);
              // employeeDetails.setEmpName(rs.getString(3)+" "+rs.getString(4));
              // employeeDetails.setUser_role(role);
              // employeeDetails.setLevel(rs.getString(15));
              // employeeDetails.setEmpManager(rs.getString(13));
              // employeeDetails.setEmailAddress(rs.getString(5));

              empRepo.save(empentity);

              // EmployeeDetailsEntity empDetailEntity= new EmployeeDetailsEntity();

       }

       @SuppressWarnings("null")
       @Override
       public MessageDTO createJob(JSONObject jsonObject) {
              boolean status = false;
              MessageDTO response = new MessageDTO();
              // For general applications
              if (jsonObject != null) {

                     IJobService service = null;
                     if ("general".equalsIgnoreCase(jsonObject.get("applicationType").toString())) {

                          
                                  if ("Angular".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                         if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                                response = submitNewBatchJob1(jsonObject);

                                         }
                                         if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewYascaJob(jsonObject);

                                         }
                                         if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewCheckmarx(jsonObject);

                                         }

                                         if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitDeploy(jsonObject);

                                         }
                                         if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = createDeployChefJob(jsonObject);

                                         }
                                         if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitDeployCfJob(jsonObject);

                                         }
                                         if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewPerformanceJob(jsonObject);

                                         }

                                         if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewRegressionJob(jsonObject);

                                         }
                                  } else if ("Polymer".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                         if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                                response = submitNewBatchJob1(jsonObject);

                                         }
                                         if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewYascaJob(jsonObject);

                                         }
                                         if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewCheckmarx(jsonObject);

                                         }

                                         if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitDeploy(jsonObject);

                                         }
                                         if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = createDeployChefJob(jsonObject);

                                         }
                                         if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitDeployCfJob(jsonObject);

                                         }
                                         if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewPerformanceJob(jsonObject);

                                         }

                                         if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewRegressionJob(jsonObject);

                                         }
                                  } else if ("Node".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                         if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                                response = submitNewBatchJob1(jsonObject);
                                                if ("build".equalsIgnoreCase((String) jsonObject.get("buildStatus"))) {
                                                       buildJob(jsonObject);
                                                }

                                         }
                                         if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewYascaJob(jsonObject);

                                         }
                                         if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewCheckmarx(jsonObject);

                                         }

                                         if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitDeploy(jsonObject);

                                         }
                                         if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = createDeployChefJob(jsonObject);

                                         }
                                         if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitDeployCfJob(jsonObject);

                                         }
                                         if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewPerformanceJob(jsonObject);

                                         }

                                         if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewRegressionJob(jsonObject);

                                         }
                                  } else if ("Java".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                	  
                                	  		/*if("Java".equalsIgnoreCase(jsonObject.get("codeBase").toString()))
                                	  		{
                                	  			
                                	  		}*/

                                         if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                                response = submitNewBatchJob1(jsonObject);
                                                if ("build".equalsIgnoreCase((String) jsonObject.get("buildStatus"))) {
                                                       buildJob(jsonObject);
                                                }

                                         }
                                         if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewYascaJob(jsonObject);

                                         }
                                         if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewCheckmarx(jsonObject);

                                         }

                                         if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitDeploy(jsonObject);

                                         }
                                         if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = createDeployChefJob(jsonObject);

                                         }
                                         if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitDeployCfJob(jsonObject);

                                         }
                                         if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewPerformanceJob(jsonObject);

                                         }

                                         if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                                response = submitNewRegressionJob(jsonObject);

                                         }
                                  }
                           
                     }

                     else if ("Standalone".equalsIgnoreCase(jsonObject.get("applicationType").toString())) {

                         
                         if ("Angular".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                       response = submitNewBatchJob1(jsonObject);

                                }
                                if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewYascaJob(jsonObject);

                                }
                                if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewCheckmarx(jsonObject);

                                }

                                if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeploy(jsonObject);

                                }
                                if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = createDeployChefJob(jsonObject);

                                }
                                if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeployCfJob(jsonObject);

                                }
                                if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewPerformanceJob(jsonObject);

                                }

                                if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewRegressionJob(jsonObject);

                                }
                         } else if ("Polymer".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                       response = submitNewBatchJob1(jsonObject);

                                }
                                if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewYascaJob(jsonObject);

                                }
                                if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewCheckmarx(jsonObject);

                                }

                                if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeploy(jsonObject);

                                }
                                if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = createDeployChefJob(jsonObject);

                                }
                                if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeployCfJob(jsonObject);

                                }
                                if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewPerformanceJob(jsonObject);

                                }

                                if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewRegressionJob(jsonObject);

                                }
                         } else if ("Node".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                       response = submitNewBatchJob1(jsonObject);
                                       if ("build".equalsIgnoreCase((String) jsonObject.get("buildStatus"))) {
                                              buildJob(jsonObject);
                                       }

                                }
                                if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewYascaJob(jsonObject);

                                }
                                if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewCheckmarx(jsonObject);

                                }

                                if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeploy(jsonObject);

                                }
                                if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = createDeployChefJob(jsonObject);

                                }
                                if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeployCfJob(jsonObject);

                                }
                                if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewPerformanceJob(jsonObject);

                                }

                                if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewRegressionJob(jsonObject);

                                }
                         } else if ("Java".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                       	  
                       	  		/*if("Java".equalsIgnoreCase(jsonObject.get("codeBase").toString()))
                       	  		{
                       	  			
                       	  		}*/

                                if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                       response = submitNewBatchJob1(jsonObject);
                                       if ("build".equalsIgnoreCase((String) jsonObject.get("buildStatus"))) {
                                              buildJob(jsonObject);
                                       }

                                }
                                if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewYascaJob(jsonObject);

                                }
                                if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewCheckmarx(jsonObject);

                                }

                                if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeploy(jsonObject);

                                }
                                if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = createDeployChefJob(jsonObject);

                                }
                                if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeployCfJob(jsonObject);

                                }
                                if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewPerformanceJob(jsonObject);

                                }

                                if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewRegressionJob(jsonObject);

                                }
                         }
                  
            }

                     else {

                         
                         if ("Angular".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                       response = submitNewBatchJob1(jsonObject);

                                }
                                if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewYascaJob(jsonObject);

                                }
                                if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewCheckmarx(jsonObject);

                                }

                                if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeploy(jsonObject);

                                }
                                if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = createDeployChefJob(jsonObject);

                                }
                                if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeployCfJob(jsonObject);

                                }
                                if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewPerformanceJob(jsonObject);

                                }

                                if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewRegressionJob(jsonObject);

                                }
                         } else if ("Polymer".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                       response = submitNewBatchJob1(jsonObject);

                                }
                                if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewYascaJob(jsonObject);

                                }
                                if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewCheckmarx(jsonObject);

                                }

                                if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeploy(jsonObject);

                                }
                                if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = createDeployChefJob(jsonObject);

                                }
                                if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeployCfJob(jsonObject);

                                }
                                if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewPerformanceJob(jsonObject);

                                }

                                if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewRegressionJob(jsonObject);

                                }
                         } else if ("Node".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                       response = submitNewBatchJob1(jsonObject);
                                       if ("build".equalsIgnoreCase((String) jsonObject.get("buildStatus"))) {
                                              buildJob(jsonObject);
                                       }

                                }
                                if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewYascaJob(jsonObject);

                                }
                                if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewCheckmarx(jsonObject);

                                }

                                if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeploy(jsonObject);

                                }
                                if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = createDeployChefJob(jsonObject);

                                }
                                if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeployCfJob(jsonObject);

                                }
                                if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewPerformanceJob(jsonObject);

                                }

                                if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewRegressionJob(jsonObject);

                                }
                         } else if ("Java".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                       	  
                       	  		/*if("Java".equalsIgnoreCase(jsonObject.get("codeBase").toString()))
                       	  		{
                       	  			
                       	  		}*/

                                if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                       response = submitNewBatchJob1(jsonObject);
                                       if ("build".equalsIgnoreCase((String) jsonObject.get("buildStatus"))) {
                                              buildJob(jsonObject);
                                       }

                                }
                                if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewYascaJob(jsonObject);

                                }
                                if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewCheckmarx(jsonObject);

                                }

                                if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeploy(jsonObject);

                                }
                                if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = createDeployChefJob(jsonObject);

                                }
                                if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitDeployCfJob(jsonObject);

                                }
                                if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewPerformanceJob(jsonObject);

                                }

                                if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                       response = submitNewRegressionJob(jsonObject);

                                }
                         }
                  
            }
                     if (!response.equals("null")) {
                           if ("Batch".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                  status = true;
                                  // jobEntity.setCurrentState("Batch job");
                           } else {
                                  status = true;
                           }
                     } else {
                           status = false;
                     }
                     // For microservices
                     if ("microservices".equalsIgnoreCase(jsonObject.get("applicationType").toString()))

                     {

                           if ("Java".equalsIgnoreCase(jsonObject.get("projectType").toString())) {

                                  if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                         response = submitNewMicroserviceJob(jsonObject);
                                         if ("build".equalsIgnoreCase((String) jsonObject.get("buildStatus"))) {
                                                buildJob(jsonObject);
                                         }

                                  }
                                  if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewYascaJob(jsonObject);

                                  }
                                  if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewCheckmarx(jsonObject);

                                  }

                                  if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitDeploy(jsonObject);

                                  }
                                  if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = createDeployChefJob(jsonObject);

                                  }
                                  if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitDeployCfJob(jsonObject);

                                  }
                                  if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewPerformanceJob(jsonObject);

                                  }

                                  if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewRegressionJob(jsonObject);

                                  }
                                  response.setMsg("successsssss");
                           }
                           if ("Node".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                  if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                         response = submitNewMicroserviceJob(jsonObject);
                                         if ("build".equalsIgnoreCase((String) jsonObject.get("buildStatus"))) {
                                                buildJob(jsonObject);
                                         }

                                  }
                                  if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewYascaJob(jsonObject);

                                  }
                                  if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewCheckmarx(jsonObject);

                                  }

                                  if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitDeploy(jsonObject);

                                  }
                                  if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = createDeployChefJob(jsonObject);

                                  }
                                  if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitDeployCfJob(jsonObject);

                                  }
                                  if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewPerformanceJob(jsonObject);

                                  }

                                  if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewRegressionJob(jsonObject);

                                  }

                                  response.setMsg("successsssss");
                           } else {
                                  if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                                         response = submitNewMicroserviceJob(jsonObject);
                                         if ("build".equalsIgnoreCase((String) jsonObject.get("buildStatus"))) {
                                                buildJob(jsonObject);
                                         }

                                  }
                                  if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewYascaJob(jsonObject);

                                  }
                                  if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewCheckmarx(jsonObject);

                                  }

                                  if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitDeploy(jsonObject);

                                  }
                                  if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = createDeployChefJob(jsonObject);

                                  }
                                  if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitDeployCfJob(jsonObject);

                                  }
                                  if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewPerformanceJob(jsonObject);

                                  }

                                  if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                                         response = submitNewRegressionJob(jsonObject);

                                  }

                                  response.setMsg("successsssss");
                           }

                           if (!response.equals("null")) {
                                  if ("Batch".equalsIgnoreCase(jsonObject.get("projectType").toString())) {
                                         status = true;
                                         // jobEntity.setCurrentState("Batch job");
                                  } else {
                                         status = true;
                                  }
                           } else {
                                  status = false;
                           }
                     }
              }
              return response;

       }

       public MessageDTO createDeployChefJob(JSONObject jsonObject) {
              boolean status = false;
              JobEntity incidentEntity = new JobEntity();
            
              JSONObject jobj = new JSONObject();
              // String incidentId1 = (String) ((HashMap)
              // jsonObject.get("JobDetails")).get("jobId");

              // System.out.println("Aish"+incidentId1);
              // int job_id= Integer.parseInt(incidentId1);
            DeployChefJobEntity deploych=new DeployChefJobEntity();

              String stg = (String) jsonObject.get("Stage");
              
              // incidentEntity.setJobId(job_id);
              String jenkinsusername = null;
              String jenkinspassword = null;
              String sourcecode=null;
              String svnURL = null;
              String module = null;
              String cvsRoot = null;
              String cvsPassword = null;
              String branchName = null;
              String tagName = null;
              String remoteName = null;
              String localName = null;
              String locationType = null;
              String gitURL =null;
              String gitBranch = null;
              String projectBranch = null;
			  
			  String jobName=(String)jsonObject.get("jobName");
              JobEntity deploychefjob=jobRepo.findByAppName1(jobName);
              jenkinsusername=deploychefjob.getJenkinsUsername();
              jenkinspassword=deploychefjob.getJenkinsPassword();
              sourcecode=deploychefjob.getCodeBase();
              svnURL = deploychefjob.getSvnUrl();
              module = deploychefjob.getLocalModuleDirectory();
              cvsRoot = deploychefjob.getCvsRoot();
              cvsPassword = deploychefjob.getCvsPassword();
              branchName = deploychefjob.getBranchLocationName();
              tagName = deploychefjob.getTagLocationName();
              remoteName = deploychefjob.getRemoteName();
              localName = deploychefjob.getLocalName();
              locationType = deploychefjob.getCvsLocation();
              gitURL =deploychefjob.getGitUrl();
              gitBranch = deploychefjob.getGitBranch();
              projectBranch = deploychefjob.getProjectPathBranch();
              long idd=deploychefjob.getJobId();
			  deploychefjob.setCurrentState(stg);
			  deploychefjob.setStage(stg);
			  deploych.setDeployJobIdChef(idd);
			  deploych.setJobName(jobName);
			  deploych.setJobEntity(deploychefjob);
			  deploych.setEmpId(1);
			  
			  
              if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Deploy$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(jobName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setJobName(jobName.split("_DeployChef", 2)[0]);
                           jobName = incidentEntity.getJobName();

                     } else {
                           String suffix = "_DeployChef";

                           String jobNameNew = jobName.concat(suffix);
                           incidentEntity.setJobName(jobNameNew);
                           jobName = incidentEntity.getJobName();// addition of
                                                                                                              // suffix in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              System.out.println("in  dao submit fn^^^^^^^^^^");
              try {
                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jenkinsusername,
                                  jenkinspassword);
                     String managerUserName = null;
                     String managerPassWord = null;
                     String url = (String) jsonObject.get("UrlDeploy");
                    
                    
                     
                     String temp[];
                     String temp1[];
                     String[] temp2;
                     String[] temp3;
                     String[] temp4;
                     String[] temp5;
                     String[] temp6;
                     String war = (String) jsonObject.get("WarFilePath");
                     String contextPath = (String) jsonObject.get("ContextPath");
                     String delimiter = "\\,";

                     String strXMLFilenameMaven = null;

                     if ((sourcecode).equalsIgnoreCase("SVN")) {

                           System.out.println("in svn");
                           if ("tomcat".equalsIgnoreCase((String) jsonObject.get("DeploySeverType"))) {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployChef");
                                  managerUserName = (String) jsonObject.get("ManagerUserName");
                                  managerPassWord = (String) jsonObject.get("ManagerPassWord");
                                  url = (String) jsonObject.get("UrlDeploy");
                                  deploych.setManagerUserNameChef(managerUserName);
                                  deploych.setManagerPassWordChef(managerPassWord);
                                  deploych.setTomCatUrlChef(url);
                           } else {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployChefJboss");
                                  managerUserName = (String) jsonObject.get("ManagerUserNameJboss");
                                  managerPassWord = (String) jsonObject.get("ManagerPassWordJboss");
                                  url = (String) jsonObject.get("JbossUrl");
                                  deploych.setManagerUserNameJbossChef(managerUserName);
                                  deploych.setManagerPassWordJbossChef(managerPassWord);
                                  deploych.setTomCatUrlChef(url);

                           }
                     } else if ("CVS".equalsIgnoreCase(sourcecode)) {
                           if ("tomcat".equalsIgnoreCase((String) jsonObject.get("DeploySeverType"))) {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployChefCVS");
                                  managerUserName = (String) jsonObject.get("ManagerUserName");
                                  managerPassWord = (String) jsonObject.get("ManagerPassWord");
                                  url = (String) jsonObject.get("tomcatUrl");
                                  deploych.setManagerUserNameChef(managerUserName);
                                  deploych.setManagerPassWordChef(managerPassWord);
                                  deploych.setTomCatUrlChef(url);
                           } else {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployChefJbossCVS");
                                  managerUserName = (String) jsonObject.get("ManagerUserNameJboss");
                                  managerPassWord = (String) jsonObject.get("ManagerPassWordJboss");
                                  url = (String) jsonObject.get("JbossUrl");
                                  deploych.setManagerUserNameJbossChef(managerUserName);
                                  deploych.setManagerPassWordJbossChef(managerPassWord);
                                  deploych.setTomCatUrlChef(url);

                           }
                     } else if ("GIT".equalsIgnoreCase(sourcecode)) {
                           if ("tomcat".equalsIgnoreCase((String) jsonObject.get("DeploySeverType"))) {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployChefGIT");
                                  managerUserName = (String) jsonObject.get("ManagerUserName");
                                  managerPassWord = (String) jsonObject.get("ManagerPassWord");
                                  url = (String) jsonObject.get("tomcatUrl");
                                  deploych.setManagerUserNameChef(managerUserName);
                                  deploych.setManagerPassWordChef(managerPassWord);
                                  deploych.setTomCatUrlChef(url);
                           } else {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployChefJbossGIT");
                                  managerUserName = (String) jsonObject.get("ManagerUserNameJboss");
                                  managerPassWord = (String) jsonObject.get("ManagerPassWordJboss");
                                  url = (String) jsonObject.get("JbossUrl");
                                  deploych.setManagerUserNameJbossChef(managerUserName);
                                  deploych.setManagerPassWordJbossChef(managerPassWord);
                                  deploych.setTomCatUrlChef(url);
                           }
                     }
                     
                     File xmlFile = new File(strXMLFilenameMaven);

                     DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                     DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                     Document doc = dBuilder.parse(xmlFile);

                     NodeList permissionList = doc.getElementsByTagName("permission");
                     Node workspacePermission = permissionList.item(0);
                     workspacePermission.setTextContent("hudson.model.Item.Workspace:" + jsonObject.get("JenkinsUsername"));
                     Node buildPermission = permissionList.item(1);
                     buildPermission.setTextContent("hudson.model.Item.Build:" + jsonObject.get("JenkinsUsername"));
                     Node updatePermission = permissionList.item(2);
                     updatePermission.setTextContent("hudson.model.Run.Update:" + jsonObject.get("JenkinsUsername"));
                     Node readPermission = permissionList.item(3);
                     readPermission.setTextContent("hudson.model.Item.Read:" + jsonObject.get("JenkinsUsername"));
                     Node tagPermission = permissionList.item(4);
                     tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jsonObject.get("JenkinsUsername"));
                     Node configurePermission = permissionList.item(5);
                     configurePermission.setTextContent("hudson.model.Item.Configure:" + jsonObject.get("JenkinsUsername"));
                     Node discoverPermission = permissionList.item(6);
                     discoverPermission.setTextContent("hudson.model.Item.Discover:" + jsonObject.get("JenkinsUsername"));

                     if ("SVN".equalsIgnoreCase(sourcecode)) {
                           
                           NodeList nodeListLocation = doc.getElementsByTagName("locations");
                           Node nodeLoc = nodeListLocation.item(0);
                           Element locations = (Element) nodeLoc;

                           if (!url.isEmpty()) {
                                  temp = url.split(delimiter);
                                  temp1 = module.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {

                                         Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                         locations.appendChild(moduleNode);
                                         Element remoteNode = doc.createElement("remote");
                                         remoteNode.setTextContent(temp[i]);
                                         moduleNode.appendChild(remoteNode);
                                         Element local = doc.createElement("local");
                                         local.setTextContent(temp1[i]);
                                         moduleNode.appendChild(local);
                                         Element depth = doc.createElement("depthOption");
                                         depth.setTextContent("infinity");
                                         moduleNode.appendChild(depth);
                                         Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                         ignoreExternalsOption.setTextContent("false");
                                         moduleNode.appendChild(ignoreExternalsOption);
                                  }
                           }
                     } else if ("CVS".equalsIgnoreCase(sourcecode)) {
                           
                           NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                           Node nodeRepositories = nodeListRepositories.item(0);
                           Element repositories = (Element) nodeRepositories;

                           if (!cvsRoot.isEmpty()) {
                                  temp = cvsRoot.split(delimiter);
                                  temp1 = cvsPassword.split(delimiter);
                                  temp2 = branchName.split(delimiter);
                                  temp3 = remoteName.split(delimiter);
                                  temp4 = localName.split(delimiter);
                                  temp5 = locationType.split(delimiter);
                                  temp6 = tagName.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {

                                         Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                         repositories.appendChild(cvsRepository);

                                         Element cvsRootXml = doc.createElement("cvsRoot");
                                         cvsRootXml.setTextContent(temp[i]);
                                         cvsRepository.appendChild(cvsRootXml);

                                         Element repositoryItems = doc.createElement("repositoryItems");
                                         cvsRepository.appendChild(repositoryItems);

                                         Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                         repositoryItems.appendChild(cvsRepositoryItem);

                                         Element modules = doc.createElement("modules");
                                         cvsRepositoryItem.appendChild(modules);

                                         Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                         modules.appendChild(cvsModule);

                                         Element localName1 = doc.createElement("localName");
                                         localName1.setTextContent(temp4[i]);
                                         cvsModule.appendChild(localName1);

                                         Element remoteName1 = doc.createElement("remoteName");
                                         remoteName1.setTextContent(temp3[i]);
                                         cvsModule.appendChild(remoteName1);

                                         Element location = doc.createElement("location");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                         }
                                         if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                         }
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                         }
                                         cvsRepositoryItem.appendChild(location);

                                         Element locationType1 = doc.createElement("locationType");
                                         locationType1.setTextContent(temp5[i]);
                                         location.appendChild(locationType1);

                                         Element locationName1 = doc.createElement("locationName");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp2[i]);
                                         } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp6[i]);
                                         }
                                         location.appendChild(locationName1);

                                         Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                useHeadIfNotFound.setTextContent("false");
                                         } else {
                                                useHeadIfNotFound.setTextContent("true");
                                         }
                                         location.appendChild(useHeadIfNotFound);

                                         Element compressionLevel = doc.createElement("compressionLevel");
                                         compressionLevel.setTextContent("-1");
                                         cvsRepository.appendChild(compressionLevel);

                                         Element excludedRegions = doc.createElement("excludedRegions");
                                         cvsRepository.appendChild(excludedRegions);

                                         Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                         excludedRegions.appendChild(excludedRegion);

                                         Element pattern = doc.createElement("pattern");
                                         excludedRegion.appendChild(pattern);

                                         Element cvsPassword1 = doc.createElement("password");
                                         cvsPassword1.setTextContent(temp1[i]);
                                         cvsRepository.appendChild(cvsPassword1);

                                         Element passwordRequired = doc.createElement("passwordRequired");
                                         passwordRequired.setTextContent("true");
                                         cvsRepository.appendChild(passwordRequired);

                                  }
                           }
                     }

                     else if ("GIT".equalsIgnoreCase(sourcecode)) {

                           NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                           Node nodeRepositories11 = nodeListRepositories11.item(0);
                           Element userRemoteConfigs = (Element) nodeRepositories11;

                           if (!gitURL.isEmpty()) {

                                  temp = gitURL.split(delimiter);
                                  temp1 = gitBranch.split(delimiter);
                                  temp2 = projectBranch.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                         userRemoteConfigs.appendChild(moduleNode11);

                                         Element remoteNode11 = doc.createElement("url");
                                         remoteNode11.setTextContent(temp[i]);
                                         moduleNode11.appendChild(remoteNode11);

                                         NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                         Node nodeRepositories13 = nodeListRepositories13.item(0);
                                         Element branches = (Element) nodeRepositories13;

                                         Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                         branches.appendChild(moduleNode12);

                                         Element remoteNode12 = doc.createElement("name");
                                         remoteNode12.setTextContent(temp1[i]);
                                         moduleNode12.appendChild(remoteNode12);

                                         if (projectBranch.equalsIgnoreCase(",")) {

                                                Element element = (Element) doc
                                                              .getElementsByTagName("hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                                              .item(0);

                                                Node parent = element.getParentNode();

                                                parent.removeChild(element);

                                                parent.normalize();

                                         } else {
                                                NodeList nodeListRepositories12 = doc.getElementsByTagName("sparseCheckoutPaths");
                                                Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                Element moduleNode13 = doc
                                                              .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                sparseCheckoutPaths.appendChild(moduleNode13);
                                                Element nodeListRepositories22 = doc.createElement("path");
                                                nodeListRepositories22.setTextContent(temp2[i]);
                                                moduleNode13.appendChild(nodeListRepositories22);
                                         }
                                  }
                           }
                     }

                     NodeList nodeListTest = doc.getElementsByTagName("userName");
                     Node nodeName = nodeListTest.item(0);
                     Element projectName1 = (Element) nodeName;
                     projectName1.setTextContent(managerUserName);

                     NodeList nodeListTeam = doc.getElementsByTagName("passwordScrambled");
                     Node nodeTeam = nodeListTeam.item(0);
                     Element team = (Element) nodeTeam;

                     // encryptedPassword = workFlowUtil.scramble(managerPassWord);

                     // team.setTextContent(encryptedPassword);

                     NodeList nodeListPreset = doc.getElementsByTagName("war");
                     Node nodePreset = nodeListPreset.item(0);
                     Element preset = (Element) nodePreset;
                     preset.setTextContent(war);

                     NodeList nodeListConfig = doc.getElementsByTagName("contextPath");
                     Node nodeConfig = nodeListConfig.item(0);
                     Element config = (Element) nodeConfig;
                     config.setTextContent(contextPath);

                     NodeList nodeListTomcat = doc.getElementsByTagName("url");
                     Node nodetomcat = nodeListTomcat.item(nodeListTomcat.getLength() - 1);

                     Element tomcat = (Element) nodetomcat;
                     tomcat.setTextContent(url);

                     String strURL1 = PropertyUtil.getPropValue("jenkinsUrl");
                     String strURL = strURL1.concat(jobName);

                     /*
                     * NodeList nodeListsiteName = doc.getElementsByTagName("siteName");
                     * 
                      * Node nodesn = nodeListsiteName.item(0); Element
                     * defaultValueNodesn = (Element) nodesn;
                     * 
                      * defaultValueNodesn .setTextContent("vv817839@3.209.30.155:22");
                     */

                     NodeList nodeList = doc.getElementsByTagName("command");

                     Node node = nodeList.item(0);
                     Element defaultValueNode = (Element) node;

                     defaultValueNode.setTextContent("cp -r /home/automation/jenkins/jenkins_production/.jenkins/jobs/"
                                  + sourcecode + "/workspace/" + jsonObject.get("ContextPath") + "/build/artifacts/war/"
                                  + jsonObject.get("WarFilePath") + " /home/automation/warfiles");

                     Node node1 = nodeList.item(0);
                     Element defaultValueNode1 = (Element) node1;

                     /*
                     * defaultValueNode1
                     * .setTextContent("cd /home/automation/chef_repo/chef-repo/cookbooks sudo knife cookbook upload devops_cookbook sudo knife bootstrap 3.209.30.155 -x vv817839 -P Igate@12 --sudo -N node155 --run-list 'recipe[devops_cookbook]' --node-ssl-verify-mode none"
                     * );
                     */
                     status = workFlowUtil.postXML(strURL, doc);

              } catch (FileNotFoundException e) {
                     e.printStackTrace();
              } catch (IOException e) {
                     e.printStackTrace();

              } catch (ParserConfigurationException e) {
                     e.printStackTrace();
              } catch (SAXException e) {
                     e.printStackTrace();
              }
              dcRepo.save(deploych);
              jobRepo.save(deploychefjob);
              return messageDTO;
              
       }

       @Override
       
       public MessageDTO submitNewBatchJob1(JSONObject jsonObject) {
              JobEntity incidentEntity = new JobEntity();
              WorkflowMasterEntity wentity = null;
              CodeQualityJobEntity codeQualityentity=new CodeQualityJobEntity();
              JSONObject jobj = new JSONObject();
              // String incidentId1 = (String) ((HashMap)
              // jsonObject.get("JobDetails")).get("jobId");
              ProjectInformationEntity pentity=new ProjectInformationEntity();
              // System.out.println("Aish"+incidentId1);
              // int job_id= Integer.parseInt(incidentId1);
              incidentEntity = new JobEntity();
              wentity = new WorkflowMasterEntity();
              incidentEntity.setUserName("aishshar");
              String stg = (String) jsonObject.get("Stage");
              incidentEntity.setStage(stg);
              // incidentEntity.setJobId(job_id);
              boolean status = false;
              String jobName= jsonObject.get("jobName").toString();
              //String xmlPath= jsonObject.get("xml").toString();
              String projectId = jsonObject.get("ProjectId").toString();
              String applicationName = jsonObject.get("applicationName").toString();
              String applicationType = jsonObject.get("applicationType").toString();
              String projectName = jsonObject.get("ProjectName").toString();
              String projectType = jsonObject.get("projectType").toString();
              MessageDTO response = new MessageDTO();
              String pro = jsonObject.get("ProjectType").toString();
              String releaseDate = jsonObject.get("releaseDate").toString();
              // incidentEntity.setApplicationName(applicationName);
              incidentEntity.setApplicationType(applicationType);
              incidentEntity.setJobName(jobName);
              long jobidddd=incidentEntity.getJobId();
              pentity.setAccountName(projectName);
              pentity.setApplicationName(applicationName);
              pentity.setSubAccountName(projectName);
              pentity.setProjectName(projectName);
              pentity.setWebappsAndMicroservice(jobName);
              pentity.setReleaseDate(releaseDate);
              pentity.setSubAccountName(projectName);
              pentity.setProjectId(projectId);
              
              incidentEntity.setTypeOfProject(projectType);
              incidentEntity.setProjectId(projectId);
              incidentEntity.setProjectName(projectName);
              if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                     String projectNamePatten = "^[a-zA-Z]{3,25}?_CodeQuality$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(jobName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setJobName(jobName.split("_CodeQuality", 2)[0]);
                           jobName = incidentEntity.getJobName();

                     } else {
                           String suffix = "_CodeQuality";

                           String jobNameNew = jobName.concat(suffix);
                           incidentEntity.setJobName(jobNameNew);
                           jobName = incidentEntity.getJobName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println("new job name is"+jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              
              // incidentEntity.setReleaseDate(releaseDate);
              String[] temp;
              String[] temp1;
              String[] temp2;
              String[] temp3;
              String[] temp4;
              String[] temp5;
              String[] temp6;

              String delimiter = "\\,";

              Object log;
              try {
                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jsonObject.get("JenkinsUsername").toString(),
                                  jsonObject.get("JenkinsPassword").toString());
                     incidentEntity.setJenkinsUsername((String) jsonObject.get("JenkinsUsername"));
                     incidentEntity.setJenkinsPassword((String) jsonObject.get("JenkinsPassword"));
                     incidentEntity.setCodeBase(jsonObject.get("SourceCode").toString());
                     String strXMLFilename = null;

                     if ("SVN".equalsIgnoreCase(jsonObject.get("SourceCode").toString())) {
                           strXMLFilename = PropertyUtil.getPropValue("xmlConfigBatch");
                     } else if ("CVS".equalsIgnoreCase(jsonObject.get("SourceCode").toString())) {
                           strXMLFilename = PropertyUtil.getPropValue("xmlConfigBatchCVS");
                     } else if ("GIT".equalsIgnoreCase(jsonObject.get("SourceCode").toString())) {
                           strXMLFilename = PropertyUtil.getPropValue("xmlConfigBatchGIT");
                     }

                     File xmlFile = new File(strXMLFilename);
                     DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                     DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                     Document doc = dBuilder.parse(xmlFile);

                     NodeList permissionList = doc.getElementsByTagName("permission");
                     Node workspacePermission = permissionList.item(0);
                     workspacePermission.setTextContent("hudson.model.Item.Workspace:" + jsonObject.get("JenkinsUsername"));

                     Node buildPermission = permissionList.item(1);
                     buildPermission.setTextContent("hudson.model.Item.Build:" + jsonObject.get("JenkinsUsername"));
                     Node updatePermission = permissionList.item(2);
                     updatePermission.setTextContent("hudson.model.Run.Update:" + jsonObject.get("JenkinsUsername"));
                     Node readPermission = permissionList.item(3);
                     readPermission.setTextContent("hudson.model.Item.Read:" + jsonObject.get("JenkinsUsername"));
                     Node tagPermission = permissionList.item(4);
                     tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jsonObject.get("JenkinsUsername"));
                     Node configurePermission = permissionList.item(5);
                     configurePermission.setTextContent("hudson.model.Item.Configure:" + jsonObject.get("JenkinsUsername"));
                     Node discoverPermission = permissionList.item(6);
                     discoverPermission.setTextContent("hudson.model.Item.Discover:" + jsonObject.get("JenkinsUsername"));

                     NodeList nodeList = doc.getElementsByTagName("defaultValue");
                     Node classN = nodeList.item(0);
                     Element classname = (Element) classN;
                     classname.setTextContent(jsonObject.get("MainClassName").toString());

                     Node batchNode = nodeList.item(1);
                     Element batch = (Element) batchNode;
                  //   batch.setTextContent(jsonObject.get("BatchFileName").toString());

                     if ("SVN".equalsIgnoreCase(jsonObject.get("SourceCode").toString())) {
                           String svnURL = jsonObject.get("SvnUrl").toString();
                           String module = jsonObject.get("LocalModule").toString();

                           incidentEntity.setSvnUrl(svnURL);
                           incidentEntity.setLocalModuleDirectory(module);
                           NodeList nodeListLocation = doc.getElementsByTagName("locations");
                           Node nodeLoc = nodeListLocation.item(0);
                           Element locations = (Element) nodeLoc;

                           if (!svnURL.isEmpty()) {
                                  temp = svnURL.split(delimiter);
                                  temp1 = module.split(delimiter);
                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                         locations.appendChild(moduleNode);
                                         Element remoteNode = doc.createElement("remote");
                                         remoteNode.setTextContent(temp[i]);
                                         moduleNode.appendChild(remoteNode);
                                         Element local = doc.createElement("local");
                                         local.setTextContent(temp1[i]);
                                         moduleNode.appendChild(local);
                                         Element depth = doc.createElement("depthOption");
                                         depth.setTextContent("infinity");
                                         moduleNode.appendChild(depth);
                                         Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                         ignoreExternalsOption.setTextContent("false");
                                         moduleNode.appendChild(ignoreExternalsOption);
                                  }
                           }
                     } else if ("CVS".equalsIgnoreCase(jsonObject.get("SourceCode").toString())) {
                           String cvsRoot = jsonObject.get("CvsRoot").toString();
                           String cvsPassword = jsonObject.get("CvsPassword").toString();
                           String branchName = jsonObject.get("BranchName").toString();
                           String tagName = jsonObject.get("TagName").toString();
                           String remoteName = jsonObject.get("RemoteName").toString();
                           String localName = jsonObject.get("LocalName").toString();
                           String locationType = jsonObject.get("LocationType").toString();
                           incidentEntity.setCvsRoot(cvsRoot);
                           incidentEntity.setCvsPassword(cvsPassword);
                           incidentEntity.setBranchLocationName(branchName);
                           incidentEntity.setTagLocationName(tagName);
                           incidentEntity.setRemoteName(remoteName);
                           incidentEntity.setLocalName(localName);
                           incidentEntity.setCvsLocation(locationType);
                           NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                           Node nodeRepositories = nodeListRepositories.item(0);
                           Element repositories = (Element) nodeRepositories;

                           if (!cvsRoot.isEmpty()) {
                                  temp = cvsRoot.split(delimiter);
                                  temp1 = cvsPassword.split(delimiter);
                                  temp2 = branchName.split(delimiter);
                                  temp3 = remoteName.split(delimiter);
                                  temp4 = localName.split(delimiter);
                                  temp5 = locationType.split(delimiter);
                                  temp6 = tagName.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                         repositories.appendChild(cvsRepository);

                                         Element cvsRootXml = doc.createElement("cvsRoot");
                                         cvsRootXml.setTextContent(temp[i]);
                                         cvsRepository.appendChild(cvsRootXml);

                                         Element repositoryItems = doc.createElement("repositoryItems");
                                         cvsRepository.appendChild(repositoryItems);

                                         Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                         repositoryItems.appendChild(cvsRepositoryItem);

                                         Element modules = doc.createElement("modules");
                                         cvsRepositoryItem.appendChild(modules);

                                         Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                         modules.appendChild(cvsModule);

                                         Element localName1 = doc.createElement("localName");
                                         localName1.setTextContent(temp4[i]);
                                         cvsModule.appendChild(localName1);

                                         Element remoteName1 = doc.createElement("remoteName");
                                         remoteName1.setTextContent(temp3[i]);
                                         cvsModule.appendChild(remoteName1);

                                         Element location = doc.createElement("location");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                         }
                                         if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                         }
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                         }
                                         cvsRepositoryItem.appendChild(location);

                                         Element locationType1 = doc.createElement("locationType");
                                         locationType1.setTextContent(temp5[i]);
                                         location.appendChild(locationType1);

                                         Element locationName1 = doc.createElement("locationName");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp2[i]);
                                         } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp6[i]);
                                         }
                                         location.appendChild(locationName1);

                                         Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                useHeadIfNotFound.setTextContent("false");
                                         } else {
                                                useHeadIfNotFound.setTextContent("true");
                                         }
                                         location.appendChild(useHeadIfNotFound);

                                         Element compressionLevel = doc.createElement("compressionLevel");
                                         compressionLevel.setTextContent("-1");
                                         cvsRepository.appendChild(compressionLevel);

                                         Element excludedRegions = doc.createElement("excludedRegions");
                                         cvsRepository.appendChild(excludedRegions);

                                         Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                         excludedRegions.appendChild(excludedRegion);

                                         Element pattern = doc.createElement("pattern");
                                         excludedRegion.appendChild(pattern);

                                         Element cvsPassword1 = doc.createElement("password");
                                         cvsPassword1.setTextContent(temp1[i]);
                                         cvsRepository.appendChild(cvsPassword1);

                                         Element passwordRequired = doc.createElement("passwordRequired");
                                         passwordRequired.setTextContent("true");
                                         cvsRepository.appendChild(passwordRequired);

                                  }
                           }
                     }

                     else if ("GIT".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {

                           String gitURL = jsonObject.get("GitUrl").toString();
                           String gitBranch = jsonObject.get("GitBranch").toString();
                           String projectBranch = jsonObject.get("ProjectBranch").toString();
                           NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                           Node nodeRepositories11 = nodeListRepositories11.item(0);
                           Element userRemoteConfigs = (Element) nodeRepositories11;
                           incidentEntity.setGitUrl(gitURL);
                           incidentEntity.setGitBranch(gitBranch);
                           incidentEntity.setProjectPathBranch(projectBranch);

                            if (!gitURL.isEmpty()) {

                                  temp = gitURL.split(delimiter);
                                  temp1 = gitBranch.split(delimiter);
                                  temp2 = projectBranch.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                         userRemoteConfigs.appendChild(moduleNode11);

                                         Element remoteNode11 = doc.createElement("url");
                                         remoteNode11.setTextContent(temp[i]);
                                         moduleNode11.appendChild(remoteNode11);

                                         NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                         Node nodeRepositories13 = nodeListRepositories13.item(0);
                                         Element branches = (Element) nodeRepositories13;

                                         Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                         branches.appendChild(moduleNode12);

                                         Element remoteNode12 = doc.createElement("name");
                                         remoteNode12.setTextContent(temp1[i]);
                                         moduleNode12.appendChild(remoteNode12);

                                         if (projectBranch.equalsIgnoreCase(",")) {

                                                Element element = (Element) doc
                                                              .getElementsByTagName("hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                                              .item(0);

                                                Node parent = element.getParentNode();

                                                parent.removeChild(element);

                                                parent.normalize();

                                         } else {
                                                NodeList nodeListRepositories12 = doc.getElementsByTagName("sparseCheckoutPaths");
                                                Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                Element moduleNode13 = doc
                                                              .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                sparseCheckoutPaths.appendChild(moduleNode13);
                                                Element nodeListRepositories22 = doc.createElement("path");
                                                nodeListRepositories22.setTextContent(temp2[i]);
                                                moduleNode13.appendChild(nodeListRepositories22);
                                         }
                                  }
                           }
                     }

                     String strURL1 = PropertyUtil.getPropValue("jenkinsUrl");
                     String strURL = strURL1.concat(jobName);
                     System.out.println("strurl is "+strURL);
                     if ("batch".equalsIgnoreCase(pro)) {
                           status = workFlowUtil.postXML(strURL, doc);
                           System.out.println("Status is "+status);
                     }else if ("ant".equalsIgnoreCase(pro)) {
                           status = workFlowUtil.postXML(strURL, doc);
                           System.out.println("Status is "+status);
                     }else if ("maven".equalsIgnoreCase(pro)) {
                           status = workFlowUtil.postXML(strURL, doc);
                           System.out.println("Status is "+status);
                     } else if ("noTestCasesANT".equalsIgnoreCase(pro)) {
                           status = workFlowUtil.postXML(strURL, doc);
                           System.out.println("Status is "+status);
                     }else if ("noTestCasesMAVEN".equalsIgnoreCase(pro)) {
                           status = workFlowUtil.postXML(strURL, doc);
                           System.out.println("Status is "+status);
                     } else if ("batch".equalsIgnoreCase(pro)) {
                           status = workFlowUtil.postXML(strURL, doc);
                           System.out.println("Status is "+status);
                     }
              } catch (FileNotFoundException e) {
                     // log.error(e);
                     e.printStackTrace();

              } catch (IOException e) {
                     e.printStackTrace();
              } catch (ParserConfigurationException e) {
                     e.printStackTrace();
              } catch (SAXException e) {
                     e.printStackTrace();
              }

            
              // String incidentId33=(String) jsonObject.get("workflowid");

              wentity.getWorkflowId();
              
              incidentEntity.getJobId();
              wentity.setJobEntity(incidentEntity);
              wentity.setProjectId(projectId);
              /*codeQualityentity.setJobEntity(incidentEntity);
              codeQualityentity.setCodequalityId((int) jobidddd);
              codeQualityentity.setJobName(jobName);
              codeQualityentity.setApplicationName(jobName);*/
              wentity.setProjectName(projectName);
              incidentEntity.setJobName((String) jsonObject.get("jobName"));
              incidentEntity.setApplicationName(applicationName);
              wentity.setApplicationName(applicationName);
              
                     
              
              wRepo.save(wentity);
              jobRepo.save(incidentEntity);
              pRepo.save(pentity);
            //  cRepo.save(codeQualityentity);
              messageDTO.setMsg("Data created successfully");

              return messageDTO;

       }

       public MessageDTO buildMavenJob(JSONObject jsonObject) {
              boolean status = false;
              Object log;
              try {

                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jsonObject.get("JenkinsUsername").toString(),
                                  jsonObject.get("JenkinsPassword").toString());
                     String projectName = (String) jsonObject.get("ProjectName");
                     final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuildWithParameters");
                     String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", projectName);

                     String statusString = workFlowUtil.postURL(jenkinsUrlBuild);

                     if (statusString.isEmpty()) {
                           status = true;
                     }

              } catch (FileNotFoundException e) {
                     System.out.println("file not found error");

              } catch (IOException e) {

                     System.out.println();
              }
              messageDTO.setMsg("Build done");
              return messageDTO;
       }

       @Override
       public MessageDTO submitNewMicroserviceJob(JSONObject jsonObject) {
              JobEntity incidentEntity = null;
              WorkflowMasterEntity wentity = null;
              JSONObject jobj = new JSONObject();
              // String incidentId1 = (String) ((HashMap)
              // jsonObject.get("JobDetails")).get("jobId");
              String applicationName = (String) jsonObject.get("applicationName");

              // System.out.println("Aish"+incidentId1);
              // int job_id= Integer.parseInt(incidentId1);
              incidentEntity = new JobEntity();
              wentity = new WorkflowMasterEntity();

              String stg = (String) jsonObject.get("Stage");
              incidentEntity.setStage(stg);
              // incidentEntity.setJobId(job_id);
              boolean status = false;
              if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                     String projectNamePatten = "^[a-zA-Z]{3,25}?_CodeQuality$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(applicationName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setApplicationName(applicationName.split("_CodeQuality", 2)[0]);
                           applicationName = incidentEntity.getApplicationName();

                     } else {
                           String suffix = "_CodeQuality";

                           String jobNameNew = applicationName.concat(suffix);
                           incidentEntity.setApplicationName(jobNameNew);
                           applicationName = incidentEntity.getApplicationName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Yasca$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(applicationName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setApplicationName(applicationName.split("_Yasca", 2)[0]);
                           applicationName = incidentEntity.getApplicationName();

                     } else {
                           String suffix = "_Yasca";

                           String jobNameNew = applicationName.concat(suffix);
                           incidentEntity.setProjectName(jobNameNew);
                           applicationName = incidentEntity.getProjectName();// addition of
                                                                                                                     // suffix in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Checkmarx$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(applicationName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setApplicationName(applicationName.split("_Checkmarx", 2)[0]);
                           applicationName = incidentEntity.getApplicationName();

                     } else {
                           String suffix = "_Checkmarx";

                           String jobNameNew = applicationName.concat(suffix);
                           incidentEntity.setApplicationName(jobNameNew);
                           applicationName = incidentEntity.getApplicationName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              if ("Deploy".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Deploy$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(applicationName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setApplicationName(applicationName.split("_Deploy", 2)[0]);
                           applicationName = incidentEntity.getApplicationName();

                     } else {
                           String suffix = "_Deploy";

                           String jobNameNew = applicationName.concat(suffix);
                           incidentEntity.setApplicationName(jobNameNew);
                           applicationName = incidentEntity.getApplicationName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Regression$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(applicationName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setApplicationName(applicationName.split("_Regression", 2)[0]);
                           applicationName = incidentEntity.getApplicationName();

                     } else {
                           String suffix = "_Regression";

                           String jobNameNew = applicationName.concat(suffix);
                           incidentEntity.setApplicationName(jobNameNew);
                           applicationName = incidentEntity.getApplicationName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Performance$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(applicationName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setApplicationName(applicationName.split("_Performance", 2)[0]);
                           applicationName = incidentEntity.getApplicationName();

                     } else {
                           String suffix = "_Performance";

                           String jobNameNew = applicationName.concat(suffix);
                           incidentEntity.setApplicationName(jobNameNew);
                           applicationName = incidentEntity.getApplicationName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              try {

                     if ("java".equalsIgnoreCase(jsonObject.get("projectType").toString()))

                     {

                           System.out.println(
                                         "inside submit new microservice job printing project id" + jsonObject.get("ProjectId"));

                           // int appId = fetchAppId(jsonObject);
                           String appId = (String) jsonObject.get("applicationId");
                           int job_idd = Integer.parseInt(appId);
                           // newJobBean.setAppId(appId);

                           DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jsonObject.get("JenkinsUsername").toString(),
                                         jsonObject.get("JenkinsPassword").toString());
                           // ////////////////// prj name to app name
                           // String applicationName=(String)
                           // jsonObject.get("applicationName");
                           incidentEntity.setApplicationName(applicationName);
                           String applicationType = (String) jsonObject.get("applicationType");
                           incidentEntity.setApplicationType(applicationType);
                           String projectType = (String) jsonObject.get("ProjectType");
                           incidentEntity.setTypeOfProject(projectType);
                           String projectId = (String) jsonObject.get("ProjectId");
                           incidentEntity.setProjectId(projectId);
                           String jenkinsUsername = (String) jsonObject.get("JenkinsUsername");
                           incidentEntity.setJenkinsUsername(jenkinsUsername);
                           String jenkinsPassword = (String) jsonObject.get("JenkinsPassword");
                           incidentEntity.setJenkinsPassword(jenkinsPassword);
                           String localModuleDirectory = (String) jsonObject.get("LocalModule");
                           incidentEntity.setLocalModuleDirectory(localModuleDirectory);

                           File xmlFile = null;
                           File fileMaven = null;

                           String[] temp;
                           String[] temp1;
                           String delimiter = "\\,";

                           int result = 0;

                           String strXMLFilename = null;
                           String strXMLFilenameMaven = null;
                           String strXMLFilenameNoTestCasesAnt = null;
                           String strXMLFilenameNoTestCasesMaven = null;

                           String[] temp2;
                           String[] temp3;
                           String[] temp4;
                           String[] temp5;
                           String[] temp6;

                           final String mailRecipients = PropertyUtil.getPropValue("mail.Recipients");
                           String testResultPath = (String) jsonObject.get("TestReportXmlPath");

                           if ("SVN".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                  strXMLFilename = PropertyUtil.getPropValue("xmlConfig");

                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigMaven");

                                  strXMLFilenameNoTestCasesAnt = PropertyUtil.getPropValue("xmlConfigNoTestCasesAnt");

                                  strXMLFilenameNoTestCasesMaven = PropertyUtil.getPropValue("xmlConfigNoTestCasesMaven");
                           } else if ("CVS".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                  strXMLFilename = PropertyUtil.getPropValue("xmlConfigCVS");

                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigMavenCVS");

                                  strXMLFilenameNoTestCasesAnt = PropertyUtil.getPropValue("xmlConfigNoTestCasesAntCVS");

                                  strXMLFilenameNoTestCasesMaven = PropertyUtil.getPropValue("xmlConfigNoTestCasesMavenCVS");
                           } else if ("GIT".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {

                                  /* System.out.println("***************** git checked"); */
                                  strXMLFilename = PropertyUtil.getPropValue("xmlConfigGIT");

                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigMavenGit");

                                  strXMLFilenameNoTestCasesAnt = PropertyUtil.getPropValue("xmlConfigNoTestCasesAntGIT");

                                  strXMLFilenameNoTestCasesMaven = PropertyUtil.getPropValue("xmlConfigNoTestCasesMavenGIT");
                           }

                           String strURL1 = PropertyUtil.getPropValue("jenkinsUrl");
                           String strURL = strURL1.concat(applicationName);

                           /*
                           * System.out.println("project name ***********" + projectName);
                           * System.out.println("str URL **********" + strURL);
                           * System.out.println("app name ************" +
                           * newJobBean.getProjectName());
                           * 
                            * System.out.println("---- source type--"+newJobBean.
                           * getSourceCode()); System.out.println("maven check***********"
                           * +strXMLFilenameMaven);
                           * System.out.println("--project Type--"+projectType);
                           */

                           if ("ant".equalsIgnoreCase(projectType)) {
                                  if (!((String) jsonObject.get("WasCheck") == (null))
                                                && !("".equals((String) jsonObject.get("WasCheck")))) {

                                         String was = null;
                                         if (("yes").equalsIgnoreCase((String) jsonObject.get("WasCheck"))) {

                                                if ("SVN".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                       was = PropertyUtil.getPropValue("xmlConfigWas");
                                                } else if ("CVS".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                       was = PropertyUtil.getPropValue("xmlConfigWasCVS");
                                                } else if ("GIT".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                       was = PropertyUtil.getPropValue("xmlConfigWasGIT");
                                                }
                                                xmlFile = new File(was);

                                         }
                                  } else {

                                         xmlFile = new File(strXMLFilename);
                                  }
                                  DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                                  DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                                  Document doc = dBuilder.parse(xmlFile);

                                  NodeList permissionList = doc.getElementsByTagName("permission");
                                  Node workspacePermission = permissionList.item(0);
                                  workspacePermission.setTextContent(
                                                "hudson.model.Item.Workspace:" + (String) jsonObject.get("JenkinsUsername"));
                                  Node buildPermission = permissionList.item(1);
                                  buildPermission.setTextContent("hudson.model.Item.Build:" + jsonObject.get("JenkinsUsername"));
                                  Node updatePermission = permissionList.item(2);
                                  updatePermission.setTextContent("hudson.model.Run.Update:" + jsonObject.get("JenkinsUsername"));
                                  Node readPermission = permissionList.item(3);
                                  readPermission.setTextContent("hudson.model.Item.Read:" + jsonObject.get("JenkinsUsername"));
                                  Node tagPermission = permissionList.item(4);
                                  tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jsonObject.get("JenkinsUsername"));
                                  Node configurePermission = permissionList.item(5);
                                  configurePermission
                                                .setTextContent("hudson.model.Item.Configure:" + jsonObject.get("JenkinsUsername"));
                                  Node discoverPermission = permissionList.item(6);
                                  discoverPermission
                                                .setTextContent("hudson.model.Item.Discover:" + jsonObject.get("JenkinsUsername"));

                                  NodeList nodeList = doc.getElementsByTagName("defaultValue");
                                  Node node = nodeList.item(0);

                                  Element defaultValueNode = (Element) node;
                                  defaultValueNode.setTextContent("$WORKSPACE/[file_path]");
                                  String filePath = defaultValueNode.getTextContent();
                                  String newfilePath = filePath.replace("[file_path]", (CharSequence) jsonObject.get("WarFilePath"));
                                  defaultValueNode.setTextContent(newfilePath);
                                  /*
                                  * System.out.println(
                                  * newfilePath+"*****************************************war file"
                                  * );
                                  */

                                  NodeList nodeListTest = doc.getElementsByTagName("testResults");
                                  Node nodeTest = nodeListTest.item(0);
                                  Element testResultNode = (Element) nodeTest;

                                  if ("SVN".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {

                                         String svnURL = (String) jsonObject.get("SvnUrl");
                                         String module = (String) jsonObject.get("LocalModule");
                                         NodeList nodeListLocation = doc.getElementsByTagName("locations");
                                         Node nodeLoc = nodeListLocation.item(0);
                                         Element locations = (Element) nodeLoc;

                                         if (!svnURL.isEmpty()) {
                                                temp = svnURL.split(delimiter);
                                                temp1 = module.split(delimiter);
                                                for (int i = 0; i < temp.length; i++) {
                                                       Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                                       locations.appendChild(moduleNode);
                                                       Element remoteNode = doc.createElement("remote");
                                                       remoteNode.setTextContent(temp[i]);
                                                       moduleNode.appendChild(remoteNode);
                                                       Element local = doc.createElement("local");
                                                       local.setTextContent(temp1[i]);
                                                       moduleNode.appendChild(local);
                                                       Element depth = doc.createElement("depthOption");
                                                       depth.setTextContent("infinity");
                                                       moduleNode.appendChild(depth);
                                                       Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                                       ignoreExternalsOption.setTextContent("false");

                                                       moduleNode.appendChild(ignoreExternalsOption);
                                                }
                                                incidentEntity.setSvnUrl(svnURL);
                                                incidentEntity.setLocalModuleDirectory(module);

                                         }
                                  } else if ("CVS".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                         String cvsRoot = (String) jsonObject.get("CvsRoot");
                                         String cvsPassword = (String) jsonObject.get("CvsPassword");
                                         String branchName = (String) jsonObject.get("BranchName");
                                         String tagName = (String) jsonObject.get("TagName");
                                         String remoteName = (String) jsonObject.get("RemoteName");
                                         String localName = (String) jsonObject.get("LocalName");
                                         String locationType = (String) jsonObject.get("LocationType");
                                         NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                                         Node nodeRepositories = nodeListRepositories.item(0);
                                         Element repositories = (Element) nodeRepositories;
                                         incidentEntity.setCvsRoot(cvsRoot);
                                         incidentEntity.setCvsPassword(cvsPassword);
                                         incidentEntity.setBranchLocationName(branchName);
                                         incidentEntity.setTagLocationName(tagName);
                                         incidentEntity.setRemoteName(remoteName);
                                         incidentEntity.setLocalName(localName);
                                         incidentEntity.setCvsLocation(locationType);

                                         if (!cvsRoot.isEmpty()) {
                                                temp = cvsRoot.split(delimiter);
                                                temp1 = cvsPassword.split(delimiter);
                                                temp2 = branchName.split(delimiter);
                                                temp3 = remoteName.split(delimiter);
                                                temp4 = localName.split(delimiter);
                                                temp5 = locationType.split(delimiter);
                                                temp6 = tagName.split(delimiter);

                                                for (int i = 0; i < temp.length; i++) {

                                                       Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                                       repositories.appendChild(cvsRepository);

                                                       Element cvsRootXml = doc.createElement("cvsRoot");
                                                       cvsRootXml.setTextContent(temp[i]);
                                                       cvsRepository.appendChild(cvsRootXml);

                                                       Element repositoryItems = doc.createElement("repositoryItems");
                                                       cvsRepository.appendChild(repositoryItems);

                                                       Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                                       repositoryItems.appendChild(cvsRepositoryItem);

                                                       Element modules = doc.createElement("modules");
                                                       cvsRepositoryItem.appendChild(modules);

                                                       Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                                       modules.appendChild(cvsModule);

                                                       Element localName1 = doc.createElement("localName");
                                                       localName1.setTextContent(temp4[i]);
                                                       cvsModule.appendChild(localName1);

                                                       Element remoteName1 = doc.createElement("remoteName");
                                                       remoteName1.setTextContent(temp3[i]);
                                                       cvsModule.appendChild(remoteName1);

                                                       Element location = doc.createElement("location");
                                                       if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                              location.setAttribute("class",
                                                                            "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                                       }
                                                       if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                              location.setAttribute("class",
                                                                            "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                                       }
                                                       if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                              location.setAttribute("class",
                                                                            "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                                       }
                                                       cvsRepositoryItem.appendChild(location);

                                                       Element locationType1 = doc.createElement("locationType");
                                                       locationType1.setTextContent(temp5[i]);
                                                       location.appendChild(locationType1);

                                                       Element locationName1 = doc.createElement("locationName");
                                                       if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                              locationName1.setTextContent(temp2[i]);
                                                       } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                              locationName1.setTextContent(temp6[i]);
                                                       }
                                                       location.appendChild(locationName1);

                                                       Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                                       if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                              useHeadIfNotFound.setTextContent("false");
                                                       } else {
                                                              useHeadIfNotFound.setTextContent("true");
                                                       }
                                                       location.appendChild(useHeadIfNotFound);

                                                       Element compressionLevel = doc.createElement("compressionLevel");
                                                       compressionLevel.setTextContent("-1");
                                                       cvsRepository.appendChild(compressionLevel);

                                                       Element excludedRegions = doc.createElement("excludedRegions");
                                                       cvsRepository.appendChild(excludedRegions);

                                                       Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                                       excludedRegions.appendChild(excludedRegion);

                                                       Element pattern = doc.createElement("pattern");
                                                       excludedRegion.appendChild(pattern);

                                                       Element cvsPassword1 = doc.createElement("password");
                                                       cvsPassword1.setTextContent(temp1[i]);
                                                       cvsRepository.appendChild(cvsPassword1);

                                                       Element passwordRequired = doc.createElement("passwordRequired");
                                                       passwordRequired.setTextContent("true");
                                                       cvsRepository.appendChild(passwordRequired);

                                                }
                                         }
                                  }

                                  else if ("GIT".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                         String gitURL = (String) jsonObject.get("GitUrl");
                                         String gitBranch = (String) jsonObject.get("GitBranch");
                                         String projectBranch = (String) jsonObject.get("ProjectBranch");

                                         NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                                         Node nodeRepositories11 = nodeListRepositories11.item(0);
                                         Element userRemoteConfigs = (Element) nodeRepositories11;
                                         incidentEntity.setGitUrl(gitURL);
                                         incidentEntity.setGitBranch(gitBranch);
                                         incidentEntity.setProjectPathBranch(projectBranch);
                                         if (!gitURL.isEmpty()) {

                                                temp = gitURL.split(delimiter);
                                                temp1 = gitBranch.split(delimiter);
                                                temp2 = projectBranch.split(delimiter);

                                                for (int i = 0; i < temp.length; i++) {
                                                       Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                                       userRemoteConfigs.appendChild(moduleNode11);

                                                       Element remoteNode11 = doc.createElement("url");
                                                       remoteNode11.setTextContent(temp[i]);
                                                       moduleNode11.appendChild(remoteNode11);

                                                       NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                                       Node nodeRepositories13 = nodeListRepositories13.item(0);
                                                       Element branches = (Element) nodeRepositories13;

                                                       Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                                       branches.appendChild(moduleNode12);

                                                       Element remoteNode12 = doc.createElement("name");
                                                       remoteNode12.setTextContent(temp1[i]);
                                                       moduleNode12.appendChild(remoteNode12);

                                                       if (projectBranch.equalsIgnoreCase(",")) {

                                                              Element element = (Element) doc.getElementsByTagName(
                                                                            "hudson.plugins.git.extensions.impl.SparseCheckoutPaths").item(0);

                                                              Node parent = element.getParentNode();

                                                              parent.removeChild(element);

                                                              parent.normalize();

                                                       } else {
                                                              NodeList nodeListRepositories12 = doc.getElementsByTagName("sparseCheckoutPaths");
                                                              Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                              Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                              Element moduleNode13 = doc
                                                                            .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                              sparseCheckoutPaths.appendChild(moduleNode13);
                                                              Element nodeListRepositories22 = doc.createElement("path");
                                                              nodeListRepositories22.setTextContent(temp2[i]);
                                                              moduleNode13.appendChild(nodeListRepositories22);
                                                       }
                                                }
                                         }
                                  }

                                  if (!testResultPath.isEmpty()) {
                                         testResultNode.setTextContent(testResultPath);
                                  }

                                  String empEmailId = null;

                                  NodeList nodeEmaill = doc.getElementsByTagName("recipientList");
                                  Node nodeEmaill1 = nodeEmaill.item(0);
                                  Element nodeEmaillResult = (Element) nodeEmaill1;

                                  if (!testResultPath.isEmpty()) {
                                         empEmailId = (String) jsonObject.get("EmpEmailId");
                                         String allEmails = mailRecipients.concat(empEmailId);
                                         nodeEmaillResult.setTextContent(allEmails);
                                  }

                                  status = workFlowUtil.postXML(strURL, doc);
                           } else if ("Maven".equalsIgnoreCase(projectType)) {

                                  if (!(jsonObject.get("WasCheck") == (null)) && !("".equals(jsonObject.get("WasCheck")))) {
                                         if (((String) jsonObject.get("WasCheck")).equalsIgnoreCase("yes")) {

                                                String was = null;
                                                if ("SVN".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                       was = PropertyUtil.getPropValue("xmlConfigMavenWasCheck");
                                                } else if ("CVS".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                       was = PropertyUtil.getPropValue("xmlConfigMavenWasCheckCVS");
                                                } else if ("GIT".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {

                                                       was = PropertyUtil.getPropValue("xmlConfigMavenWasCheckGIT");
                                                }
                                                fileMaven = new File(was);
                                         }
                                  } else {

                                         fileMaven = new File(strXMLFilenameMaven);
                                  }

                                  DocumentBuilderFactory dbFactory1 = DocumentBuilderFactory.newInstance();
                                  DocumentBuilder dBuilder1 = dbFactory1.newDocumentBuilder();
                                  Document docMaven = dBuilder1.parse(fileMaven);

                                  NodeList permissionList = docMaven.getElementsByTagName("permission");
                                  Node workspacePermission = permissionList.item(0);
                                  workspacePermission
                                                .setTextContent("hudson.model.Item.Workspace:" + jsonObject.get("JenkinsUsername"));
                                  Node buildPermission = permissionList.item(1);
                                  buildPermission.setTextContent("hudson.model.Item.Build:" + jsonObject.get("JenkinsUsername"));
                                  Node updatePermission = permissionList.item(2);
                                  updatePermission.setTextContent("hudson.model.Run.Update:" + jsonObject.get("JenkinsUsername"));
                                  Node readPermission = permissionList.item(3);
                                  readPermission.setTextContent("hudson.model.Item.Read:" + jsonObject.get("JenkinsUsername"));
                                  Node tagPermission = permissionList.item(4);
                                  tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jsonObject.get("JenkinsUsername"));
                                  Node configurePermission = permissionList.item(5);
                                  configurePermission
                                                .setTextContent("hudson.model.Item.Configure:" + jsonObject.get("JenkinsUsername"));
                                  Node discoverPermission = permissionList.item(6);
                                  discoverPermission
                                                .setTextContent("hudson.model.Item.Discover:" + jsonObject.get("JenkinsUsername"));

                                  NodeList nodeList1 = docMaven.getElementsByTagName("defaultValue");
                                  Node node1 = nodeList1.item(0);
                                  Element defaultValueNode1 = (Element) node1;
                                  defaultValueNode1.setTextContent("$WORKSPACE/[file_path]");
                                  String filePath1 = defaultValueNode1.getTextContent();
                                  String newfilePath1 = filePath1.replace("[file_path]",
                                                (CharSequence) jsonObject.get("WarFilePath"));
                                  defaultValueNode1.setTextContent(newfilePath1);
                                  /*
                                  * System.out.
                                  * println("******************************war file path"
                                  * +newfilePath1);
                                   */
                                  NodeList nodeListTest1 = docMaven.getElementsByTagName("testResults");
                                  Node nodeTest1 = nodeListTest1.item(0);
                                  Element testResultNode1 = (Element) nodeTest1;

                                  if ("SVN".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                         String svnURL = (String) jsonObject.get("SvnUrl");
                                         String module = (String) jsonObject.get("LocalModule");
                                         NodeList nodeListLocation = docMaven.getElementsByTagName("locations");
                                         Node nodeLoc = nodeListLocation.item(0);
                                         Element locations = (Element) nodeLoc;

                                         if (!svnURL.isEmpty()) {
                                                temp = svnURL.split(delimiter);
                                                temp1 = module.split(delimiter);
                                                for (int i = 0; i < temp.length; i++) {
                                                       Element moduleNode = docMaven.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                                       locations.appendChild(moduleNode);
                                                       Element remoteNode = docMaven.createElement("remote");

                                                       remoteNode.setTextContent(temp[i]);
                                                       moduleNode.appendChild(remoteNode);

                                                       Element local = docMaven.createElement("local");
                                                       local.setTextContent(temp1[i]);
                                                       moduleNode.appendChild(local);
                                                       Element depth = docMaven.createElement("depthOption");
                                                       depth.setTextContent("infinity");
                                                       moduleNode.appendChild(depth);
                                                       Element ignoreExternalsOption = docMaven.createElement("ignoreExternalsOption");
                                                       ignoreExternalsOption.setTextContent("false");
                                                       moduleNode.appendChild(ignoreExternalsOption);
                                                       incidentEntity.setSvnUrl(svnURL);
                                                       incidentEntity.setLocalModuleDirectory(module);

                                                }
                                         }
                                  } else if ("CVS".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                         String cvsRoot = (String) jsonObject.get("CvsRoot");
                                         String cvsPassword = (String) jsonObject.get("CvsPassword");
                                         String branchName = (String) jsonObject.get("BranchName");
                                         String tagName = (String) jsonObject.get("TagName");
                                         String remoteName = (String) jsonObject.get("RemoteName");
                                         String localName = (String) jsonObject.get("LocalName");
                                         String locationType = (String) jsonObject.get("LocationType");
                                         NodeList nodeListRepositories = docMaven.getElementsByTagName("repositories");
                                         Node nodeRepositories = nodeListRepositories.item(0);
                                         Element repositories = (Element) nodeRepositories;
                                         incidentEntity.setCvsRoot(cvsRoot);
                                         incidentEntity.setCvsPassword(cvsPassword);
                                         incidentEntity.setBranchLocationName(branchName);
                                         incidentEntity.setTagLocationName(tagName);
                                         incidentEntity.setRemoteName(remoteName);
                                         incidentEntity.setLocalName(localName);
                                         incidentEntity.setCvsLocation(locationType);
                                         if (!cvsRoot.isEmpty()) {
                                                temp = cvsRoot.split(delimiter);
                                                temp1 = cvsPassword.split(delimiter);
                                                temp2 = branchName.split(delimiter);
                                                temp3 = remoteName.split(delimiter);
                                                temp4 = localName.split(delimiter);
                                                temp5 = locationType.split(delimiter);
                                                temp6 = tagName.split(delimiter);

                                                for (int i = 0; i < temp.length; i++) {

                                                       Element cvsRepository = docMaven.createElement("hudson.scm.CvsRepository");
                                                       repositories.appendChild(cvsRepository);

                                                       Element cvsRootXml = docMaven.createElement("cvsRoot");
                                                       cvsRootXml.setTextContent(temp[i]);
                                                       cvsRepository.appendChild(cvsRootXml);

                                                       Element repositoryItems = docMaven.createElement("repositoryItems");
                                                       cvsRepository.appendChild(repositoryItems);

                                                       Element cvsRepositoryItem = docMaven.createElement("hudson.scm.CvsRepositoryItem");
                                                       repositoryItems.appendChild(cvsRepositoryItem);

                                                       Element modules = docMaven.createElement("modules");
                                                       cvsRepositoryItem.appendChild(modules);

                                                       Element cvsModule = docMaven.createElement("hudson.scm.CvsModule");
                                                       modules.appendChild(cvsModule);

                                                       Element localName1 = docMaven.createElement("localName");
                                                       localName1.setTextContent(temp4[i]);
                                                       cvsModule.appendChild(localName1);

                                                       Element remoteName1 = docMaven.createElement("remoteName");
                                                       remoteName1.setTextContent(temp3[i]);
                                                       cvsModule.appendChild(remoteName1);

                                                       Element location = docMaven.createElement("location");
                                                       if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                              location.setAttribute("class",
                                                                            "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                                       }
                                                       if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                              location.setAttribute("class",
                                                                            "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                                       }
                                                       if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                              location.setAttribute("class",
                                                                            "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                                       }
                                                       cvsRepositoryItem.appendChild(location);

                                                       Element locationType1 = docMaven.createElement("locationType");
                                                       locationType1.setTextContent(temp5[i]);
                                                       location.appendChild(locationType1);

                                                       Element locationName1 = docMaven.createElement("locationName");
                                                       if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                              locationName1.setTextContent(temp2[i]);
                                                       } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                              locationName1.setTextContent(temp6[i]);
                                                       }
                                                       location.appendChild(locationName1);

                                                       Element useHeadIfNotFound = docMaven.createElement("useHeadIfNotFound");
                                                       if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                              useHeadIfNotFound.setTextContent("false");
                                                       } else {
                                                              useHeadIfNotFound.setTextContent("true");
                                                       }
                                                       location.appendChild(useHeadIfNotFound);

                                                       Element compressionLevel = docMaven.createElement("compressionLevel");
                                                       compressionLevel.setTextContent("-1");
                                                       cvsRepository.appendChild(compressionLevel);

                                                       Element excludedRegions = docMaven.createElement("excludedRegions");
                                                       cvsRepository.appendChild(excludedRegions);

                                                       Element excludedRegion = docMaven.createElement("hudson.scm.ExcludedRegion");
                                                       excludedRegions.appendChild(excludedRegion);

                                                       Element pattern = docMaven.createElement("pattern");
                                                       excludedRegion.appendChild(pattern);

                                                       Element cvsPassword1 = docMaven.createElement("password");
                                                       cvsPassword1.setTextContent(temp1[i]);
                                                       cvsRepository.appendChild(cvsPassword1);

                                                       Element passwordRequired = docMaven.createElement("passwordRequired");
                                                       passwordRequired.setTextContent("true");
                                                       cvsRepository.appendChild(passwordRequired);

                                                }
                                         }

                                  } else if ("GIT".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {

                                         String gitURL = (String) jsonObject.get("GitUrl");
                                         String gitBranch = (String) jsonObject.get("GitBranch");
                                         String projectBranch = (String) jsonObject.get("ProjectBranch");

                                         NodeList nodeListRepositories11 = docMaven.getElementsByTagName("userRemoteConfigs");
                                         Node nodeRepositories11 = nodeListRepositories11.item(0);
                                         Element userRemoteConfigs = (Element) nodeRepositories11;
                                         incidentEntity.setGitUrl(gitURL);
                                         incidentEntity.setGitBranch(gitBranch);
                                         incidentEntity.setProjectPathBranch(projectBranch);

                                         if (!gitURL.isEmpty()) {

                                                temp = gitURL.split(delimiter);
                                                temp1 = gitBranch.split(delimiter);
                                                temp2 = projectBranch.split(delimiter);

                                                for (int i = 0; i < temp.length; i++) {
                                                       Element moduleNode11 = docMaven.createElement("hudson.plugins.git.UserRemoteConfig");
                                                       userRemoteConfigs.appendChild(moduleNode11);

                                                       Element remoteNode11 = docMaven.createElement("url");
                                                       remoteNode11.setTextContent(temp[i]);
                                                       moduleNode11.appendChild(remoteNode11);

                                                       NodeList nodeListRepositories13 = docMaven.getElementsByTagName("branches");
                                                       Node nodeRepositories13 = nodeListRepositories13.item(0);
                                                       Element branches = (Element) nodeRepositories13;

                                                       Element moduleNode12 = docMaven.createElement("hudson.plugins.git.BranchSpec");
                                                       branches.appendChild(moduleNode12);

                                                       Element remoteNode12 = docMaven.createElement("name");
                                                       remoteNode12.setTextContent(temp1[i]);
                                                       moduleNode12.appendChild(remoteNode12);

                                                       if (projectBranch.equalsIgnoreCase(",")) {

                                                              Element element = (Element) docMaven.getElementsByTagName(
                                                                            "hudson.plugins.git.extensions.impl.SparseCheckoutPaths").item(0);

                                                              Node parent = element.getParentNode();

                                                              parent.removeChild(element);

                                                              parent.normalize();

                                                       } else {
                                                              NodeList nodeListRepositories12 = docMaven
                                                                            .getElementsByTagName("sparseCheckoutPaths");
                                                              Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                              Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                              Element moduleNode13 = docMaven
                                                                            .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                              sparseCheckoutPaths.appendChild(moduleNode13);
                                                              Element nodeListRepositories22 = docMaven.createElement("path");
                                                              nodeListRepositories22.setTextContent(temp2[i]);
                                                              moduleNode13.appendChild(nodeListRepositories22);
                                                       }
                                                }
                                         }
                                  }

                                  if (!testResultPath.isEmpty()) {
                                         testResultNode1.setTextContent(testResultPath);
                                  }

                                  String empEmailId = null;
                                  NodeList nodeEmaill = docMaven.getElementsByTagName("recipientList");
                                  Node nodeEmaill1 = nodeEmaill.item(0);
                                  Element nodeEmaillResult = (Element) nodeEmaill1;

                                  if (!testResultPath.isEmpty()) {
                                         empEmailId = (String) jsonObject.get("EmpEmailId");
                                         String allEmails = mailRecipients.concat(empEmailId);
                                         nodeEmaillResult.setTextContent(allEmails);

                                  }
                                  status = workFlowUtil.postXML(strURL, docMaven);

                           } else if ("noTestCasesAnt".equalsIgnoreCase(projectType)) {
                                  if (!(jsonObject.get("WasCheck") == (null)) && !("".equals(jsonObject.get("WasCheck")))) {

                                         if (((String) jsonObject.get("WasCheck")).equalsIgnoreCase("yes")) {

                                                String was = null;
                                                if ("SVN".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                       was = PropertyUtil.getPropValue("xmlConfigNoTestCasesAntWas");
                                                } else if ("CVS".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                       was = PropertyUtil.getPropValue("xmlConfigNoTestCasesAntWasCVS");
                                                } else if ("GIT".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                       was = PropertyUtil.getPropValue("xmlConfigNoTestCasesAntWasGIT");
                                                }
                                                xmlFile = new File(was);

                                         } else {

                                                xmlFile = new File(strXMLFilenameNoTestCasesAnt);
                                         }
                                         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                                         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                                         Document doc = dBuilder.parse(xmlFile);

                                         NodeList permissionList = doc.getElementsByTagName("permission");
                                         Node workspacePermission = permissionList.item(0);
                                         workspacePermission
                                                       .setTextContent("hudson.model.Item.Workspace:" + jsonObject.get("JenkinsUsername"));
                                         Node buildPermission = permissionList.item(1);
                                         buildPermission.setTextContent("hudson.model.Item.Build:" + jsonObject.get("JenkinsUsername"));
                                         Node updatePermission = permissionList.item(2);
                                         updatePermission.setTextContent("hudson.model.Run.Update:" + jsonObject.get("JenkinsUsername"));
                                         Node readPermission = permissionList.item(3);
                                         readPermission.setTextContent("hudson.model.Item.Read:" + jsonObject.get("JenkinsUsername"));
                                         Node tagPermission = permissionList.item(4);
                                         tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jsonObject.get("JenkinsUsername"));
                                         Node configurePermission = permissionList.item(5);
                                         configurePermission
                                                       .setTextContent("hudson.model.Item.Configure:" + jsonObject.get("JenkinsUsername"));
                                         Node discoverPermission = permissionList.item(6);
                                         discoverPermission
                                                       .setTextContent("hudson.model.Item.Discover:" + jsonObject.get("JenkinsUsername"));

                                         NodeList nodeList = doc.getElementsByTagName("defaultValue");
                                         Node node = nodeList.item(0);

                                         Element defaultValueNode = (Element) node;
                                         defaultValueNode.setTextContent("$WORKSPACE/[file_path]");
                                         String filePath = defaultValueNode.getTextContent();
                                         String newfilePath = filePath.replace("[file_path]",
                                                       (CharSequence) jsonObject.get("WarFilePath"));
                                         defaultValueNode.setTextContent(newfilePath);

                                         if ("SVN".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                String svnURL = (String) jsonObject.get("SvnUrl");
                                                String module = (String) jsonObject.get("LocalModule");
                                                NodeList nodeListLocation = doc.getElementsByTagName("locations");
                                                Node nodeLoc = nodeListLocation.item(0);
                                                Element locations = (Element) nodeLoc;
                                                incidentEntity.setSvnUrl(svnURL);
                                                incidentEntity.setLocalModuleDirectory(module);
                                                if (!svnURL.isEmpty()) {
                                                       temp = svnURL.split(delimiter);
                                                       temp1 = module.split(delimiter);
                                                       for (int i = 0; i < temp.length; i++) {
                                                              Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                                              locations.appendChild(moduleNode);
                                                              Element remoteNode = doc.createElement("remote");
                                                              remoteNode.setTextContent(temp[i]);
                                                              moduleNode.appendChild(remoteNode);
                                                              Element local = doc.createElement("local");
                                                              local.setTextContent(temp1[i]);
                                                              moduleNode.appendChild(local);
                                                              Element depth = doc.createElement("depthOption");
                                                              depth.setTextContent("infinity");
                                                              moduleNode.appendChild(depth);
                                                              Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                                              ignoreExternalsOption.setTextContent("false");
                                                              moduleNode.appendChild(ignoreExternalsOption);
                                                       }
                                                }
                                         } else if ("CVS".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                String cvsRoot = (String) jsonObject.get("CvsRoot");
                                                String cvsPassword = (String) jsonObject.get("CvsPassword");
                                                String branchName = (String) jsonObject.get("BranchName");
                                                String tagName = (String) jsonObject.get("TagName");
                                                String remoteName = (String) jsonObject.get("RemoteName");
                                                String localName = (String) jsonObject.get("LocalName");
                                                String locationType = (String) jsonObject.get("LocationType");
                                                NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                                                Node nodeRepositories = nodeListRepositories.item(0);
                                                Element repositories = (Element) nodeRepositories;
                                                incidentEntity.setCvsRoot(cvsRoot);
                                                incidentEntity.setCvsPassword(cvsPassword);
                                                incidentEntity.setBranchLocationName(branchName);
                                                incidentEntity.setTagLocationName(tagName);
                                                incidentEntity.setRemoteName(remoteName);
                                                incidentEntity.setLocalName(localName);
                                                incidentEntity.setCvsLocation(locationType);
                                                if (!cvsRoot.isEmpty()) {
                                                       temp = cvsRoot.split(delimiter);
                                                       temp1 = cvsPassword.split(delimiter);
                                                       temp2 = branchName.split(delimiter);
                                                       temp3 = remoteName.split(delimiter);
                                                       temp4 = localName.split(delimiter);
                                                       temp5 = locationType.split(delimiter);
                                                       temp6 = tagName.split(delimiter);

                                                       for (int i = 0; i < temp.length; i++) {

                                                              Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                                              repositories.appendChild(cvsRepository);

                                                              Element cvsRootXml = doc.createElement("cvsRoot");
                                                              cvsRootXml.setTextContent(temp[i]);
                                                              cvsRepository.appendChild(cvsRootXml);

                                                              Element repositoryItems = doc.createElement("repositoryItems");
                                                              cvsRepository.appendChild(repositoryItems);

                                                              Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                                              repositoryItems.appendChild(cvsRepositoryItem);

                                                              Element modules = doc.createElement("modules");
                                                              cvsRepositoryItem.appendChild(modules);

                                                              Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                                              modules.appendChild(cvsModule);

                                                              Element localName1 = doc.createElement("localName");
                                                              localName1.setTextContent(temp4[i]);
                                                              cvsModule.appendChild(localName1);

                                                              Element remoteName1 = doc.createElement("remoteName");
                                                              remoteName1.setTextContent(temp3[i]);
                                                              cvsModule.appendChild(remoteName1);

                                                              Element location = doc.createElement("location");
                                                              if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                                     location.setAttribute("class",
                                                                                  "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                                              }
                                                              if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                                     location.setAttribute("class",
                                                                                  "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                                              }
                                                              if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                                     location.setAttribute("class",
                                                                                  "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                                              }
                                                              cvsRepositoryItem.appendChild(location);

                                                              Element locationType1 = doc.createElement("locationType");
                                                              locationType1.setTextContent(temp5[i]);
                                                              location.appendChild(locationType1);

                                                              Element locationName1 = doc.createElement("locationName");
                                                              if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                                     locationName1.setTextContent(temp2[i]);
                                                              } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                                     locationName1.setTextContent(temp6[i]);
                                                              }
                                                              location.appendChild(locationName1);

                                                              Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                                              if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                                     useHeadIfNotFound.setTextContent("false");
                                                              } else {
                                                                     useHeadIfNotFound.setTextContent("true");
                                                              }
                                                              location.appendChild(useHeadIfNotFound);

                                                              Element compressionLevel = doc.createElement("compressionLevel");
                                                              compressionLevel.setTextContent("-1");
                                                              cvsRepository.appendChild(compressionLevel);

                                                              Element excludedRegions = doc.createElement("excludedRegions");
                                                              cvsRepository.appendChild(excludedRegions);

                                                              Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                                              excludedRegions.appendChild(excludedRegion);

                                                              Element pattern = doc.createElement("pattern");
                                                              excludedRegion.appendChild(pattern);

                                                              Element cvsPassword1 = doc.createElement("password");
                                                              cvsPassword1.setTextContent(temp1[i]);
                                                              cvsRepository.appendChild(cvsPassword1);

                                                              Element passwordRequired = doc.createElement("passwordRequired");
                                                              passwordRequired.setTextContent("true");
                                                              cvsRepository.appendChild(passwordRequired);

                                                       }
                                                }
                                         }

                                         else if ("GIT".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                String gitURL = (String) jsonObject.get("GitUrl");
                                                String gitBranch = (String) jsonObject.get("GitBranch");
                                                String projectBranch = (String) jsonObject.get("ProjectBranch");
                                                incidentEntity.setGitUrl(gitURL);
                                                incidentEntity.setGitBranch(gitBranch);
                                                incidentEntity.setProjectPathBranch(projectBranch);
                                                NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                                                Node nodeRepositories11 = nodeListRepositories11.item(0);
                                                Element userRemoteConfigs = (Element) nodeRepositories11;

                                                if (!gitURL.isEmpty()) {

                                                       temp = gitURL.split(delimiter);
                                                       temp1 = gitBranch.split(delimiter);
                                                       temp2 = projectBranch.split(delimiter);

                                                       for (int i = 0; i < temp.length; i++) {
                                                              Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                                              userRemoteConfigs.appendChild(moduleNode11);

                                                              Element remoteNode11 = doc.createElement("url");
                                                              remoteNode11.setTextContent(temp[i]);
                                                              moduleNode11.appendChild(remoteNode11);

                                                              NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                                              Node nodeRepositories13 = nodeListRepositories13.item(0);
                                                              Element branches = (Element) nodeRepositories13;

                                                              Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                                              branches.appendChild(moduleNode12);

                                                              Element remoteNode12 = doc.createElement("name");
                                                              remoteNode12.setTextContent(temp1[i]);
                                                              moduleNode12.appendChild(remoteNode12);

                                                              if (projectBranch.equalsIgnoreCase(",")) {

                                                                     Element element = (Element) doc
                                                                                  .getElementsByTagName(
                                                                                                "hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                                                                  .item(0);

                                                                     Node parent = element.getParentNode();

                                                                     parent.removeChild(element);

                                                                     parent.normalize();

                                                              } else {
                                                                     NodeList nodeListRepositories12 = doc
                                                                                  .getElementsByTagName("sparseCheckoutPaths");
                                                                     Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                                     Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                                     Element moduleNode13 = doc
                                                                                  .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                                     sparseCheckoutPaths.appendChild(moduleNode13);
                                                                     Element nodeListRepositories22 = doc.createElement("path");
                                                                     nodeListRepositories22.setTextContent(temp2[i]);
                                                                     moduleNode13.appendChild(nodeListRepositories22);
                                                              }
                                                       }
                                                }
                                         }

                                         String empEmailId = null;

                                         NodeList nodeEmaill = doc.getElementsByTagName("recipientList");
                                         Node nodeEmaill1 = nodeEmaill.item(0);
                                         Element nodeEmaillResult = (Element) nodeEmaill1;

                                         empEmailId = (String) jsonObject.get("EmpEmailId");
                                         String allEmails = mailRecipients.concat(empEmailId);
                                         nodeEmaillResult.setTextContent(allEmails);

                                         status = workFlowUtil.postXML(strURL, doc);

                                  } else if ("noTestCasesMaven".equalsIgnoreCase(projectType)) {
                                         if (!((String) jsonObject.get("WasCheck") == (null))
                                                       && !("".equals((String) jsonObject.get("WasCheck")))) {
                                                if ("yes".equalsIgnoreCase((String) jsonObject.get("WasCheck"))) {

                                                       String was = null;
                                                       if ("SVN".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                              was = PropertyUtil.getPropValue("xmlConfigNoTestCasesMavenWas");
                                                       } else if ("CVS".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                              was = PropertyUtil.getPropValue("xmlConfigNoTestCasesMavenWasCVS");
                                                       } else if ("GIT".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                              was = PropertyUtil.getPropValue("xmlConfigNoTestCasesMavenWasGIT");
                                                       }
                                                       xmlFile = new File(was);
                                                }
                                         } else {

                                                xmlFile = new File(strXMLFilenameNoTestCasesMaven);
                                         }
                                         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                                         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                                         Document doc = dBuilder.parse(xmlFile);

                                         NodeList permissionList = doc.getElementsByTagName("permission");
                                         Node workspacePermission = permissionList.item(0);
                                         workspacePermission
                                                       .setTextContent("hudson.model.Item.Workspace:" + jsonObject.get("JenkinsUsername"));
                                         Node buildPermission = permissionList.item(1);
                                         buildPermission.setTextContent("hudson.model.Item.Build:" + jsonObject.get("JenkinsUsername"));
                                         Node updatePermission = permissionList.item(2);
                                         updatePermission.setTextContent("hudson.model.Run.Update:" + jsonObject.get("JenkinsUsername"));
                                         Node readPermission = permissionList.item(3);
                                         readPermission.setTextContent("hudson.model.Item.Read:" + jsonObject.get("JenkinsUsername"));
                                         Node tagPermission = permissionList.item(4);
                                         tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jsonObject.get("JenkinsUsername"));
                                         Node configurePermission = permissionList.item(5);
                                         configurePermission
                                                       .setTextContent("hudson.model.Item.Configure:" + jsonObject.get("JenkinsUsername"));
                                         Node discoverPermission = permissionList.item(6);
                                         discoverPermission
                                                       .setTextContent("hudson.model.Item.Discover:" + jsonObject.get("JenkinsUsername"));

                                         NodeList nodeList = doc.getElementsByTagName("defaultValue");
                                         Node node = nodeList.item(0);

                                         Element defaultValueNode = (Element) node;
                                         defaultValueNode.setTextContent("$WORKSPACE/[file_path]");
                                         String filePath = defaultValueNode.getTextContent();
                                         String newfilePath = filePath.replace("[file_path]",
                                                       (CharSequence) jsonObject.get("WarFilePath"));
                                         defaultValueNode.setTextContent(newfilePath);

                                         if ("SVN".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                String svnURL = (String) jsonObject.get("SvnUrl");
                                                String module = (String) jsonObject.get("LocalModule");
                                                NodeList nodeListLocation = doc.getElementsByTagName("locations");
                                                Node nodeLoc = nodeListLocation.item(0);
                                                Element locations = (Element) nodeLoc;

                                                if (!svnURL.isEmpty()) {
                                                       temp = svnURL.split(delimiter);
                                                       temp1 = module.split(delimiter);
                                                       for (int i = 0; i < temp.length; i++) {
                                                              Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                                              locations.appendChild(moduleNode);
                                                              Element remoteNode = doc.createElement("remote");
                                                              remoteNode.setTextContent(temp[i]);
                                                              moduleNode.appendChild(remoteNode);
                                                              Element local = doc.createElement("local");
                                                              local.setTextContent(temp1[i]);
                                                              moduleNode.appendChild(local);
                                                              Element depth = doc.createElement("depthOption");
                                                              depth.setTextContent("infinity");
                                                              moduleNode.appendChild(depth);
                                                              Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                                              ignoreExternalsOption.setTextContent("false");
                                                              moduleNode.appendChild(ignoreExternalsOption);
                                                       }
                                                }
                                         } else if ("CVS".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                String cvsRoot = (String) jsonObject.get("CvsRoot");
                                                String cvsPassword = (String) jsonObject.get("CvsPassword");
                                                String branchName = (String) jsonObject.get("BranchName");
                                                String tagName = (String) jsonObject.get("TagName");
                                                String remoteName = (String) jsonObject.get("RemoteName");
                                                String localName = (String) jsonObject.get("LocalName");
                                                String locationType = (String) jsonObject.get("LocationType");
                                                NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                                                Node nodeRepositories = nodeListRepositories.item(0);
                                                Element repositories = (Element) nodeRepositories;

                                                if (!cvsRoot.isEmpty()) {
                                                       temp = cvsRoot.split(delimiter);
                                                       temp1 = cvsPassword.split(delimiter);
                                                       temp2 = branchName.split(delimiter);
                                                       temp3 = remoteName.split(delimiter);
                                                       temp4 = localName.split(delimiter);
                                                       temp5 = locationType.split(delimiter);
                                                       temp6 = tagName.split(delimiter);

                                                       for (int i = 0; i < temp.length; i++) {

                                                              Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                                              repositories.appendChild(cvsRepository);

                                                              Element cvsRootXml = doc.createElement("cvsRoot");
                                                              cvsRootXml.setTextContent(temp[i]);
                                                              cvsRepository.appendChild(cvsRootXml);

                                                              Element repositoryItems = doc.createElement("repositoryItems");
                                                              cvsRepository.appendChild(repositoryItems);

                                                              Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                                              repositoryItems.appendChild(cvsRepositoryItem);

                                                              Element modules = doc.createElement("modules");
                                                              cvsRepositoryItem.appendChild(modules);

                                                              Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                                              modules.appendChild(cvsModule);

                                                              Element localName1 = doc.createElement("localName");
                                                              localName1.setTextContent(temp4[i]);
                                                              cvsModule.appendChild(localName1);

                                                              Element remoteName1 = doc.createElement("remoteName");
                                                              remoteName1.setTextContent(temp3[i]);
                                                              cvsModule.appendChild(remoteName1);

                                                              Element location = doc.createElement("location");
                                                              if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                                     location.setAttribute("class",
                                                                                  "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                                              }
                                                              if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                                     location.setAttribute("class",
                                                                                  "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                                              }
                                                              if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                                     location.setAttribute("class",
                                                                                  "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                                              }
                                                              cvsRepositoryItem.appendChild(location);

                                                              Element locationType1 = doc.createElement("locationType");
                                                              locationType1.setTextContent(temp5[i]);
                                                              location.appendChild(locationType1);

                                                              Element locationName1 = doc.createElement("locationName");
                                                              if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                                     locationName1.setTextContent(temp2[i]);
                                                              } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                                     locationName1.setTextContent(temp6[i]);
                                                              }
                                                              location.appendChild(locationName1);

                                                              Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                                              if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                                     useHeadIfNotFound.setTextContent("false");
                                                              } else {
                                                                     useHeadIfNotFound.setTextContent("true");
                                                              }
                                                              location.appendChild(useHeadIfNotFound);

                                                              Element compressionLevel = doc.createElement("compressionLevel");
                                                              compressionLevel.setTextContent("-1");
                                                              cvsRepository.appendChild(compressionLevel);

                                                              Element excludedRegions = doc.createElement("excludedRegions");
                                                              cvsRepository.appendChild(excludedRegions);

                                                              Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                                              excludedRegions.appendChild(excludedRegion);

                                                              Element pattern = doc.createElement("pattern");
                                                              excludedRegion.appendChild(pattern);

                                                              Element cvsPassword1 = doc.createElement("password");
                                                              cvsPassword1.setTextContent(temp1[i]);
                                                              cvsRepository.appendChild(cvsPassword1);

                                                              Element passwordRequired = doc.createElement("passwordRequired");
                                                              passwordRequired.setTextContent("true");
                                                              cvsRepository.appendChild(passwordRequired);
                                                       }
                                                }
                                         }

                                         else if ("GIT".equalsIgnoreCase((String) jsonObject.get("SourceCode"))) {
                                                String gitURL = (String) jsonObject.get("GitUrl");
                                                String gitBranch = (String) jsonObject.get("GitBranch");
                                                String projectBranch = (String) jsonObject.get("ProjectBranch");

                                                NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                                                Node nodeRepositories11 = nodeListRepositories11.item(0);
                                                Element userRemoteConfigs = (Element) nodeRepositories11;

                                                if (!gitURL.isEmpty()) {

                                                       temp = gitURL.split(delimiter);
                                                       temp1 = gitBranch.split(delimiter);
                                                       temp2 = projectBranch.split(delimiter);

                                                       for (int i = 0; i < temp.length; i++) {
                                                              Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                                              userRemoteConfigs.appendChild(moduleNode11);

                                                              Element remoteNode11 = doc.createElement("url");
                                                              remoteNode11.setTextContent(temp[i]);
                                                              moduleNode11.appendChild(remoteNode11);

                                                              NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                                              Node nodeRepositories13 = nodeListRepositories13.item(0);
                                                              Element branches = (Element) nodeRepositories13;

                                                              Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                                              branches.appendChild(moduleNode12);

                                                              Element remoteNode12 = doc.createElement("name");
                                                              remoteNode12.setTextContent(temp1[i]);
                                                              moduleNode12.appendChild(remoteNode12);

                                                              if (projectBranch.equalsIgnoreCase(",")) {

                                                                     Element element = (Element) doc
                                                                                  .getElementsByTagName(
                                                                                                "hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                                                                  .item(0);

                                                                     Node parent = element.getParentNode();

                                                                     parent.removeChild(element);

                                                                     parent.normalize();

                                                              } else {
                                                                     NodeList nodeListRepositories12 = doc
                                                                                  .getElementsByTagName("sparseCheckoutPaths");
                                                                     Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                                     Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                                     Element moduleNode13 = doc
                                                                                  .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                                     sparseCheckoutPaths.appendChild(moduleNode13);
                                                                     Element nodeListRepositories22 = doc.createElement("path");
                                                                     nodeListRepositories22.setTextContent(temp2[i]);
                                                                     moduleNode13.appendChild(nodeListRepositories22);
                                                              }
                                                       }
                                                }
                                         }

                                         String empEmailId = null;

                                         NodeList nodeEmaill = doc.getElementsByTagName("recipientList");
                                         Node nodeEmaill1 = nodeEmaill.item(0);
                                         Element nodeEmaillResult = (Element) nodeEmaill1;

                                         empEmailId = (String) jsonObject.get("EmpEmailId");
                                         String allEmails = mailRecipients.concat(empEmailId);
                                         nodeEmaillResult.setTextContent(allEmails);

                                         status = workFlowUtil.postXML(strURL, doc);

                                  }
                           }
                     } else {/*
                                  * ////////change DevOpsWorkFlowUtil workFlowUtil = new
                                  * DevOpsWorkFlowUtil( jsonObject.get("JenkinsUsername"),
                                  * jsonObject.get("JenkinsPassword")); //String
                                  * deployJobName = newJobBean.getProjectNameDeployChef();
                                  * 
                                   * String url = (String) jsonObject.get("SvnUrl"); String
                                  * gitURL = (String) jsonObject.get("GitUrl"); String
                                  * gitBranch= (String) jsonObject.get("GitBranch"); String
                                  * projectBranch = (String)
                                  * jsonObject.get("GitProjectPathDeploy");
                                  * 
                                   * String module = (String) jsonObject.get("LocalModule");
                                  * 
                                   * String temp[]; String temp1[]; String[] temp2; String[]
                                  * temp3; String[] temp4; String[] temp5; String[] temp6;
                                  * String cvsRoot = (String)
                                  * jsonObject.get("getDeploycvsRoot"); String cvsPassword =
                                  * (String) jsonObject.get("DeploycvsPassword"); String
                                  * branchName = (String) jsonObject.get("DeploybranchName");
                                  * String tagName = (String)
                                  * jsonObject.get("DeploytagName"); String remoteName =
                                  * (String) jsonObject.get("DeployremoteName"); String
                                  * localName = (String) jsonObject.get("DeploylocalName");
                                  * String locationType = (String)
                                  * jsonObject.get("DeploylocationType"); String delimiter =
                                  * "\\,";
                                  * 
                                   * String projectName=(String)
                                   * jsonObject.get("ProjectName"); String strXMLFilenameMaven
                                  * = null; incidentEntity.setProjectName(projectName);
                                  * String strURL1 = PropertyUtil.getPropValue("jenkinsUrl");
                                  * String strURL = strURL1.concat(projectName);
                                  * 
                                   * 
                                   * if (((String)
                                  * jsonObject.get("SourceCode")).equalsIgnoreCase("SVN")) {
                                  * 
                                   * System.out.println("in svn");
                                  * 
                                   * strXMLFilenameMaven = PropertyUtil
                                  * .getPropValue("xmlConfigPolymerSVN");
                                  * 
                                   * 
                                   * } else if (((String)
                                  * jsonObject.get("SourceCode")).equalsIgnoreCase( "CVS")) {
                                  * 
                                   * strXMLFilenameMaven = PropertyUtil
                                  * .getPropValue("xmlConfigPolymerCVS"); }
                                  * 
                                   * 
                                   * 
                                   * else if (((String)
                                  * jsonObject.get("SourceCode")).equalsIgnoreCase( "GIT")) {
                                  * 
                                   * strXMLFilenameMaven = PropertyUtil
                                  * .getPropValue("xmlConfigPolymerGIT");
                                  * 
                                   * }
                                  * 
                                   * 
                                   * File xmlFile = new File(strXMLFilenameMaven);
                                  * 
                                   * DocumentBuilderFactory dbFactory = DocumentBuilderFactory
                                  * .newInstance(); DocumentBuilder dBuilder =
                                  * dbFactory.newDocumentBuilder(); Document doc =
                                  * dBuilder.parse(xmlFile);
                                  * 
                                   * 
                                   * if (((String)
                                  * jsonObject.get("SourceCode")).equalsIgnoreCase("SVN")) {
                                  * NodeList nodeListLocation = doc
                                  * .getElementsByTagName("locations"); Node nodeLoc =
                                  * nodeListLocation.item(0); Element locations = (Element)
                                  * nodeLoc;
                                  * 
                                   * if (!url.isEmpty()) { temp = url.split(delimiter); temp1
                                  * = module.split(delimiter);
                                  * 
                                   * for (int i = 0; i < temp.length; i++) {
                                  * 
                                   * Element moduleNode = doc
                                  * .createElement("hudson.scm.SubversionSCM_-ModuleLocation"
                                  * ); locations.appendChild(moduleNode); Element remoteNode
                                  * = doc.createElement("remote");
                                  * remoteNode.setTextContent(temp[i]);
                                  * moduleNode.appendChild(remoteNode); Element local =
                                  * doc.createElement("local");
                                  * local.setTextContent(temp1[i]);
                                  * moduleNode.appendChild(local); Element depth =
                                  * doc.createElement("depthOption");
                                  * depth.setTextContent("infinity");
                                  * moduleNode.appendChild(depth); Element
                                  * ignoreExternalsOption = doc
                                  * .createElement("ignoreExternalsOption");
                                  * ignoreExternalsOption.setTextContent("false");
                                  * moduleNode.appendChild(ignoreExternalsOption); } } } else
                                  * if (((String)
                                  * jsonObject.get("SourceCode")).equalsIgnoreCase( "CVS")) {
                                  * NodeList nodeListRepositories = doc
                                  * .getElementsByTagName("repositories"); Node
                                  * nodeRepositories = nodeListRepositories.item(0); Element
                                  * repositories = (Element) nodeRepositories;
                                  * 
                                   * if (!cvsRoot.isEmpty()) { temp =
                                  * cvsRoot.split(delimiter); temp1 =
                                  * cvsPassword.split(delimiter); temp2 =
                                  * branchName.split(delimiter); temp3 =
                                  * remoteName.split(delimiter); temp4 =
                                  * localName.split(delimiter); temp5 =
                                  * locationType.split(delimiter); temp6 =
                                  * tagName.split(delimiter);
                                  * 
                                   * for (int i = 0; i < temp.length; i++) {
                                  * 
                                   * Element cvsRepository = doc
                                  * .createElement("hudson.scm.CvsRepository");
                                  * repositories.appendChild(cvsRepository);
                                  * 
                                   * Element cvsRootXml = doc.createElement("cvsRoot");
                                  * cvsRootXml.setTextContent(temp[i]);
                                  * cvsRepository.appendChild(cvsRootXml);
                                  * 
                                   * Element repositoryItems = doc
                                  * .createElement("repositoryItems");
                                  * cvsRepository.appendChild(repositoryItems);
                                  * 
                                   * Element cvsRepositoryItem = doc
                                  * .createElement("hudson.scm.CvsRepositoryItem");
                                  * repositoryItems.appendChild(cvsRepositoryItem);
                                  * 
                                   * Element modules = doc.createElement("modules");
                                  * cvsRepositoryItem.appendChild(modules);
                                  * 
                                   * Element cvsModule = doc
                                  * .createElement("hudson.scm.CvsModule");
                                  * modules.appendChild(cvsModule);
                                  * 
                                   * Element localName1 = doc.createElement("localName");
                                  * localName1.setTextContent(temp4[i]);
                                  * cvsModule.appendChild(localName1);
                                  * 
                                   * Element remoteName1 = doc.createElement("remoteName");
                                  * remoteName1.setTextContent(temp3[i]);
                                  * cvsModule.appendChild(remoteName1);
                                  * 
                                   * Element location = doc.createElement("location"); if
                                  * ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                  * location.setAttribute("class",
                                  * "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation"
                                  * ); } if ("TAG".equalsIgnoreCase(temp5[i])) {
                                  * location.setAttribute("class",
                                  * "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation")
                                  * ; } if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                  * location.setAttribute("class",
                                  * "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation"
                                  * ); } cvsRepositoryItem.appendChild(location);
                                  * 
                                   * Element locationType1 = doc
                                  * .createElement("locationType");
                                  * locationType1.setTextContent(temp5[i]);
                                  * location.appendChild(locationType1);
                                  * 
                                   * Element locationName1 = doc
                                  * .createElement("locationName"); if
                                  * ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                  * locationName1.setTextContent(temp2[i]); } else if
                                  * ("TAG".equalsIgnoreCase(temp5[i])) {
                                  * locationName1.setTextContent(temp6[i]); }
                                  * location.appendChild(locationName1);
                                  * 
                                   * Element useHeadIfNotFound = doc
                                  * .createElement("useHeadIfNotFound"); if
                                  * ("HEAD".equalsIgnoreCase(temp5[i])) {
                                  * useHeadIfNotFound.setTextContent("false"); } else {
                                  * useHeadIfNotFound.setTextContent("true"); }
                                  * location.appendChild(useHeadIfNotFound);
                                  * 
                                   * Element compressionLevel = doc
                                  * .createElement("compressionLevel");
                                  * compressionLevel.setTextContent("-1");
                                  * cvsRepository.appendChild(compressionLevel);
                                  * 
                                   * Element excludedRegions = doc
                                  * .createElement("excludedRegions");
                                  * cvsRepository.appendChild(excludedRegions);
                                  * 
                                   * Element excludedRegion = doc
                                  * .createElement("hudson.scm.ExcludedRegion");
                                  * excludedRegions.appendChild(excludedRegion);
                                  * 
                                   * Element pattern = doc.createElement("pattern");
                                  * excludedRegion.appendChild(pattern);
                                  * 
                                   * Element cvsPassword1 = doc.createElement("password");
                                  * cvsPassword1.setTextContent(temp1[i]);
                                  * cvsRepository.appendChild(cvsPassword1);
                                  * 
                                   * Element passwordRequired = doc
                                  * .createElement("passwordRequired");
                                  * passwordRequired.setTextContent("true");
                                  * cvsRepository.appendChild(passwordRequired);
                                  * 
                                   * } } }
                                  * 
                                   * 
                                   * 
                                   * 
                                   * else if ("GIT".equalsIgnoreCase((String)
                                  * jsonObject.get("SourceCode"))){
                                  * 
                                   * 
                                   * NodeList nodeListRepositories11 =
                                  * doc.getElementsByTagName("userRemoteConfigs"); Node
                                  * nodeRepositories11 = nodeListRepositories11.item(0);
                                  * Element userRemoteConfigs = (Element) nodeRepositories11;
                                  * 
                                   * 
                                   * if (!gitURL.isEmpty()) {
                                  * 
                                   * temp = gitURL.split(delimiter); temp1 =
                                  * gitBranch.split(delimiter); temp2 =
                                  * projectBranch.split(delimiter);
                                  * 
                                   * 
                                   * for (int i = 0; i < temp.length; i++) { Element
                                  * moduleNode11 =
                                  * doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                  * userRemoteConfigs.appendChild(moduleNode11);
                                  * 
                                   * Element remoteNode11 = doc.createElement("url");
                                  * remoteNode11.setTextContent(temp[i]);
                                  * moduleNode11.appendChild(remoteNode11);
                                  * 
                                   * 
                                   * NodeList nodeListRepositories13 =
                                  * doc.getElementsByTagName("branches"); Node
                                  * nodeRepositories13 = nodeListRepositories13.item(0);
                                  * Element branches = (Element) nodeRepositories13;
                                  * 
                                   * Element moduleNode12 =
                                  * doc.createElement("hudson.plugins.git.BranchSpec");
                                  * branches.appendChild(moduleNode12);
                                  * 
                                   * 
                                   * Element remoteNode12 = doc.createElement("name");
                                  * remoteNode12.setTextContent(temp1[i]);
                                  * moduleNode12.appendChild(remoteNode12);
                                  * 
                                   * 
                                   * if (projectBranch.equalsIgnoreCase(",")) {
                                  * 
                                   * Element element = (Element) doc.getElementsByTagName(
                                  * "hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                   * .item(0);
                                  * 
                                   * Node parent = element.getParentNode();
                                  * 
                                   * parent.removeChild(element);
                                  * 
                                   * parent.normalize();
                                  * 
                                   * } else{ NodeList nodeListRepositories12 =
                                  * doc.getElementsByTagName("sparseCheckoutPaths"); Node
                                  * nodeRepositories12 = nodeListRepositories12.item(0);
                                  * Element sparseCheckoutPaths = (Element)
                                  * nodeRepositories12; Element moduleNode13 =
                                  * doc.createElement(
                                  * "hudson.plugins.git.extensions.impl.SparseCheckoutPath");
                                  * 
                                   * 
                                   * sparseCheckoutPaths.appendChild(moduleNode13); Element
                                  * nodeListRepositories22 = doc.createElement("path");
                                  * nodeListRepositories22.setTextContent(temp2[i]);
                                  * moduleNode13.appendChild(nodeListRepositories22); } } } }
                                  * 
                                   * 
                                   * 
                                   * NodeList nodeList = doc.getElementsByTagName("command");
                                  * 
                                   * 
                                   * Node node1 = nodeList.item(0); Element defaultValueNode1
                                  * = (Element) node1;
                                  * 
                                   * defaultValueNode1
                                  * .setTextContent("export PATH=$PATH:$NODE_PATH\n chmod -R 0777 $WORKSPACE\n npm install\n npm install -g bower\n npm install -g grunt-cli\n bower install --allow-root\n grunt dist --allow-root"
                                  * );
                                  * 
                                   * status = workFlowUtil.postXML(strURL, doc);
                                  */
                     }
              } catch (FileNotFoundException e) {
                     // e.printStackTrace();
                     System.out.println("FileNotFoundException");

              } catch (IOException e) {

                     System.out.println("IOException");

              } catch (ParserConfigurationException e) {
                     // e.printStackTrace();
                     System.out.println("ParserConfigurationException");

              } catch (SAXException e) {
                     // e.printStackTrace();
                     System.out.println("SAXException");

              }

              if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                     String codequality = "01";
                     wentity.setStageInfo(codequality);

              }
              if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String yasca = "02";
                     String stage2 = wentity.getStageInfo();
                     wentity.setStageInfo(stage2 + yasca);

              }
              if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String checkmarx = "03";
                     wentity.setStageInfo(checkmarx);

              }

              if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String DeployTomcat = "04";
                     wentity.setStageInfo(DeployTomcat);

              }
              if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String DeployChef = "05";
                     wentity.setStageInfo(DeployChef);

              }
              if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String DeployCf = "06";
                     wentity.setStageInfo(DeployCf);

              }
              if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String Performance = "07";
                     wentity.setStageInfo(Performance);

              }

              if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String Regression = "08";
                     wentity.setStageInfo(Regression);

              }

              // String incidentId33=(String) jsonObject.get("workflowid");

              wentity.getWorkflowId();
              
              incidentEntity.getJobId();
              wentity.setJobEntity(incidentEntity);
              String projectId=(String) jsonObject.get("ProjectId");
              String projectName=(String) jsonObject.get("ProjectName");
              wentity.setProjectId(projectId);
              wentity.setProjectName(projectName);
              wentity.setApplicationName(applicationName);
              wRepo.save(wentity);
              jobRepo.save(incidentEntity);

              messageDTO.setMsg("Data created successfully");

              return messageDTO;
       }

       @Override
       public MessageDTO submitNewYascaJob(JSONObject jsonObject) {
              JobEntity incidentEntity = null;
              WorkflowMasterEntity wentity = null;
              String jenkinsusername = null;
              String jenkinspassword = null;
              String sourcecode=null;
              String svnURL = null;
              String module = null;
              String cvsRoot = null;
              String cvsPassword = null;
              String branchName = null;
              String tagName = null;
              String remoteName = null;
              String localName = null;
              String locationType = null;
              String gitURL =null;
              String gitBranch = null;
              String projectBranch = null;
              String jobName= jsonObject.get("jobName").toString();
             
              JSONObject jobj = new JSONObject();
              // String incidentId1 = (String) ((HashMap)
              // jsonObject.get("JobDetails")).get("jobId");

              // System.out.println("Aish"+incidentId1);
              // int job_id= Integer.parseInt(incidentId1);
       
              wentity = new WorkflowMasterEntity();

              String stg = (String) jsonObject.get("Stage");
              
              // incidentEntity.setJobId(job_id);
              boolean status = false;
              
            
              
              JobEntity yascajob=jobRepo.findByAppName1(jobName);
              System.out.println("jobname is "+jobName);
              yascajob.setStage("Yasca");
              yascajob.setCurrentState("Yasca");
              
                     jenkinsusername=yascajob.getJenkinsUsername();
                     jenkinspassword=yascajob.getJenkinsPassword();
                     sourcecode=yascajob.getCodeBase();
                     svnURL = yascajob.getSvnUrl();
                     module = yascajob.getLocalModuleDirectory();
                     cvsRoot = yascajob.getCvsRoot();
                     cvsPassword = yascajob.getCvsPassword();
                     branchName = yascajob.getBranchLocationName();
                     tagName = yascajob.getTagLocationName();
                     remoteName = yascajob.getRemoteName();
                     localName = yascajob.getLocalName();
                     locationType = yascajob.getCvsLocation();
                     gitURL =yascajob.getGitUrl();
                     gitBranch = yascajob.getGitBranch();
                     projectBranch = yascajob.getProjectPathBranch();
                     
                     
              
              if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Yasca$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(jobName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           
                           yascajob.setJobName(jobName.split("_Yasca", 2)[0]);
                           jobName = yascajob.getJobName();

                     } else {
                           String suffix = "_Yasca";

                           String jobNameNew = jobName.concat(suffix);
                           yascajob.setJobName(jobNameNew);
                           jobName = yascajob.getJobName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              
              // incidentEntity.setReleaseDate(releaseDate);
              String[] temp;
              String[] temp1;
              String[] temp2;
              String[] temp3;
              String[] temp4;
              String[] temp5;
              String[] temp6;

              String delimiter = "\\,";

              Object log;
              try {
                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jenkinsusername,
                                  jenkinspassword);

                     String strXMLFilenameMaven = null;
                     if (sourcecode.equalsIgnoreCase("SVN")) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigYasca");
                     } else if (sourcecode.equalsIgnoreCase("CVS")) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigYascaCVS");
                     } else if (sourcecode.equalsIgnoreCase("GIT")) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigYascaGIT");
                     }

                     File xmlFile = new File(strXMLFilenameMaven);

                     DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                     DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                     Document doc = dBuilder.parse(xmlFile);

                     NodeList permissionList = doc.getElementsByTagName("permission");
                     Node workspacePermission = permissionList.item(0);
                     workspacePermission.setTextContent("hudson.model.Item.Workspace:" + jsonObject.get("JenkinsUsername"));

                     Node buildPermission = permissionList.item(1);
                     buildPermission.setTextContent("hudson.model.Item.Build:" + jsonObject.get("JenkinsUsername"));
                     Node updatePermission = permissionList.item(2);
                     updatePermission.setTextContent("hudson.model.Run.Update:" + jsonObject.get("JenkinsUsername"));
                     Node readPermission = permissionList.item(3);
                     readPermission.setTextContent("hudson.model.Item.Read:" + jsonObject.get("JenkinsUsername"));
                     Node tagPermission = permissionList.item(4);
                     tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jsonObject.get("JenkinsUsername"));
                     Node configurePermission = permissionList.item(5);
                     configurePermission.setTextContent("hudson.model.Item.Configure:" + jsonObject.get("JenkinsUsername"));
                     Node discoverPermission = permissionList.item(6);
                     discoverPermission.setTextContent("hudson.model.Item.Discover:" + jsonObject.get("JenkinsUsername"));

                     if (sourcecode.equalsIgnoreCase("SVN")) {
                     

                           
                           NodeList nodeListLocation = doc.getElementsByTagName("locations");
                           Node nodeLoc = nodeListLocation.item(0);
                           Element locations = (Element) nodeLoc;

                           if (!svnURL.isEmpty()) {
                                  temp = svnURL.split(delimiter);
                                  temp1 = module.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                         locations.appendChild(moduleNode);
                                         Element remoteNode = doc.createElement("remote");
                                         remoteNode.setTextContent(temp[i]);
                                         moduleNode.appendChild(remoteNode);
                                         Element local = doc.createElement("local");
                                         local.setTextContent(temp1[i]);
                                         moduleNode.appendChild(local);
                                         Element depth = doc.createElement("depthOption");
                                         depth.setTextContent("infinity");
                                         moduleNode.appendChild(depth);
                                         Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                         ignoreExternalsOption.setTextContent("false");
                                         moduleNode.appendChild(ignoreExternalsOption);
                                  }
                           }
                     }
                     if (sourcecode.equalsIgnoreCase("CVS")) {
                           
                           
                           NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                           Node nodeRepositories = nodeListRepositories.item(0);
                           Element repositories = (Element) nodeRepositories;

                           if (!cvsRoot.isEmpty()) {
                                  temp = cvsRoot.split(delimiter);
                                  temp1 = cvsPassword.split(delimiter);
                                  temp2 = branchName.split(delimiter);
                                  temp3 = remoteName.split(delimiter);
                                  temp4 = localName.split(delimiter);
                                  temp5 = locationType.split(delimiter);
                                  temp6 = tagName.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                         repositories.appendChild(cvsRepository);
                                         Element cvsRootXml = doc.createElement("cvsRoot");
                                         cvsRootXml.setTextContent(temp[i]);
                                         cvsRepository.appendChild(cvsRootXml);

                                         Element repositoryItems = doc.createElement("repositoryItems");
                                         cvsRepository.appendChild(repositoryItems);

                                         Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                         repositoryItems.appendChild(cvsRepositoryItem);

                                         Element modules = doc.createElement("modules");
                                         cvsRepositoryItem.appendChild(modules);

                                         Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                         modules.appendChild(cvsModule);

                                         Element localName1 = doc.createElement("localName");
                                         localName1.setTextContent(temp4[i]);
                                         cvsModule.appendChild(localName1);

                                         Element remoteName1 = doc.createElement("remoteName");
                                         remoteName1.setTextContent(temp3[i]);
                                         cvsModule.appendChild(remoteName1);

                                         Element location = doc.createElement("location");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                         }
                                         if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                         }
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                         }
                                         cvsRepositoryItem.appendChild(location);

                                         Element locationType1 = doc.createElement("locationType");
                                         locationType1.setTextContent(temp5[i]);
                                         location.appendChild(locationType1);

                                         Element locationName1 = doc.createElement("locationName");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp2[i]);
                                         } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp6[i]);
                                         }
                                         location.appendChild(locationName1);

                                         Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                useHeadIfNotFound.setTextContent("false");
                                         } else {
                                                useHeadIfNotFound.setTextContent("true");
                                         }
                                         location.appendChild(useHeadIfNotFound);

                                         Element compressionLevel = doc.createElement("compressionLevel");
                                         compressionLevel.setTextContent("-1");
                                         cvsRepository.appendChild(compressionLevel);

                                         Element excludedRegions = doc.createElement("excludedRegions");
                                         cvsRepository.appendChild(excludedRegions);

                                         Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                         excludedRegions.appendChild(excludedRegion);

                                         Element pattern = doc.createElement("pattern");
                                         excludedRegion.appendChild(pattern);

                                         Element cvsPassword1 = doc.createElement("password");
                                         cvsPassword1.setTextContent(temp1[i]);
                                         cvsRepository.appendChild(cvsPassword1);

                                         Element passwordRequired = doc.createElement("passwordRequired");
                                         passwordRequired.setTextContent("true");
                                         cvsRepository.appendChild(passwordRequired);

                                  }
                           }
                     }

                     else if (sourcecode.equalsIgnoreCase("GIT")) {

                           
                           
                           NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                           Node nodeRepositories11 = nodeListRepositories11.item(0);
                           Element userRemoteConfigs = (Element) nodeRepositories11;

                           if (!gitURL.isEmpty()) {

                                  temp = gitURL.split(delimiter);
                                  temp1 = gitBranch.split(delimiter);
                                  temp2 = projectBranch.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                         userRemoteConfigs.appendChild(moduleNode11);

                                         Element remoteNode11 = doc.createElement("url");
                                         remoteNode11.setTextContent(temp[i]);
                                         moduleNode11.appendChild(remoteNode11);

                                         NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                         Node nodeRepositories13 = nodeListRepositories13.item(0);
                                         Element branches = (Element) nodeRepositories13;

                                         Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                         branches.appendChild(moduleNode12);

                                         Element remoteNode12 = doc.createElement("name");
                                         remoteNode12.setTextContent(temp1[i]);
                                         moduleNode12.appendChild(remoteNode12);

                                         if (projectBranch.equalsIgnoreCase(",")) {

                                                Element element = (Element) doc
                                                              .getElementsByTagName("hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                                              .item(0);

                                                Node parent = element.getParentNode();

                                                parent.removeChild(element);

                                                parent.normalize();

                                         } else {
                                                NodeList nodeListRepositories12 = doc.getElementsByTagName("sparseCheckoutPaths");
                                                Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                Element moduleNode13 = doc
                                                              .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                sparseCheckoutPaths.appendChild(moduleNode13);
                                                Element nodeListRepositories22 = doc.createElement("path");
                                                nodeListRepositories22.setTextContent(temp2[i]);
                                                moduleNode13.appendChild(nodeListRepositories22);
                                         }
                                  }
                           }
                     }

                     String strURL1 = PropertyUtil.getPropValue("jenkinsUrl");
                     String strURL = strURL1.concat(jobName);

                     status = workFlowUtil.postXML(strURL, doc);

                     if (status == false) {
                           
                           yascajob.setCurrentState("YascaTest");
                           
                     }
              } catch (FileNotFoundException e) {
                     System.out.println("file not found exception");
              } catch (IOException e) {
                     System.out.println("IO Exception");
                     ;
              } catch (ParserConfigurationException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
              } catch (SAXException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();

              }

              
              if ("yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String yasca = "02";
                     String stage2 = wentity.getStageInfo();
                     wentity.setStageInfo(stage2 + yasca);

              }
              

              // String incidentId33=(String) jsonObject.get("workflowid");
              yascajob.setJobName((String) jsonObject.get("jobName"));
              jobRepo.save(yascajob);
              messageDTO.setMsg("Data created successfulsly");

              return messageDTO;
       }

       @Override
       public MessageDTO submitNewCheckmarx(JSONObject jsonObject) {
              JobEntity incidentEntity = new JobEntity();
              CheckMarxJobentity checkentity=new CheckMarxJobentity();
              WorkflowMasterEntity wentity = null;
              
              JSONObject jobj = new JSONObject();
              // String incidentId1 = (String) ((HashMap)
              // jsonObject.get("JobDetails")).get("jobId");

              // System.out.println("Aish"+incidentId1);
              // int job_id= Integer.parseInt(incidentId1);
              incidentEntity = new JobEntity();
              
              String jobName= jsonObject.get("jobName").toString();
         
              String stg = (String) jsonObject.get("Stage");
              
              // incidentEntity.setJobId(job_id);
              boolean status = false;
              String jenkinsusername = null;
              String jenkinspassword = null;
              String sourcecode=null;
              String svnURL = null;
              String module = null;
              String cvsRoot = null;
              String cvsPassword = null;
              String branchName = null;
              String tagName = null;
              String remoteName = null;
              String localName = null;
              String locationType = null;
              String gitURL =null;
              String gitBranch = null;
              String projectBranch = null;
            
              JobEntity checkjob=jobRepo.findByAppName1(jobName);
              checkjob.setStage("CheckMarx");
              checkjob.setCurrentState("CheckMarx");
              
              jenkinsusername=checkjob.getJenkinsUsername();
              jenkinspassword=checkjob.getJenkinsPassword();
              sourcecode=checkjob.getCodeBase();
              svnURL = checkjob.getSvnUrl();
              module = checkjob.getLocalModuleDirectory();
              cvsRoot = checkjob.getCvsRoot();
              cvsPassword = checkjob.getCvsPassword();
              branchName = checkjob.getBranchLocationName();
              tagName = checkjob.getTagLocationName();
              remoteName = checkjob.getRemoteName();
              localName = checkjob.getLocalName();
              locationType = checkjob.getCvsLocation();
              gitURL =checkjob.getGitUrl();
              gitBranch = checkjob.getGitBranch();
              projectBranch = checkjob.getProjectPathBranch();
              long idd=checkjob.getJobId();
              System.out.println("job idd is +"+idd);
              if ("Checkmarx".equalsIgnoreCase((String)jsonObject.get("Stage"))) {

                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Checkmarx$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(jobName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setJobName(jobName.split("_Checkmarx", 2)[0]);
                           jobName = incidentEntity.getJobName();

                     } else {
                           String suffix = "_Checkmarx";

                           String jobNameNew = jobName.concat(suffix);
                           incidentEntity.setJobName(jobNameNew);
                           jobName = incidentEntity.getJobName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println("job name is this"+jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }


              

              // incidentEntity.setReleaseDate(releaseDate);
              String[] temp;
              String[] temp1;
              String[] temp2;
              String[] temp3;
              String[] temp4;
              String[] temp5;
              String[] temp6;

              String delimiter = "\\,";

              String delimiter2 = ",";

              Object log;
              try {
                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jenkinsusername,
                                  jenkinspassword);

                     String teamCheckmarx = (String) jsonObject.get("Teamcheckmarx");
                     String presetCheckmarx = (String) jsonObject.get("PresetCheckmarx");

                     String checkmarxServerURL = (String) jsonObject.get("CheckmarxServerURL");
                     String checkmarxServerUsername = (String) jsonObject.get("CheckmarxServerUsername");
                     String checkmarxServerPasword = (String) jsonObject.get("CheckmarxServerPassword");

                     String sourceCharacterEncoding = (String) jsonObject.get("SourceCharacterEncoding");
                     System.out.println("team checkmarx is :"+teamCheckmarx);
                     
                     //jobRepo.findByJobId(jobnewid);
                     
                     System.out.println("idd is "+idd);
                   
                     checkjob.getJobId();
                     System.out.println("Job id is "+checkjob.getJobId());
                    
                     checkentity.setJobEntity(checkjob);
                     System.out.println("check job entity"+ checkentity.getJobEntity().getJobId());
                    
                     
                    // System.out.println("checkmarx getting is is :"+checkentity.getCheckmarxJobId());
                     checkentity.setCheckmarxJobId(checkjob.getJobId());
                     checkentity.setJobName(jobName);
                     checkentity.setTeamcheckmarx(teamCheckmarx);
                     checkentity.setPresetCheckmarx(presetCheckmarx);
                     checkentity.setCheckmarxServerUsername(checkmarxServerUsername);
                     checkentity.setCheckmarxServerPassword(checkmarxServerPasword);
                     checkentity.setUrlCheckmarx(checkmarxServerURL);
                     checkentity.setEmpId(1);
                     
                     String strXMLFilenameMaven = null;
                     if (sourcecode.equalsIgnoreCase("SVN")) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigCheckmarx");
                     } else if (sourcecode.equalsIgnoreCase("CVS")) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigCheckmarxCVS");
                     } else if (sourcecode.equalsIgnoreCase("GIT")) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigCheckmarxGIT");
                     }

                     File xmlFile = new File(strXMLFilenameMaven);

                     DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                     DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                     Document doc = dBuilder.parse(xmlFile);

                     NodeList permissionList = doc.getElementsByTagName("permission");
                     Node workspacePermission = permissionList.item(0);
                     workspacePermission.setTextContent("hudson.model.Item.Workspace:" + jenkinsusername);
                     Node buildPermission = permissionList.item(1);
                     buildPermission.setTextContent("hudson.model.Item.Build:" +jenkinsusername);
                     Node updatePermission = permissionList.item(2);
                     updatePermission.setTextContent("hudson.model.Run.Update:" + jenkinsusername);
                     Node readPermission = permissionList.item(3);
                     readPermission.setTextContent("hudson.model.Item.Read:" + jenkinsusername);
                     Node tagPermission = permissionList.item(4);
                     tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jenkinsusername);
                     Node configurePermission = permissionList.item(5);
                     configurePermission.setTextContent("hudson.model.Item.Configure:" + jenkinsusername);
                     Node discoverPermission = permissionList.item(6);
                     discoverPermission.setTextContent("hudson.model.Item.Discover:" + jenkinsusername);

                     if (sourcecode.equalsIgnoreCase("SVN")) {
                           

                           
                           NodeList nodeListLocation = doc.getElementsByTagName("locations");
                           Node nodeLoc = nodeListLocation.item(0);
                           Element locations = (Element) nodeLoc;

                           if (!svnURL.isEmpty()) {
                                  temp = svnURL.split(delimiter);
                                  temp1 = module.split(delimiter);
                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                         locations.appendChild(moduleNode);
                                         Element remoteNode = doc.createElement("remote");
                                         remoteNode.setTextContent(temp[i]);
                                         moduleNode.appendChild(remoteNode);
                                         Element local = doc.createElement("local");
                                         local.setTextContent(temp1[i]);
                                         moduleNode.appendChild(local);
                                         Element depth = doc.createElement("depthOption");
                                         depth.setTextContent("infinity");
                                         moduleNode.appendChild(depth);
                                         Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                         ignoreExternalsOption.setTextContent("false");
                                         moduleNode.appendChild(ignoreExternalsOption);
                                  }
                                  String new11 = incidentEntity.getHasMicroservice();
                                  incidentEntity.setHasMicroservice(new11);
                                  // System.out.println(chekcEntity.getAddMicroservice());

                                  if ("YES".equalsIgnoreCase(incidentEntity.getHasMicroservice())) {
                                         String[] svnUrl = incidentEntity.getSvnUrl().split(delimiter);

                                         String[] localModule = incidentEntity.getLocalModuleDirectory().split(delimiter);

                                         for (int i = 0; i < svnUrl.length; i++) {
                                                Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                                locations.appendChild(moduleNode);
                                                Element remoteNode = doc.createElement("remote");
                                                remoteNode.setTextContent(svnUrl[i]);
                                                moduleNode.appendChild(remoteNode);
                                                Element local = doc.createElement("local");
                                                local.setTextContent(localModule[i]);
                                                moduleNode.appendChild(local);
                                                Element depth = doc.createElement("depthOption");
                                                depth.setTextContent("infinity");
                                                moduleNode.appendChild(depth);
                                                Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                                ignoreExternalsOption.setTextContent("false");
                                                moduleNode.appendChild(ignoreExternalsOption);
                                         }
                                  }
                                  // if("NO".equalsIgnoreCase())

                           } else if (sourcecode.equalsIgnoreCase("CVS")) {
                           
                                  
                                  NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                                  Node nodeRepositories = nodeListRepositories.item(0);
                                  Element repositories = (Element) nodeRepositories;

                                  if (!cvsRoot.isEmpty()) {
                                         temp = cvsRoot.split(delimiter);
                                         temp1 = cvsPassword.split(delimiter);
                                         temp2 = branchName.split(delimiter);
                                         temp3 = remoteName.split(delimiter);
                                         temp4 = localName.split(delimiter);
                                         temp5 = locationType.split(delimiter);
                                         temp6 = tagName.split(delimiter);

                                         for (int i = 0; i < temp.length; i++) {

                                                Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                                repositories.appendChild(cvsRepository);

                                                Element cvsRootXml = doc.createElement("cvsRoot");
                                                cvsRootXml.setTextContent(temp[i]);
                                                cvsRepository.appendChild(cvsRootXml);

                                                Element repositoryItems = doc.createElement("repositoryItems");
                                                cvsRepository.appendChild(repositoryItems);

                                                Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                                repositoryItems.appendChild(cvsRepositoryItem);

                                                Element modules = doc.createElement("modules");
                                                cvsRepositoryItem.appendChild(modules);

                                                Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                                modules.appendChild(cvsModule);

                                                Element localName1 = doc.createElement("localName");
                                                localName1.setTextContent(temp4[i]);
                                                cvsModule.appendChild(localName1);

                                                Element remoteName1 = doc.createElement("remoteName");
                                                remoteName1.setTextContent(temp3[i]);
                                                cvsModule.appendChild(remoteName1);

                                                Element location = doc.createElement("location");
                                                if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                       location.setAttribute("class",
                                                                     "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                                }
                                                if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                       location.setAttribute("class",
                                                                     "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                                }
                                                if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                       location.setAttribute("class",
                                                                     "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                                }
                                                cvsRepositoryItem.appendChild(location);

                                                Element locationType1 = doc.createElement("locationType");
                                                locationType1.setTextContent(temp5[i]);
                                                location.appendChild(locationType1);

                                                Element locationName1 = doc.createElement("locationName");
                                                if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                       locationName1.setTextContent(temp2[i]);
                                                } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                       locationName1.setTextContent(temp6[i]);
                                                }
                                                location.appendChild(locationName1);

                                                Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                                if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                       useHeadIfNotFound.setTextContent("false");
                                                } else {
                                                       useHeadIfNotFound.setTextContent("true");
                                                }
                                                location.appendChild(useHeadIfNotFound);

                                                Element compressionLevel = doc.createElement("compressionLevel");
                                                compressionLevel.setTextContent("-1");
                                                cvsRepository.appendChild(compressionLevel);

                                                Element excludedRegions = doc.createElement("excludedRegions");
                                                cvsRepository.appendChild(excludedRegions);

                                                Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                                excludedRegions.appendChild(excludedRegion);

                                                Element pattern = doc.createElement("pattern");
                                                excludedRegion.appendChild(pattern);

                                                Element cvsPassword1 = doc.createElement("password");
                                                cvsPassword1.setTextContent(temp1[i]);
                                                cvsRepository.appendChild(cvsPassword1);

                                                Element passwordRequired = doc.createElement("passwordRequired");
                                                passwordRequired.setTextContent("true");
                                                cvsRepository.appendChild(passwordRequired);

                                         }
                                  }
                           }

                           else if (sourcecode.equalsIgnoreCase("GIT")) {

                                  
                                  
                                  NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                                  Node nodeRepositories11 = nodeListRepositories11.item(0);
                                  Element userRemoteConfigs = (Element) nodeRepositories11;

                                  if (!gitURL.isEmpty()) {

                                         temp = gitURL.split(delimiter);
                                         temp1 = gitBranch.split(delimiter);
                                         temp2 = projectBranch.split(delimiter);

                                         for (int i = 0; i < temp.length; i++) {
                                                Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                                userRemoteConfigs.appendChild(moduleNode11);

                                                Element remoteNode11 = doc.createElement("url");
                                                remoteNode11.setTextContent(temp[i]);
                                                moduleNode11.appendChild(remoteNode11);

                                                NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                                Node nodeRepositories13 = nodeListRepositories13.item(0);
                                                Element branches = (Element) nodeRepositories13;

                                                Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                                branches.appendChild(moduleNode12);

                                                Element remoteNode12 = doc.createElement("name");
                                                remoteNode12.setTextContent(temp1[i]);
                                                moduleNode12.appendChild(remoteNode12);

                                                if (projectBranch.equalsIgnoreCase(",")) {

                                                       Element element = (Element) doc
                                                                     .getElementsByTagName("hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                                                     .item(0);

                                                       Node parent = element.getParentNode();

                                                       parent.removeChild(element);

                                                       parent.normalize();

                                                } else {
                                                       NodeList nodeListRepositories12 = doc.getElementsByTagName("sparseCheckoutPaths");
                                                       Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                       Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                       Element moduleNode13 = doc
                                                                     .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                       sparseCheckoutPaths.appendChild(moduleNode13);
                                                       Element nodeListRepositories22 = doc.createElement("path");
                                                       nodeListRepositories22.setTextContent(temp2[i]);
                                                       moduleNode13.appendChild(nodeListRepositories22);
                                                }
                                         }
                                  }
                           }

                           NodeList nodeListTest = doc.getElementsByTagName("projectName");
                           Node nodeName = nodeListTest.item(0);
                           Element projectName1 = (Element) nodeName;
                           projectName1.setTextContent(jobName);

                           NodeList nodeListTeam = doc.getElementsByTagName("groupId");
                           Node nodeTeam = nodeListTeam.item(0);
                           Element team = (Element) nodeTeam;
                           team.setTextContent(teamCheckmarx);

                           NodeList nodeListPreset = doc.getElementsByTagName("preset");
                           Node nodePreset = nodeListPreset.item(0);
                           Element preset = (Element) nodePreset;
                           preset.setTextContent(presetCheckmarx);

                           NodeList nodeListConfig = doc.getElementsByTagName("sourceEncoding");
                           Node nodeConfig = nodeListConfig.item(0);
                           Element config = (Element) nodeConfig;
                           config.setTextContent(sourceCharacterEncoding);

                           // if server url is to be taken from user uncomment this block
                           NodeList nodeListCheckmarxServerURL = doc.getElementsByTagName("serverUrl");
                           Node nodeURL = nodeListCheckmarxServerURL.item(0);
                           Element URL = (Element) nodeURL;
                           URL.setTextContent(checkmarxServerURL);

                           NodeList nodeListCheckmarxServerUsername = doc.getElementsByTagName("username");
                           Node nodeUsername = nodeListCheckmarxServerUsername.item(0);
                           Element username = (Element) nodeUsername;
                           username.setTextContent(checkmarxServerUsername);

                           NodeList nodeListCheckmarxServerPassword = doc.getElementsByTagName("password");
                           Node nodePassword = nodeListCheckmarxServerPassword.item(0);
                           Element password = (Element) nodePassword;
                           password.setTextContent(checkmarxServerPasword);

                           String strURL1 = PropertyUtil.getPropValue("jenkinsUrl");
                           String strURL = strURL1.concat(jobName);

                           status = workFlowUtil.postXML(strURL, doc);

                     }
              } catch (FileNotFoundException e) {

                     System.out.println("FileNotFoundException");
              } catch (IOException e) {
                     System.out.println("IOException");

              } catch (ParserConfigurationException e) {
                     System.out.println("ParserConfigurationException");
              } catch (SAXException e) {
                     System.out.println("SAXException");
              }
              
              

              

              // String incidentId33=(String) jsonObject.get("workflowid");

              
              chRepo.save(checkentity);
              jobRepo.save(checkjob);
              messageDTO.setMsg("Data created successfully");

              return messageDTO;

       }

       @Override
       public MessageDTO submitDeploy(JSONObject jsonObject) {
              JobEntity incidentEntity = null;
              WorkflowMasterEntity wentity = null;
              JSONObject jobj = new JSONObject();
              // String incidentId1 = (String) ((HashMap)
              // jsonObject.get("JobDetails")).get("jobId");

              // System.out.println("Aish"+incidentId1);
              // int job_id= Integer.parseInt(incidentId1);
              incidentEntity = new JobEntity();
              
              DeployJenkinsJobEntity deployjenkinsjob=new DeployJenkinsJobEntity();
              String stg = (String) jsonObject.get("Stage");
             
              // incidentEntity.setJobId(job_id);
              String jenkinsusername = null;
              String jenkinspassword = null;
              String sourcecode=null;
              String svnURL = null;
              String module = null;
              String cvsRoot = null;
              String cvsPassword = null;
              String branchName = null;
              String tagName = null;
              String remoteName = null;
              String localName = null;
              String locationType = null;
              String gitURL =null;
              String gitBranch = null;
              String projectBranch = null;
              String jobName= jsonObject.get("jobName").toString();
              
			
              JobEntity deployjobtomcat=jobRepo.findByAppName1(jobName);
              jenkinsusername=deployjobtomcat.getJenkinsUsername();
              jenkinspassword=deployjobtomcat.getJenkinsPassword();
              sourcecode=deployjobtomcat.getCodeBase();
              svnURL = deployjobtomcat.getSvnUrl();
              module = deployjobtomcat.getLocalModuleDirectory();
              cvsRoot = deployjobtomcat.getCvsRoot();
              cvsPassword = deployjobtomcat.getCvsPassword();
              branchName = deployjobtomcat.getBranchLocationName();
              tagName = deployjobtomcat.getTagLocationName();
              remoteName = deployjobtomcat.getRemoteName();
              localName = deployjobtomcat.getLocalName();
              locationType = deployjobtomcat.getCvsLocation();
              gitURL =deployjobtomcat.getGitUrl();
              gitBranch = deployjobtomcat.getGitBranch();
              projectBranch = deployjobtomcat.getProjectPathBranch();
              long idd=deployjobtomcat.getJobId();
              deployjenkinsjob.setJobId(deployjobtomcat.getJobId());
              deployjenkinsjob.setJobName(jobName);
              deployjenkinsjob.setDeployTomcatId((int) deployjobtomcat.getJobId());
              if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Deploy$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(jobName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setJobName(jobName.split("_DeployTomcat", 2)[0]);
                           jobName = incidentEntity.getJobName();

                     } else {
                           String suffix = "_DeployTomcat";

                           String jobNameNew = jobName.concat(suffix);
                           incidentEntity.setJobName(jobNameNew);
                           jobName = incidentEntity.getJobName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
             

              // incidentEntity.setReleaseDate(releaseDate);
              String[] temp;
              String[] temp1;
              String[] temp2;
              String[] temp3;
              String[] temp4;
              String[] temp5;
              String[] temp6;
              boolean status = false;
              String war = (String) jsonObject.get("WarFilePath");
              String contextPath = (String) jsonObject.get("ContextPath");
              String delimiter = "\\,";
              
              Object log;
              //////////////////////////////////////////////////////////
              try {
                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jenkinsusername,
                                 jenkinspassword);
                     
                     /*String managerUserName = (String) jsonObject.get("ManagerUserName");
                     String managerPassWord = (String) jsonObject.get("ManagerPassWord");
                     
                     String tomcatUrl = (String) jsonObject.get("TomCatUrl");
                     deployjenkinsjob.setDeployTomcatId((int) deployjobtomcat.getJobId());
                     deployjenkinsjob.setJobName(jobName);
                     deployjenkinsjob.setTomcatUsername(managerUserName);
                     deployjenkinsjob.setTomcatPassword(managerPassWord);*/
                     
                     String encryptedPassword = "";
                     String tomcatmanagerUserName= null;
                     String tomcatmanagerPassword= null;
                     
                     String managerUserNameJboss= null;
                     String managerPassWordJboss= null;
                    
                     String strXMLFilenameMaven = null;
                     String url = (String) jsonObject.get("UrlDeploy");
                     System.out.println("url for deploy is "+url);
                     if ("SVN".equalsIgnoreCase((String)jsonObject.get("sourcecode"))) {
                    	 String svnurl=(String)jsonObject.get("svnurl");
                    	 String localmoduledir=(String)jsonObject.get("localmoduledir");
                    	 deployjenkinsjob.setSvnUrl(svnurl);
                    	 deployjenkinsjob.setLocalModuleDirectory(localmoduledir);
                    	 System.out.println("svn url is "+deployjenkinsjob.getSvnUrl());
                    	 System.out.println("svn local module dir is "+deployjenkinsjob.getLocalModuleDirectory());
                           if ("tomcat".equalsIgnoreCase((String) jsonObject.get("DeploySeverType"))) {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeploy");
                                  tomcatmanagerUserName = (String) jsonObject.get("ManagerUserName");
                                  tomcatmanagerUserName = (String) jsonObject.get("ManagerPassWord");
                                  url = (String) jsonObject.get("UrlDeploy");
                                  deployjenkinsjob.setTomcatUsername(tomcatmanagerUserName);
                                  deployjenkinsjob.setTomcatPassword(tomcatmanagerUserName);
                                  System.out.println("tomcat username is "+deployjenkinsjob.getTomcatUsername());
                                  System.out.println("Tomcat password is "+deployjenkinsjob.getTomcatPassword());
                                  
                           } else {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployJboss");
                                  managerUserNameJboss = (String) jsonObject.get("ManagerUserNameJboss");
                                  managerPassWordJboss = (String) jsonObject.get("ManagerPassWordJboss");
                                  url = (String) jsonObject.get("UrlDeploy");
                                  
                                  deployjenkinsjob.setManagerUserNameJboss(managerUserNameJboss);
                                  deployjenkinsjob.setManagerPassWordJboss(managerPassWordJboss);
                           }
                           
                     } else if ("CVS".equalsIgnoreCase(sourcecode)) {
                           if ("tomcat".equalsIgnoreCase((String) jsonObject.get("DeploySeverType"))) {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployCVS");
                                  tomcatmanagerUserName = (String) jsonObject.get("ManagerUserName");
                                  tomcatmanagerPassword = (String) jsonObject.get("ManagerPassWord");
                                  url = (String) jsonObject.get("UrlDeploy");
                                  deployjenkinsjob.setTomcatUsername(tomcatmanagerUserName);
                                  deployjenkinsjob.setTomcatPassword(tomcatmanagerUserName);
                           } else {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployJbossCVS");
                                  managerUserNameJboss = (String) jsonObject.get("ManagerUserNameJboss");
                                  managerPassWordJboss = (String) jsonObject.get("ManagerPassWordJboss");
                                  url = (String) jsonObject.get("UrlDeploy");
                                  deployjenkinsjob.setManagerUserNameJboss(managerUserNameJboss);
                                  deployjenkinsjob.setManagerPassWordJboss(managerPassWordJboss);
                           }
                     } else if ("GIT".equalsIgnoreCase(sourcecode)) {
                           if ("tomcat".equalsIgnoreCase((String) jsonObject.get("DeploySeverType"))) {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployGIT");
                                  tomcatmanagerUserName = (String) jsonObject.get("ManagerUserName");
                                  tomcatmanagerPassword = (String) jsonObject.get("ManagerPassWord");
                                  url = (String) jsonObject.get("UrlDeploy");
                                  deployjenkinsjob.setTomcatUsername(tomcatmanagerUserName);
                                  deployjenkinsjob.setTomcatPassword(tomcatmanagerUserName);
                           } else {
                                  strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployJbossGIT");
                                  managerUserNameJboss = (String) jsonObject.get("ManagerUserNameJboss");
                                  managerPassWordJboss = (String) jsonObject.get("ManagerPassWordJboss");
                                  url = (String) jsonObject.get("UrlDeploy");
                                  deployjenkinsjob.setManagerUserNameJboss(managerUserNameJboss);
                                  deployjenkinsjob.setManagerPassWordJboss(managerPassWordJboss);
                           }
                     }
                     
                     File xmlFile = new File(strXMLFilenameMaven);

                     DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                     DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                     Document doc = dBuilder.parse(xmlFile);

                     NodeList permissionList = doc.getElementsByTagName("permission");
                     Node workspacePermission = permissionList.item(0);
                     workspacePermission.setTextContent("hudson.model.Item.Workspace:" + jenkinsusername);
                     Node buildPermission = permissionList.item(1);
                     buildPermission.setTextContent("hudson.model.Item.Build:" + jenkinsusername);
                     Node updatePermission = permissionList.item(2);
                     updatePermission.setTextContent("hudson.model.Run.Update:" + jenkinsusername);
                     Node readPermission = permissionList.item(3);
                     readPermission.setTextContent("hudson.model.Item.Read:" + jenkinsusername);
                     Node tagPermission = permissionList.item(4);
                     tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jenkinsusername);
                     Node configurePermission = permissionList.item(5);
                     configurePermission.setTextContent("hudson.model.Item.Configure:" + jenkinsusername);
                     Node discoverPermission = permissionList.item(6);
                     discoverPermission.setTextContent("hudson.model.Item.Discover:" + jenkinsusername);

                     if ("SVN".equalsIgnoreCase(sourcecode)) {
                           
                           NodeList nodeListLocation = doc.getElementsByTagName("locations");
                           Node nodeLoc = nodeListLocation.item(0);
                           Element locations = (Element) nodeLoc;

                           if (!url.isEmpty()) {
                                  temp = url.split(delimiter);
                                  temp1 = module.split(delimiter);
                                  for (int i = 0; i < temp.length; i++) {

                                         Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                         locations.appendChild(moduleNode);
                                         Element remoteNode = doc.createElement("remote");
                                         remoteNode.setTextContent(temp[i]);
                                         moduleNode.appendChild(remoteNode);
                                         Element local = doc.createElement("local");
                                         local.setTextContent(temp1[i]);
                                         moduleNode.appendChild(local);
                                         Element depth = doc.createElement("depthOption");
                                         depth.setTextContent("infinity");
                                         moduleNode.appendChild(depth);
                                         Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                         ignoreExternalsOption.setTextContent("false");
                                         moduleNode.appendChild(ignoreExternalsOption);
                                  }
                           }
                     } else if ("CVS".equalsIgnoreCase(sourcecode)) {
                         
                           NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                           Node nodeRepositories = nodeListRepositories.item(0);
                           Element repositories = (Element) nodeRepositories;

                           if (!cvsRoot.isEmpty()) {
                                  temp = cvsRoot.split(delimiter);
                                  temp1 = cvsPassword.split(delimiter);
                                  temp2 = branchName.split(delimiter);
                                  temp3 = remoteName.split(delimiter);
                                  temp4 = localName.split(delimiter);
                                  temp5 = locationType.split(delimiter);
                                  temp6 = tagName.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {

                                         Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                         repositories.appendChild(cvsRepository);

                                         Element cvsRootXml = doc.createElement("cvsRoot");
                                         cvsRootXml.setTextContent(temp[i]);
                                         cvsRepository.appendChild(cvsRootXml);

                                         Element repositoryItems = doc.createElement("repositoryItems");
                                         cvsRepository.appendChild(repositoryItems);

                                         Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                         repositoryItems.appendChild(cvsRepositoryItem);

                                         Element modules = doc.createElement("modules");
                                         cvsRepositoryItem.appendChild(modules);

                                         Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                         modules.appendChild(cvsModule);

                                         Element localName1 = doc.createElement("localName");
                                         localName1.setTextContent(temp4[i]);
                                         cvsModule.appendChild(localName1);

                                         Element remoteName1 = doc.createElement("remoteName");
                                         remoteName1.setTextContent(temp3[i]);
                                         cvsModule.appendChild(remoteName1);

                                         Element location = doc.createElement("location");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                         }
                                         if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                         }
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                         }
                                         cvsRepositoryItem.appendChild(location);

                                         Element locationType1 = doc.createElement("locationType");
                                         locationType1.setTextContent(temp5[i]);
                                         location.appendChild(locationType1);

                                         Element locationName1 = doc.createElement("locationName");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp2[i]);
                                         } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp6[i]);
                                         }
                                         location.appendChild(locationName1);

                                         Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                useHeadIfNotFound.setTextContent("false");
                                         } else {
                                                useHeadIfNotFound.setTextContent("true");
                                         }
                                         location.appendChild(useHeadIfNotFound);

                                         Element compressionLevel = doc.createElement("compressionLevel");
                                         compressionLevel.setTextContent("-1");
                                         cvsRepository.appendChild(compressionLevel);

                                         Element excludedRegions = doc.createElement("excludedRegions");
                                         cvsRepository.appendChild(excludedRegions);

                                         Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                         excludedRegions.appendChild(excludedRegion);

                                         Element pattern = doc.createElement("pattern");
                                         excludedRegion.appendChild(pattern);

                                         Element cvsPassword1 = doc.createElement("password");
                                         cvsPassword1.setTextContent(temp1[i]);
                                         cvsRepository.appendChild(cvsPassword1);

                                         Element passwordRequired = doc.createElement("passwordRequired");
                                         passwordRequired.setTextContent("true");
                                         cvsRepository.appendChild(passwordRequired);

                                  }
                           }
                     } else if ("GIT".equalsIgnoreCase(sourcecode)) {

                         

                           NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                           Node nodeRepositories11 = nodeListRepositories11.item(0);
                           Element userRemoteConfigs = (Element) nodeRepositories11;

                           if (!gitURL.isEmpty()) {

                                  temp = gitURL.split(delimiter);
                                  temp1 = gitBranch.split(delimiter);
                                  temp2 = projectBranch.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                         userRemoteConfigs.appendChild(moduleNode11);

                                         Element remoteNode11 = doc.createElement("url");
                                         remoteNode11.setTextContent(temp[i]);
                                         moduleNode11.appendChild(remoteNode11);

                                         NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                         Node nodeRepositories13 = nodeListRepositories13.item(0);
                                         Element branches = (Element) nodeRepositories13;

                                         Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                         branches.appendChild(moduleNode12);

                                         Element remoteNode12 = doc.createElement("name");
                                         remoteNode12.setTextContent(temp1[i]);
                                         moduleNode12.appendChild(remoteNode12);

                                         if (projectBranch.equalsIgnoreCase(",")) {

                                                Element element = (Element) doc
                                                              .getElementsByTagName("hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                                              .item(0);

                                                Node parent = element.getParentNode();

                                                parent.removeChild(element);

                                                parent.normalize();

                                         } else {
                                                NodeList nodeListRepositories12 = doc.getElementsByTagName("sparseCheckoutPaths");
                                                Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                Element moduleNode13 = doc
                                                              .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                sparseCheckoutPaths.appendChild(moduleNode13);
                                                Element nodeListRepositories22 = doc.createElement("path");
                                                nodeListRepositories22.setTextContent(temp2[i]);
                                                moduleNode13.appendChild(nodeListRepositories22);
                                         }
                                  }
                           }
                     }

                     NodeList nodeListTest = doc.getElementsByTagName("userName");
                     Node nodeName = nodeListTest.item(0);
                     Element projectName1 = (Element) nodeName;
                     projectName1.setTextContent(tomcatmanagerUserName);

                     NodeList nodeListTeam = doc.getElementsByTagName("passwordScrambled");
                     Node nodeTeam = nodeListTeam.item(0);
                     Element team = (Element) nodeTeam;

                     // encryptedPassword = workFlowUtil.scramble(managerPassWord);

                     // team.setTextContent(encryptedPassword);

                     NodeList nodeListPreset = doc.getElementsByTagName("war");
                     Node nodePreset = nodeListPreset.item(0);
                     Element preset = (Element) nodePreset;
                     preset.setTextContent(war);

                     NodeList nodeListConfig = doc.getElementsByTagName("contextPath");
                     Node nodeConfig = nodeListConfig.item(0);
                     Element config = (Element) nodeConfig;
                     config.setTextContent(contextPath);

                     NodeList nodeListTomcat = doc.getElementsByTagName("url");
                     Node nodetomcat = nodeListTomcat.item(nodeListTomcat.getLength() - 1);

                     System.out.println("*******" + nodeListTomcat.getLength());

                     Element tomcat = (Element) nodetomcat;
                     tomcat.setTextContent(url);

                     String strURL1 = PropertyUtil.getPropValue("jenkinsUrl");
                     String strURL = strURL1.concat(jobName);

                     status = workFlowUtil.postXML(strURL, doc);

              } catch (FileNotFoundException e) {

                     System.out.println("FileNotFoundException");
              } catch (IOException e) {
                     System.out.println("IOException");

              } catch (ParserConfigurationException e) {
                     System.out.println("ParserConfigurationException");
              } catch (SAXException e) {
                     System.out.println("SAXException");
              }

             
              
              // String incidentId33=(String) jsonObject.get("workflowid");

              deployjobtomcat.setCurrentState(stg);
              deployjobtomcat.setStage(stg);
              jobRepo.save(deployjobtomcat);
              djRepo.save(deployjenkinsjob);
              messageDTO.setMsg("Data created successfully");

              return messageDTO;

       }

       @Override
       public MessageDTO submitNewPerformanceJob(JSONObject jsonObject) {
              JobEntity incidentEntity = new JobEntity();
             
              JSONObject jobj = new JSONObject();
              
              

             
              boolean status = false;
              String jenkinsusername = null;
              String jenkinspassword = null;
              String sourcecode=null;
              String svnURL = null;
              String module = null;
              String cvsRoot = null;
              String cvsPassword = null;
              String branchName = null;
              String tagName = null;
              String remoteName = null;
              String localName = null;
              String locationType = null;
              String gitURL =null;
              String gitBranch = null;
              String projectBranch = null;
			  
			  String jobName=(String)jsonObject.get("jobName");
              JobEntity performanceJob=jobRepo.findByAppName1(jobName);
              jenkinsusername=performanceJob.getJenkinsUsername();
              jenkinspassword=performanceJob.getJenkinsPassword();
              sourcecode=performanceJob.getCodeBase();
              svnURL = performanceJob.getSvnUrl();
              module = performanceJob.getLocalModuleDirectory();
              cvsRoot = performanceJob.getCvsRoot();
              cvsPassword = performanceJob.getCvsPassword();
              branchName = performanceJob.getBranchLocationName();
              tagName = performanceJob.getTagLocationName();
              remoteName = performanceJob.getRemoteName();
              localName = performanceJob.getLocalName();
              locationType = performanceJob.getCvsLocation();
              gitURL =performanceJob.getGitUrl();
              gitBranch = performanceJob.getGitBranch();
              projectBranch = performanceJob.getProjectPathBranch();
              long idd=performanceJob.getJobId();
              String stage=(String) jsonObject.get("Stage");
              performanceJob.setCurrentState(stage);
              performanceJob.setStage(stage);
             
              if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Performance$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(jobName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setJobName(jobName.split("_Performance", 2)[0]);
                           jobName = incidentEntity.getJobName();

                     } else {
                           String suffix = "_Performance";

                           String jobNameNew = jobName.concat(suffix);
                           incidentEntity.setJobName(jobNameNew);
                           jobName = incidentEntity.getJobName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }

              // incidentEntity.setReleaseDate(releaseDate);
              String[] temp;
              String[] temp1;
              String[] temp2;
              String[] temp3;
              String[] temp4;
              String[] temp5;
              String[] temp6;

              String delimiter = "\\,";

              Object log;

              try {
                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jenkinsusername,
                                 jenkinspassword);

                     String strXMLFilename = null;
                     if ("SVN".equalsIgnoreCase(sourcecode)) {
                           strXMLFilename = PropertyUtil.getPropValue("xmlConfigPerformance");
                     } else if ("CVS".equalsIgnoreCase(sourcecode)) {
                           strXMLFilename = PropertyUtil.getPropValue("xmlConfigPerformanceCVS");
                     } else if ("GIT".equalsIgnoreCase(sourcecode)) {
                           strXMLFilename = PropertyUtil.getPropValue("xmlConfigPerformanceGIT");
                     }

                     File xmlFile = new File(strXMLFilename);

                     DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                     DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                     Document doc = dBuilder.parse(xmlFile);

                     NodeList permissionList = doc.getElementsByTagName("permission");
                     Node workspacePermission = permissionList.item(0);
                     workspacePermission.setTextContent("hudson.model.Item.Workspace:" + jenkinsusername);
                     Node buildPermission = permissionList.item(1);
                     buildPermission.setTextContent("hudson.model.Item.Build:" + jenkinsusername);
                     Node updatePermission = permissionList.item(2);
                     updatePermission.setTextContent("hudson.model.Run.Update:" +jenkinsusername);
                     Node readPermission = permissionList.item(3);
                     readPermission.setTextContent("hudson.model.Item.Read:" + jenkinsusername);
                     Node tagPermission = permissionList.item(4);
                     tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jenkinsusername);
                     Node configurePermission = permissionList.item(5);
                     configurePermission.setTextContent("hudson.model.Item.Configure:" +jenkinsusername);
                     Node discoverPermission = permissionList.item(6);
                     discoverPermission.setTextContent("hudson.model.Item.Discover:" + jenkinsusername);

                     if ("SVN".equalsIgnoreCase(sourcecode)) {
                          
                           NodeList nodeListLocation = doc.getElementsByTagName("locations");
                           Node nodeLoc = nodeListLocation.item(0);
                           Element locations = (Element) nodeLoc;

                           if (!svnURL.isEmpty()) {
                                  temp = svnURL.split(delimiter);
                                  temp1 = module.split(delimiter);
                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                         locations.appendChild(moduleNode);
                                         Element remoteNode = doc.createElement("remote");
                                         remoteNode.setTextContent(temp[i]);
                                         moduleNode.appendChild(remoteNode);
                                         Element local = doc.createElement("local");
                                         local.setTextContent(temp1[i]);
                                         moduleNode.appendChild(local);
                                         Element depth = doc.createElement("depthOption");
                                         depth.setTextContent("infinity");
                                         moduleNode.appendChild(depth);
                                         Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                         ignoreExternalsOption.setTextContent("false");
                                         moduleNode.appendChild(ignoreExternalsOption);
                                  }
                           }
                     }

                     else if ("CVS".equalsIgnoreCase(sourcecode)) {
                          
                           NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                           Node nodeRepositories = nodeListRepositories.item(0);
                           Element repositories = (Element) nodeRepositories;

                           if (!cvsRoot.isEmpty()) {
                                  temp = cvsRoot.split(delimiter);
                                  temp1 = cvsPassword.split(delimiter);
                                  temp2 = branchName.split(delimiter);
                                  temp3 = remoteName.split(delimiter);
                                  temp4 = localName.split(delimiter);
                                  temp5 = locationType.split(delimiter);
                                  temp6 = tagName.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {

                                         Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                         repositories.appendChild(cvsRepository);

                                         Element cvsRootXml = doc.createElement("cvsRoot");
                                         cvsRootXml.setTextContent(temp[i]);
                                         cvsRepository.appendChild(cvsRootXml);

                                         Element repositoryItems = doc.createElement("repositoryItems");
                                         cvsRepository.appendChild(repositoryItems);

                                         Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                         repositoryItems.appendChild(cvsRepositoryItem);

                                         Element modules = doc.createElement("modules");
                                         cvsRepositoryItem.appendChild(modules);

                                         Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                         modules.appendChild(cvsModule);

                                         Element localName1 = doc.createElement("localName");
                                         localName1.setTextContent(temp4[i]);
                                         cvsModule.appendChild(localName1);

                                         Element remoteName1 = doc.createElement("remoteName");
                                         remoteName1.setTextContent(temp3[i]);
                                         cvsModule.appendChild(remoteName1);

                                         Element location = doc.createElement("location");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                         }
                                         if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                         }
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                         }
                                         cvsRepositoryItem.appendChild(location);

                                         Element locationType1 = doc.createElement("locationType");
                                         locationType1.setTextContent(temp5[i]);
                                         location.appendChild(locationType1);

                                         Element locationName1 = doc.createElement("locationName");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp2[i]);
                                         } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp6[i]);
                                         }
                                         location.appendChild(locationName1);

                                         Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                useHeadIfNotFound.setTextContent("false");
                                         } else {
                                                useHeadIfNotFound.setTextContent("true");
                                         }
                                         location.appendChild(useHeadIfNotFound);

                                         Element compressionLevel = doc.createElement("compressionLevel");
                                         compressionLevel.setTextContent("-1");
                                         cvsRepository.appendChild(compressionLevel);

                                         Element excludedRegions = doc.createElement("excludedRegions");
                                         cvsRepository.appendChild(excludedRegions);

                                         Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                         excludedRegions.appendChild(excludedRegion);

                                         Element pattern = doc.createElement("pattern");
                                         excludedRegion.appendChild(pattern);

                                         Element cvsPassword1 = doc.createElement("password");
                                         cvsPassword1.setTextContent(temp1[i]);
                                         cvsRepository.appendChild(cvsPassword1);

                                         Element passwordRequired = doc.createElement("passwordRequired");
                                         passwordRequired.setTextContent("true");
                                         cvsRepository.appendChild(passwordRequired);

                                  }
                           }
                     }

                     else if ("GIT".equalsIgnoreCase(sourcecode)) {
                          

                           NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                           Node nodeRepositories11 = nodeListRepositories11.item(0);
                           Element userRemoteConfigs = (Element) nodeRepositories11;

                           if (!gitURL.isEmpty()) {

                                  temp = gitURL.split(delimiter);
                                  temp1 = gitBranch.split(delimiter);
                                  temp2 = projectBranch.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                         userRemoteConfigs.appendChild(moduleNode11);

                                         Element remoteNode11 = doc.createElement("url");
                                         remoteNode11.setTextContent(temp[i]);
                                         moduleNode11.appendChild(remoteNode11);

                                         NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                         Node nodeRepositories13 = nodeListRepositories13.item(0);
                                         Element branches = (Element) nodeRepositories13;

                                         Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                         branches.appendChild(moduleNode12);

                                         Element remoteNode12 = doc.createElement("name");
                                         remoteNode12.setTextContent(temp1[i]);
                                         moduleNode12.appendChild(remoteNode12);

                                         if (projectBranch.equalsIgnoreCase(",")) {

                                                Element element = (Element) doc
                                                              .getElementsByTagName("hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                                              .item(0);

                                                Node parent = element.getParentNode();

                                                parent.removeChild(element);

                                                parent.normalize();

                                         } else {
                                                NodeList nodeListRepositories12 = doc.getElementsByTagName("sparseCheckoutPaths");
                                                Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                Element moduleNode13 = doc
                                                              .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                sparseCheckoutPaths.appendChild(moduleNode13);
                                                Element nodeListRepositories22 = doc.createElement("path");
                                                nodeListRepositories22.setTextContent(temp2[i]);
                                                moduleNode13.appendChild(nodeListRepositories22);
                                         }
                                  }
                           }
                     }

                     NodeList nodeList = doc.getElementsByTagName("defaultValue");
                     Node node = nodeList.item(0);
                     Element defaultValueNode = (Element) node;
                     defaultValueNode.setTextContent("[file_name]");
                     String filePath = defaultValueNode.getTextContent();
                     String newfilePath = filePath.replace("[file_name]", (CharSequence) jsonObject.get("JmxFile"));
                     defaultValueNode.setTextContent(newfilePath);

                     String strURL1 = PropertyUtil.getPropValue("jenkinsUrl");
                     String strURL = strURL1.concat(jobName);

                     status = workFlowUtil.postXML(strURL, doc);

              } catch (FileNotFoundException e) {
                     System.out.println("FileNotFoundException");
              } catch (IOException e) {
                     System.out.println("IOException");
              } catch (ParserConfigurationException e) {
                     System.out.println("ParserConfigurationException");
              } catch (SAXException e) {
                     System.out.println("SAXException");
              }

              

              // String incidentId33=(String) jsonObject.get("workflowid");

              
            
             
             jobRepo.save(performanceJob);
              messageDTO.setMsg("Data created successfully");

              return messageDTO;

       }

       @Override
       public MessageDTO submitNewRegressionJob(JSONObject jsonObject) {
              JobEntity incidentEntity = new JobEntity();
              
              JSONObject jobj = new JSONObject();
              // String incidentId1 = (String) ((HashMap)
              // jsonObject.get("JobDetails")).get("jobId");

              // System.out.println("Aish"+incidentId1);
              // int job_id= Integer.parseInt(incidentId1);
             

              String stg = (String) jsonObject.get("Stage");
             
              boolean status = false;
              String jenkinsusername = null;
              String jenkinspassword = null;
              String sourcecode=null;
              String svnURL = null;
              String module = null;
              String cvsRoot = null;
              String cvsPassword = null;
              String branchName = null;
              String tagName = null;
              String remoteName = null;
              String localName = null;
              String locationType = null;
              String gitURL =null;
              String gitBranch = null;
              String projectBranch = null;
			  
			  String jobName=(String)jsonObject.get("jobName");
              JobEntity regressionJob=jobRepo.findByAppName1(jobName);
              jenkinsusername=regressionJob.getJenkinsUsername();
              jenkinspassword=regressionJob.getJenkinsPassword();
              sourcecode=regressionJob.getCodeBase();
              svnURL = regressionJob.getSvnUrl();
              module = regressionJob.getLocalModuleDirectory();
              cvsRoot = regressionJob.getCvsRoot();
              cvsPassword = regressionJob.getCvsPassword();
              branchName = regressionJob.getBranchLocationName();
              tagName = regressionJob.getTagLocationName();
              remoteName = regressionJob.getRemoteName();
              localName = regressionJob.getLocalName();
              locationType = regressionJob.getCvsLocation();
              gitURL =regressionJob.getGitUrl();
              gitBranch = regressionJob.getGitBranch();
              projectBranch = regressionJob.getProjectPathBranch();
              long idd=regressionJob.getJobId();
			  
              regressionJob.setStage(stg);
              regressionJob.setCurrentState(stg);
              if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Regression$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(jobName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setJobName(jobName.split("_Regression", 2)[0]);
                           jobName = incidentEntity.getJobName();

                     } else {
                           String suffix = "_Regression";

                           String jobNameNew = jobName.concat(suffix);
                           System.out.println("new job name is :"+jobNameNew);
                           incidentEntity.setJobName(jobNameNew);
                           
                           jobName = incidentEntity.getJobName();// addition
                                                                                                                            // of
                                                                                                                            // suffix
                                                                                                                            // in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              
              // incidentEntity.setReleaseDate(releaseDate);
              String[] temp;
              String[] temp1;
              String[] temp2;
              String[] temp3;
              String[] temp4;
              String[] temp5;
              String[] temp6;

              String delimiter = "\\,";

              Object log;
              try {
                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jenkinsusername,
                                  jenkinspassword);

                     String strXMLFilenameMaven = null;
                     if ((sourcecode).equalsIgnoreCase("SVN")) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigRegression");
                     } else if ((sourcecode).equalsIgnoreCase("CVS")) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigRegressionCVS");
                     } else if ((sourcecode).equalsIgnoreCase("GIT")) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigRegressionGIT");
                     }
                     File xmlFile = new File(strXMLFilenameMaven);
                     DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                     DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                     Document doc = dBuilder.parse(xmlFile);

                     NodeList permissionList = doc.getElementsByTagName("permission");
                     Node workspacePermission = permissionList.item(0);
                     workspacePermission.setTextContent("hudson.model.Item.Workspace:" + jenkinsusername);
                     Node buildPermission = permissionList.item(1);
                     buildPermission.setTextContent("hudson.model.Item.Build:" + jenkinsusername);
                     Node updatePermission = permissionList.item(2);
                     updatePermission.setTextContent("hudson.model.Run.Update:" + jenkinsusername);
                     Node readPermission = permissionList.item(3);
                     readPermission.setTextContent("hudson.model.Item.Read:" + jenkinsusername);
                     Node tagPermission = permissionList.item(4);
                     tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jenkinsusername);
                     Node configurePermission = permissionList.item(5);
                     configurePermission.setTextContent("hudson.model.Item.Configure:" +jenkinsusername);
                     Node discoverPermission = permissionList.item(6);
                     discoverPermission.setTextContent("hudson.model.Item.Discover:" + jenkinsusername);

                     if ((sourcecode).equalsIgnoreCase("SVN")) {
                           

                           NodeList nodeListLocation = doc.getElementsByTagName("locations");
                           Node nodeLoc = nodeListLocation.item(0);
                           Element locations = (Element) nodeLoc;

                           if (!svnURL.isEmpty()) {
                                  temp = svnURL.split(delimiter);
                                  temp1 = module.split(delimiter);
                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                         locations.appendChild(moduleNode);
                                         Element remoteNode = doc.createElement("remote");
                                         remoteNode.setTextContent(temp[i]);
                                         moduleNode.appendChild(remoteNode);
                                         Element local = doc.createElement("local");
                                         local.setTextContent(temp1[i]);
                                         moduleNode.appendChild(local);
                                         Element depth = doc.createElement("depthOption");
                                         depth.setTextContent("infinity");
                                         moduleNode.appendChild(depth);
                                         Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                         ignoreExternalsOption.setTextContent("false");
                                         moduleNode.appendChild(ignoreExternalsOption);
                                  }
                           }
                     } else if ((sourcecode).equalsIgnoreCase("CVS")) {
                          
                           NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                           Node nodeRepositories = nodeListRepositories.item(0);
                           Element repositories = (Element) nodeRepositories;

                           if (!cvsRoot.isEmpty()) {
                                  temp = cvsRoot.split(delimiter);
                                  temp1 = cvsPassword.split(delimiter);
                                  temp2 = branchName.split(delimiter);
                                  temp3 = remoteName.split(delimiter);
                                  temp4 = localName.split(delimiter);
                                  temp5 = locationType.split(delimiter);
                                  temp6 = tagName.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                         repositories.appendChild(cvsRepository);

                                         Element cvsRootXml = doc.createElement("cvsRoot");
                                         cvsRootXml.setTextContent(temp[i]);
                                         cvsRepository.appendChild(cvsRootXml);

                                         Element repositoryItems = doc.createElement("repositoryItems");
                                         cvsRepository.appendChild(repositoryItems);

                                         Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                         repositoryItems.appendChild(cvsRepositoryItem);

                                         Element modules = doc.createElement("modules");
                                         cvsRepositoryItem.appendChild(modules);

                                         Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                         modules.appendChild(cvsModule);

                                         Element localName1 = doc.createElement("localName");
                                         localName1.setTextContent(temp4[i]);
                                         cvsModule.appendChild(localName1);

                                         Element remoteName1 = doc.createElement("remoteName");
                                         remoteName1.setTextContent(temp3[i]);
                                         cvsModule.appendChild(remoteName1);

                                         Element location = doc.createElement("location");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                         }
                                         if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                         }
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                         }
                                         cvsRepositoryItem.appendChild(location);

                                         Element locationType1 = doc.createElement("locationType");
                                         locationType1.setTextContent(temp5[i]);
                                         location.appendChild(locationType1);

                                         Element locationName1 = doc.createElement("locationName");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp2[i]);
                                         } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp6[i]);
                                         }
                                         location.appendChild(locationName1);

                                         Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                useHeadIfNotFound.setTextContent("false");
                                         } else {
                                                useHeadIfNotFound.setTextContent("true");
                                         }
                                         location.appendChild(useHeadIfNotFound);

                                         Element compressionLevel = doc.createElement("compressionLevel");
                                         compressionLevel.setTextContent("-1");
                                         cvsRepository.appendChild(compressionLevel);

                                         Element excludedRegions = doc.createElement("excludedRegions");
                                         cvsRepository.appendChild(excludedRegions);

                                         Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                         excludedRegions.appendChild(excludedRegion);

                                         Element pattern = doc.createElement("pattern");
                                         excludedRegion.appendChild(pattern);

                                         Element cvsPassword1 = doc.createElement("password");
                                         cvsPassword1.setTextContent(temp1[i]);
                                         cvsRepository.appendChild(cvsPassword1);

                                         Element passwordRequired = doc.createElement("passwordRequired");
                                         passwordRequired.setTextContent("true");
                                         cvsRepository.appendChild(passwordRequired);
                                  }
                           }
                     }

                     else if ((sourcecode).equalsIgnoreCase("GIT")) {
                           

                           NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                           Node nodeRepositories11 = nodeListRepositories11.item(0);
                           Element userRemoteConfigs = (Element) nodeRepositories11;

                           if (!gitURL.isEmpty()) {

                                  temp = gitURL.split(delimiter);
                                  temp1 = gitBranch.split(delimiter);
                                  temp2 = projectBranch.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                         userRemoteConfigs.appendChild(moduleNode11);

                                         Element remoteNode11 = doc.createElement("url");
                                         remoteNode11.setTextContent(temp[i]);
                                         moduleNode11.appendChild(remoteNode11);

                                         NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                         Node nodeRepositories13 = nodeListRepositories13.item(0);
                                         Element branches = (Element) nodeRepositories13;

                                         Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                         branches.appendChild(moduleNode12);

                                         Element remoteNode12 = doc.createElement("name");
                                         remoteNode12.setTextContent(temp1[i]);
                                         moduleNode12.appendChild(remoteNode12);

                                         if (projectBranch.equalsIgnoreCase(",")) {

                                                Element element = (Element) doc
                                                              .getElementsByTagName("hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                                              .item(0);

                                                Node parent = element.getParentNode();

                                                parent.removeChild(element);

                                                parent.normalize();

                                         } else {
                                                NodeList nodeListRepositories12 = doc.getElementsByTagName("sparseCheckoutPaths");
                                                Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                Element moduleNode13 = doc
                                                              .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                sparseCheckoutPaths.appendChild(moduleNode13);
                                                Element nodeListRepositories22 = doc.createElement("path");
                                                nodeListRepositories22.setTextContent(temp2[i]);
                                                moduleNode13.appendChild(nodeListRepositories22);
                                         }
                                  }
                           }
                     }

                     String strURL1 = PropertyUtil.getPropValue("jenkinsUrl");
                     String strURL = strURL1.concat(jobName);
                     status = workFlowUtil.postXML(strURL, doc);

              } catch (FileNotFoundException e) {
                     System.out.println("FileNotFoundException");
              } catch (IOException e) {
                     System.out.println("IOException");
              } catch (ParserConfigurationException e) {
                     System.out.println("ParserConfigurationException");
              } catch (SAXException e) {
                     System.out.println("SAXException");

              }

             

              // String incidentId33=(String) jsonObject.get("workflowid");

             jobRepo.save(regressionJob);

              messageDTO.setMsg("Data created successfully");

              return messageDTO;

       }

       @Override
       public MessageDTO buildJob(JSONObject jsonObject) {
              boolean status = false;
              String jenkinsusername = null;
              String jenkinspassword = null;
              
              String jobName=jsonObject.get("jobName").toString();
              System.out.println("Here job name is "+jobName);
              try {
                     JobEntity jobentityforbuild=jobRepo.findByAppName1(jobName);
                     
                     
                           jenkinsusername=jobentityforbuild.getJenkinsUsername();
                           jenkinspassword=jobentityforbuild.getJenkinsPassword();
                           
                           
                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jenkinsusername,
                                  jenkinspassword);

                     String jobNameNew=null;

                     if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                           String projectNamePatten = "^[a-zA-Z]{3,25}?_CodeQuality$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  jobentityforbuild.setJobName(jobName.split("_CodeQuality", 2)[0]);
                                  jobName = jobentityforbuild.getJobName();

                           } else {
                                  String suffix = "_CodeQuality";

                                   jobNameNew = jobName.concat(suffix);
                                  //jobentityforbuild.setJobName(jobNameNew);
                                  jobName = jobentityforbuild.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuildWithParameters");
                           String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", jobNameNew);

                           String statusString = workFlowUtil.postURL(jenkinsUrlBuild);
                           System.out.println("Now the project name " + jobName);
                           viewReports(jsonObject);

                     }
                     
                     if ("JUnitSonarEmma".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                         String projectNamePatten = "^[a-zA-Z]{3,25}?_JUnitSonarEmma$";
                         Pattern r = Pattern.compile(projectNamePatten);
                         Matcher m = r.matcher(jobName);
                         if (m.find()) {
                                // boolean validJobName = validateJobName(jsonObject,
                                // projectName);
                                jobentityforbuild.setJobName(jobName.split("_JUnitSonarEmma", 2)[0]);
                                jobName = jobentityforbuild.getJobName();

                         } else {
                                String suffix = "_JUnitSonarEmma";

                                 jobNameNew = jobName.concat(suffix);
                                //jobentityforbuild.setJobName(jobNameNew);
                                //jobName = jobentityforbuild.getJobName();// addition
                                                                                                                                // of
                                                                                                                                // suffix
                                                                                                                                // in
                                System.out.println(jobNameNew); // app name
                                // validJobName = validateJobName(jsonObject, jobNameNew);
                         }
                         final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuildWithParameters");
                         String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", jobName);
                         System.out.println(jenkinsUrlBuild);
                         String statusString = workFlowUtil.postURL(jenkinsUrlBuild);
                         System.out.println("Now the project name " + jobName);
                         viewReports(jsonObject);

                   }
                     
                     if ("Yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Yasca$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  jobentityforbuild.setJobName(jobName.split("_Yasca", 2)[0]);
                                  jobName = jobentityforbuild.getJobName();

                           } else {
                                  String suffix = "_Yasca";

                                   jobNameNew = jobName.concat(suffix);
                                  //jobentityforbuild.setJobName(jobNameNew);
                                  //jobName = jobentityforbuild.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuild");
                           String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", jobNameNew);
                           System.out.println(jenkinsUrlBuild);
                           String statusString = workFlowUtil.postURL(jenkinsUrlBuild);
                           System.out.println("Now the project name " + jobName);
                           viewReports(jsonObject);
                     }
                     if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Checkmarx$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  jobentityforbuild.setJobName(jobName.split("_Checkmarx", 2)[0]);
                                  jobName = jobentityforbuild.getJobName();

                           } else {
                                  String suffix = "_Checkmarx";

                                   jobNameNew = jobName.concat(suffix);
                                 // jobentityforbuild.setJobName(jobNameNew);
                                  jobName = jobentityforbuild.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuild");
                           String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", jobNameNew);
                           System.out.println(jenkinsUrlBuild);
                           String statusString = workFlowUtil.postURL(jenkinsUrlBuild);
                           System.out.println("Now the project name " + jobName);
                           viewReports(jsonObject);
                     }
                     if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Deploy$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  jobentityforbuild.setJobName(jobName.split("_DeployTomcat", 2)[0]);
                                  jobName = jobentityforbuild.getJobName();

                           } else {
                                  String suffix = "_DeployTomcat";

                                   jobNameNew = jobName.concat(suffix);
                                  //jobentityforbuild.setJobName(jobNameNew);
                                  jobName = jobentityforbuild.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuild");
                           String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", jobNameNew);
                           System.out.println(jenkinsUrlBuild);
                           String statusString = workFlowUtil.postURL(jenkinsUrlBuild);
                           System.out.println("Now the project name " + jobName);
                           viewReports(jsonObject);
                     }
                     if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Deploy$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  jobentityforbuild.setJobName(jobName.split("_Deploychef", 2)[0]);
                                  jobName = jobentityforbuild.getJobName();

                           } else {
                                  String suffix = "_Deploychef";

                                   jobNameNew = jobName.concat(suffix);
                                  //jobentityforbuild.setJobName(jobNameNew);
                                  jobName = jobentityforbuild.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuild");
                           String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", jobNameNew);
                           System.out.println(jenkinsUrlBuild);
                           String statusString = workFlowUtil.postURL(jenkinsUrlBuild);
                           System.out.println("Now the project name " + jobName);
                           viewReports(jsonObject);
                     }
                     if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Deploy$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  jobentityforbuild.setJobName(jobName.split("_Deploycf", 2)[0]);
                                  jobName = jobentityforbuild.getJobName();

                           } else {
                                  String suffix = "_Deploycf";

                                   jobNameNew = jobName.concat(suffix);
                                 // jobentityforbuild.setJobName(jobNameNew);
                                  jobName = jobentityforbuild.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuild");
                           String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", jobNameNew);

                           String statusString = workFlowUtil.postURL(jenkinsUrlBuild);
                           System.out.println("Now the project name " + jobName);
                           viewReports(jsonObject);
                     }
                     if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Regression$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  jobentityforbuild.setJobName(jobName.split("_Regression", 2)[0]);
                                  jobName = jobentityforbuild.getJobName();

                           } else {
                                  String suffix = "_Regression";

                                   jobNameNew = jobName.concat(suffix);
                                  //jobentityforbuild.setJobName(jobNameNew);
                                  jobName = jobentityforbuild.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuild");
                           String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", jobNameNew);
                           System.out.println("jenkinsUrlBuild"+jenkinsUrlBuild);

                           String statusString = workFlowUtil.postURL(jenkinsUrlBuild);
                           System.out.println("Now the project name " + jobName);
                           viewReports(jsonObject);
                     }
                     if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                    	 System.out.println("current stage is "+(String) jsonObject.get("Stage"));
                    	 String jmxname="aish";
                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Performance$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  jobentityforbuild.setJobName(jobName.split("_Performance", 2)[0]);
                                  jobName = jobentityforbuild.getJobName();

                           } else {
                                  String suffix = "_Performance";

                                   jobNameNew = jobName.concat(suffix);
                                 // jobentityforbuild.setJobName(jobNameNew);
                                  jobName = jobentityforbuild.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println("jobNameNew is this "+jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlForPerformanceBuild");
                           String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", jobNameNew);
                           System.out.println(jenkinsUrlBuild);
                          String jmxNameReplaced = jenkinsUrlBuild.replace("[jmx_filename]",
                        	   					jmxname);
                          System.out.println("Jmcnamereplaced is "+jmxNameReplaced);
                        	String statusString = workFlowUtil.postURL(jmxNameReplaced); 
                        	//String statusString = workFlowUtil.postURL(jenkinsUrlBuild);
                           System.out.println("Now the project name " + jobName);
                           viewReports(jsonObject);
                           
                          // messageDTO.setMsg("Job Build Successfully");
                     }

              } catch (FileNotFoundException e) {
                     e.printStackTrace();

              } catch (IOException e) {

                     e.printStackTrace();
              }

              return messageDTO;
       }

       @Override
       public MessageDTO viewReports(JSONObject jsonObject) {
              
              String jobName=jsonObject.get("jobName").toString();
              System.out.println("Job NAme "+jobName);
              String jobName1=jsonObject.get("jobName").toString();
              
              System.out.println("Job NAme1 "+jobName1);
              System.out.println("inside view reports");
              // String testResult;
              System.out.println("codebase" + jsonObject.get("CodeBase"));
              

                     
                     if ("CodeQuality".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                           String projectNamePatten = "^[a-zA-Z]{3,25}?_CodeQuality$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                 // incidentEntity.setJobName(jobName.split("_CodeQuality", 2)[0]);
                                  jobName = incidentEntity.getJobName();

                           } else {
                                  String suffix = "_CodeQuality";

                                  String jobNameNew = jobName.concat(suffix);
                                 // incidentEntity.setJobName(jobNameNew);
                                  jobName = incidentEntity.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           System.out.println("fetching sonar report for "+jobName1);
                           fetchJunitSonarReport(jobName1);
                          
                     }
                     
                     if ("JUnitSonarEmma".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                         String projectNamePatten = "^[a-zA-Z]{3,25}?_JUnitSonarEmma$";
                         Pattern r = Pattern.compile(projectNamePatten);
                         Matcher m = r.matcher(jobName);
                         if (m.find()) {
                                // boolean validJobName = validateJobName(jsonObject,
                                // projectName);
                                incidentEntity.setJobName(jobName.split("_JUnitSonarEmma", 2)[0]);
                                jobName = incidentEntity.getJobName();

                         } else {
                                String suffix = "_JUnitSonarEmma";

                                String jobNameNew = jobName.concat(suffix);
                                incidentEntity.setJobName(jobNameNew);
                                jobName = incidentEntity.getJobName();// addition
                                                                                                                                // of
                                                                                                                                // suffix
                                                                                                                                // in
                                System.out.println(jobNameNew); // app name
                                // validJobName = validateJobName(jsonObject, jobNameNew);
                         }
                         System.out.println("fetching sonar report for "+jobName1);
                         fetchJunitSonarReport(jobName1);
                   }
                     
                     
                     if ("Yasca".equalsIgnoreCase((String) jsonObject.get("Stage"))) {
                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Yasca$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  incidentEntity.setJobName(jobName.split("_Yasca", 2)[0]);
                                  jobName = incidentEntity.getJobName();

                           } else {
                                  String suffix = "_Yasca";

                                  String jobNameNew = jobName.concat(suffix);
                                  incidentEntity.setJobName(jobNameNew);
                                  jobName = incidentEntity.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           fetchYascaMetrixReport(jsonObject, jobName1);
                           System.out.println("or here after fetch yasca is called");

                     }
                     if ("Checkmarx".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Checkmarx$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  incidentEntity.setJobName(jobName.split("_Checkmarx", 2)[0]);
                                  jobName = incidentEntity.getApplicationName();

                           } else {
                                  String suffix = "_Checkmarx";

                                  String jobNameNew = jobName.concat(suffix);
                                  incidentEntity.setJobName(jobNameNew);
                                  jobName = incidentEntity.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }

                     }
                     if ("DeployTomcat".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Deploy$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  incidentEntity.setJobName(jobName.split("_DeployTomcat", 2)[0]);
                                  jobName = incidentEntity.getJobName();

                           } else {
                                  String suffix = "_DeployTomcat";

                                  String jobNameNew = jobName.concat(suffix);
                                  incidentEntity.setJobName(jobNameNew);
                                  jobName = incidentEntity.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           buildDeployJob(jsonObject, jobName1);
                     }
                     if ("DeployChef".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Deploy$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                   // projectName);
                                  incidentEntity.setJobName(jobName.split("_Deploy", 2)[0]);
                                  jobName = incidentEntity.getJobName();

                           } else {
                                  String suffix = "_Deploy";

                                  String jobNameNew = jobName.concat(suffix);
                                  incidentEntity.setJobName(jobNameNew);
                                  jobName = incidentEntity.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           buildDeployJob(jsonObject, jobName1);
                     }
                     if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Deploy$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  incidentEntity.setJobName(jobName.split("_Deploy", 2)[0]);
                                  jobName = incidentEntity.getJobName();

                           } else {
                                  String suffix = "_Deploycf";

                                  String jobNameNew = jobName.concat(suffix);
                                  incidentEntity.setJobName(jobNameNew);
                                  jobName = incidentEntity.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           buildDeployCfJob(jsonObject, jobName);
                     }
                     if ("Regression".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Regression$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  incidentEntity.setJobName(jobName.split("_Regression", 2)[0]);
                                  jobName = incidentEntity.getJobName();

                           } else {
                                  String suffix = "_Regression";

                                  String jobNameNew = jobName.concat(suffix);
                                  incidentEntity.setJobName(jobNameNew);
                                  jobName = incidentEntity.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           fetchRegressionTestReport(jsonObject, jobName1);
                     }
                     if ("Performance".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                           String projectNamePatten = "^[a-zA-Z]{3,25}?_Performance$";
                           Pattern r = Pattern.compile(projectNamePatten);
                           Matcher m = r.matcher(jobName);
                           if (m.find()) {
                                  // boolean validJobName = validateJobName(jsonObject,
                                  // projectName);
                                  incidentEntity.setJobName(jobName.split("_Performance", 2)[0]);
                                  jobName = incidentEntity.getJobName();

                           } else {
                                  String suffix = "_Performance";

                                  String jobNameNew = jobName.concat(suffix);
                                  incidentEntity.setJobName(jobNameNew);
                                  jobName = incidentEntity.getJobName();// addition
                                                                                                                                  // of
                                                                                                                                  // suffix
                                                                                                                                  // in
                                  System.out.println(jobNameNew); // app name
                                  // validJobName = validateJobName(jsonObject, jobNameNew);
                           }
                           getPerformanceJobName(jsonObject, jobName1);
                     }
                     System.out.println("Bfr updateProjectMethodEntry**********" + jsonObject);
                     // updateProject(jsonObject); // update and insert onto DB
              
System.out.println("or here at the end ");
              return messageDTO;
       }

       @Override
       public MessageDTO fetchJunitSonarReport(String microservicename) {
          String jobName=microservicename;
          String jobNamefinal=microservicename;
          
          CodeQualityJobEntity cincident=new CodeQualityJobEntity();
       long jobId = jobRepo.fetchJobId(jobNamefinal);
       JobEntity jjentity=new JobEntity();
       jjentity=jobRepo.findByAppName1(jobNamefinal);
          cincident.setJobEntity(jjentity);
          
       
              //cincident.setBuildStatus("Success");
              cincident.setJobName(jobNamefinal);
       cincident.setCodequalityId((int) jjentity.getJobId());
       
          System.out.println("microaseervice name is "+jobNamefinal);
          JobEntity jentity=new JobEntity();
          System.out.println("Hi m in fetcg sonar report");
              String xmlApiRecord = null;
              XmlReadUtil xmlReadUtil = new XmlReadUtil();
              String jenkinsusername = "automation";
              String jenkinspassword = "automation@2016";
              /* String sourcecode=null;
              String svnURL = null;
              String module = null;
              String cvsRoot = null;
              String cvsPassword = null;
              String branchName = null;
              String tagName = null;
              String remoteName = null;
              String localName = null;
              String locationType = null;
              String gitURL =null;
              String gitBranch = null;
              String projectBranch = null;*/
              
             
                 

              
              
              
              
              //JobEntity incidentEntity1=jobRepo.findByAppName1(microservicename);
              System.out.println("Hi i successfully passed from here seeee");
              /* System.out.println("Mocroservice Name "+microservicename);*/
              
                    // jenkinsusername=incidentEntity1.getJenkinsUsername();
                    // System.out.println("jenkinsusername "+jenkinsusername);
                 //    jenkinspassword=incidentEntity1.getJenkinsPassword();
                     /* sourcecode=incidentEntity1.getCodeBase();
                     svnURL = incidentEntity1.getSvnUrl();
                     module = incidentEntity1.getLocalModuleDirectory();
                     cvsRoot = incidentEntity1.getCvsRoot();
                     cvsPassword = incidentEntity1.getCvsPassword();
                     branchName = incidentEntity1.getBranchLocationName();
                     tagName = incidentEntity1.getTagLocationName();
                     remoteName = incidentEntity1.getRemoteName();
                     localName = incidentEntity1.getLocalName();
                     locationType = incidentEntity1.getCvsLocation();
                     gitURL =incidentEntity1.getGitUrl();
                     gitBranch = incidentEntity1.getGitBranch();
                     projectBranch = incidentEntity1.getProjectPathBranch();*/
                     
                     
                                  String projectNamePatten = "^[a-zA-Z]{3,25}?_CodeQuality$";
                                  Pattern r = Pattern.compile(projectNamePatten);
                                  Matcher m = r.matcher(microservicename);
                                  if (m.find()) {
                                         // boolean validJobName = validateJobName(jsonObject,
                                         // projectName);
                                         //incidentEntity.setJobName(microservicename.split("_CodeQuality", 2)[0]);
                                         microservicename = incidentEntity.getJobName();
                                         String suffix = "_CodeQuality";

                                         String jobNameNew = microservicename.concat(suffix);
                                         //incidentEntity.setJobName(jobNameNew);
                                         microservicename = incidentEntity.getJobName();// addition
                                                                                                                                         // of
                                                                                                                                         // suffix
                                                                                                                                         // in
                                         System.out.println(jobNameNew); // app name
                                         // validJobName = validateJobName(jsonObject, jobNameNew);
                                  }
                                  projectNamePatten = "^[a-zA-Z]{3,25}?_JUnitSonarEmma$";
                                   r = Pattern.compile(projectNamePatten);
                                   m = r.matcher(microservicename);
                                  if (m.find()) {
                                      // boolean validJobName = validateJobName(jsonObject,
                                      // projectName);
                                      incidentEntity.setJobName(microservicename.split("_JUnitSonarEmma", 2)[0]);
                                      microservicename = incidentEntity.getJobName();
                                      String suffix = "_JUnitSonarEmma";

                                      String jobNameNew = microservicename.concat(suffix);
                                      incidentEntity.setJobName(jobNameNew);
                                      microservicename = incidentEntity.getJobName();// addition
                                                                                                                                      // of
                                                                                                                                      // suffix
                                                                                                                                      // in
                                      System.out.println(jobNameNew); // app name
                                      // validJobName = validateJobName(jsonObject, jobNameNew);
                               }
                                 
                           
              try {
                     DevOpsWorkFlowUtil devOpsWorkFlowUtil = new DevOpsWorkFlowUtil(jenkinsusername,
                                  jenkinspassword);
                     String jenkinsUrl = PropertyUtil.getPropValue("jenkinsUrlForXML");
                     String jenkinsUrlTest = jenkinsUrl.replace("[project_name]", microservicename);
                     String jenkinsUrlSONAR1 = PropertyUtil.getPropValue("jenkinsUrlForSONAR");
                     
                     
                     System.out.println("155 jenkinsurlSONAR1 is "+jenkinsUrlSONAR1);
                     
                     String xmlapiurl1 = PropertyUtil.getPropValue("xmlapiurl");
                     microservicename=microservicename+"_CodeQuality";
                     System.out.println("microservicename is this :"+microservicename);
                     jenkinsUrlSONAR1 = jenkinsUrlSONAR1.replace("[project_name]", microservicename);
                     String xmlapiurl = xmlapiurl1.replace("[project_name]", microservicename);
                     System.out.println("xmlapiurl is : "+xmlapiurl);
                     xmlApiRecord = devOpsWorkFlowUtil.postURL(xmlapiurl);
                     System.out.println("xmlapirecord");
                     String jenkinsUrlSONAR = jenkinsUrlSONAR1.replace("[project_name]", microservicename);
                     System.out.println("jenkinsUrlSONAR is :"+jenkinsUrlSONAR);
                     String xmlRecords = null;
                     System.out.println("jenkinsUrlTest are :"+jenkinsUrlTest);
                     xmlRecords = devOpsWorkFlowUtil.postURL(jenkinsUrlTest);
                     System.out.println("XmlRecords are :"+xmlRecords);
                     
                     //String urlMy = "http://3.209.30.155:4951/api/measures/component?componentKey=QBOX_Microservice&metricKeys=violations,sqale_index,blocker_violations,critical_violations,major_violations,minor_violations,info_violations,duplicated_blocks,duplicated_lines,duplicated_lines_density,duplicated_files,sqale_rating,reliability_rating,coverage";
                   
                     String rootNodeTest = "testResult";
                     String nodeTest = "failCount";
                     String passCountTest = "passCount";
                     String skipCountTest = "skipCount";

                     String blockerTest = "blocker_violations";
                     String criticalTest = "critical_violations";
                     String majorTest = "major_violations";
                     String minorTest = "minor_violations";
                     String infoTest = "info_violations";
                     String duplicateTest = "duplicated_lines";
                     String techDeptTest = "sqale_index";
                     String voilationTest = "violations";

                     String count = null;
                     String passcount = null;
                     String skipcount = null;
                     String blocker = null;
                     String critical = null;
                     String major = null;
                     String minor = null;
                     String info = null;
                     String duplicatelines = null;
                     String techDeptLines = null;
                     String voilationTestLines = null;
                     String coverage = null;
                     String reliability_rating = null;
                     
                     
                     
                     
                     

                      
                    /*
                     blocker = xmlReadUtil.readSonarXML(xmlRecords1, blockerTest);
                     critical = xmlReadUtil.readSonarXML(xmlRecords1, criticalTest);
                     major = xmlReadUtil.readSonarXML(xmlRecords1, majorTest);
                     minor = xmlReadUtil.readSonarXML(xmlRecords1, minorTest);
                     info = xmlReadUtil.readSonarXML(xmlRecords1, infoTest);
                     duplicatelines = xmlReadUtil.readSonarXML(xmlRecords1, duplicateTest);
                     techDeptLines = xmlReadUtil.readSonarXML(xmlRecords1, techDeptTest);
                     voilationTestLines = xmlReadUtil.readSonarXML(xmlRecords1, voilationTest)*/;
                     String status = null;
                     String myBuildStatus;
                     try {
                                    String jobname1=jobName+"_CodeQuality";
                                     //String projectName = newJobBean.getApplicationName();
                                     System.out.println(jobname1);
                                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(
                                                                     "automation",
                                                                     "automation@2016");
                                     String lastCompletedBuild = PropertyUtil
                                                                     .getPropValue("jenkinsBuildStatus");
                                     String jenkinsLastCompletedBuild = lastCompletedBuild.replace(
                                                                     "[project_name]", jobname1);
                                     String xmlRecords12 = null;
                                     xmlRecords12 = workFlowUtil.postURL(jenkinsLastCompletedBuild);
                                     XmlReadUtil xmlReadUtil1 = new XmlReadUtil();

                                     if (!xmlRecords12.equalsIgnoreCase("error")) {
                                                     String buildStatus;
                                                     buildStatus = xmlReadUtil1.readTestXML(xmlRecords12,
                                                                                     "freeStyleBuild", "building");
                                                     
                                                     System.out.println("Build status in middle is "+buildStatus);
                                                     if (buildStatus.equalsIgnoreCase("false")) {
                                                    	 
                                                    	 System.out.println("Build status in middle is "+buildStatus);
                                                                     status = xmlReadUtil1.readTestXML(xmlRecords12,
                                                                                                     "freeStyleBuild", "result");
                                                                     System.out.println("Status after middle is "+status);
                                                                     String xmlapiurl11 = PropertyUtil.getPropValue("xmlapiurl");
                                                                     String xmlapiurl12 = xmlapiurl11.replace("[project_name]",
                                                                   		  jobname1);
                                                                     String xmlApiRecord1;

                                                                     xmlApiRecord1 = workFlowUtil.postURL(xmlapiurl12);
                                                                     String build = xmlReadUtil1.readTestXML(xmlApiRecord1,
                                                                                                     "build", "number");
                                                                     
                                                                    String buildStatus1= status.toLowerCase();
                                                                    
                                                                     char[] array = buildStatus1.toCharArray();
                                                                     // Modify first element in array.
                                                                     array[0] = Character.toUpperCase(array[0]);
                                                                     // Return string.
                                                                     myBuildStatus=String.valueOf(array);
                                                                     cincident.setBuildStatus(myBuildStatus);
                                                                    
                                                                    
                                                     } else {
                                                                     status = "building";
                                                     }
                                     } else {
                                                    status = "Not Found";
                                     }
                     } catch (IOException e) {
                                     log.error(e);
                     } catch (ParserConfigurationException e) {
                                     log.error(e);
                     } catch (SAXException e) {
                                     log.error(e);
                     }
                  
     System.out.println("Getting build Status"+cincident.getBuildStatus());
                   
     JSONObject xmlRecords1 = devOpsWorkFlowUtil.postURLJson(jenkinsUrlSONAR1);
     System.out.println("xmlRecords1 are :"+xmlRecords1);
     
     blocker = SearchJson.searchJson("blocker_violations", xmlRecords1);
     critical = SearchJson.searchJson("critical_violations", xmlRecords1);
     major = SearchJson.searchJson("major_violations", xmlRecords1);
     coverage = SearchJson.searchJson("coverage", xmlRecords1);
     reliability_rating = SearchJson.searchJson("reliability_rating", xmlRecords1);
     String duplicated_lines_density = SearchJson.searchJson("duplicated_lines_density", xmlRecords1);
     String sqale_index = SearchJson.searchJson("sqale_index", xmlRecords1);
     String sqale_rating = SearchJson.searchJson("sqale_rating", xmlRecords1);
     String duplicated_blocks = SearchJson.searchJson("duplicated_blocks", xmlRecords1);

     String security_rating= SearchJson.searchJson("security_rating", xmlRecords1);
     minor = SearchJson.searchJson("minor_violations", xmlRecords1);
     info = SearchJson.searchJson("info_violations", xmlRecords1);
     duplicatelines = SearchJson.searchJson("duplicated_lines", xmlRecords1);
     coverage = SearchJson.searchJson("coverage", xmlRecords1);
     voilationTestLines = SearchJson.searchJson("violations", xmlRecords1);

     System.out.println("reliability_rating"+reliability_rating+"sqale_rating"+sqale_rating+"security_rating"+security_rating);
 
     
     
                     
                     
                     String finalCritical=critical.replaceAll(",","");
                     String finalMinor=minor.replaceAll(",","");
                     String finalMajor=major.replaceAll(",","");
                     
                   
                     System.out.println("Minor Count is"+finalMinor);
                     System.out.println("Major Count is"+finalMajor);
                     
                    long minor1=Long.parseLong(finalMinor);
                    long major1=Long.parseLong(finalMajor);
                    long critical1=Long.parseLong(finalCritical);
                    
                    if(major1<=10 && minor1<=50 && critical1<=0)
                    {
                    	cincident.setFlag("true");
                    }
                    else
                    {
                    	cincident.setFlag("false");
                    }
                    
                     /*major<=10
							  minor<=50
							  critical<=0
                           */
                         cincident.setCount(count);
                         cincident.setPassCount(passcount);
                         cincident.setSkipCount(skipcount);
                         cincident.setBlocker(blocker);
                         cincident.setCritical(finalCritical);
                         cincident.setMajor(finalMajor);
                         cincident.setMinor(finalMinor);
                         cincident.setInfo(info);
                         cincident.setDuplicateLines(duplicatelines);
                         cincident.setTechDept(techDeptLines);
                         cincident.setIssues(voilationTestLines);
                         //cincident.setBuildStatus(status);
                         incidentEntity.setJobName(jobNamefinal);
                         System.out.println("cin is " + cincident.getJobEntity().getJobId());
                         System.out.println("We have proceded here");
                        
              
                   
              } catch (IOException e) {
                     e.printStackTrace();
             
              }

             
                     
             
              incidentEntity.setJobName(jobNamefinal);
              cRepo.save(cincident);
              System.out.println("Befor returning msgDTO");
              messageDTO.setMsg(cincident.getBuildStatus());
              return messageDTO;
       }



       @Override
       public MessageDTO getPolymerReports(JSONObject jsonObject) {
              // TODO Auto-generated method stub
              return null;
       }

       public void fetchYascaMetrixReport(JSONObject jsonObject, String applicationName) {
    	   String yascajobv1=applicationName;
              String xmlapiurlForYascaMetrix = PropertyUtil.getPropValue("yascaCSV");
              applicationName=applicationName+"_Yasca";
              System.out.println("now app name is this "+applicationName);
              String xmlapiurlYascaMatrix = xmlapiurlForYascaMetrix.replace("[project_name]", applicationName);
              DevOpsWorkFlowUtil devOpsWorkFlowUtil = new DevOpsWorkFlowUtil(jsonObject.get("JenkinsUsername").toString(),
                           jsonObject.get("JenkinsPassword").toString());
              System.out.println("username for jenkins"+jsonObject.get("JenkinsUsername").toString());
              System.out.println("pass for jenkins"+ jsonObject.get("JenkinsPassword").toString());
              YascaJobEntity yenti = new YascaJobEntity();
              try {
                     yenti = devOpsWorkFlowUtil.postURL5(xmlapiurlYascaMatrix, yenti);

              } catch (IOException e1) {

                     e1.printStackTrace();
              } catch (Exception e) {
                     e.printStackTrace();

              }
              YascaJobEntity newyasca2= new YascaJobEntity();
              
              long severityHigh = Long.parseLong(yenti.getSeverityHigh());
              long severityCritical = Long.parseLong(yenti.getSeverityCritical());
              
              if(severityCritical<=0 && severityHigh<=0)
              {
            	  newyasca2.setFlag("true");
              }
              else
              {
            	  newyasca2.setFlag("false");
              }
             // String projectId=jsonObject.get("ProjectId").toString();
             // long jobnewid=jobRepo.findByAppName(applicationName);
              
              //jobRepo.findByJobId(jobnewid);
           
              
              
              
              /*long jobId = jobRepo.fetchJobId(applicationName);
              yenti.setYascaJobName(applicationName);
              yenti.setYascaJobId((int) jobId);
              yenti.setEmpId(1);*/
              
              
              
              //yenti.setProjectId(projectId);
              // String incidentId1 = (String) ((HashMap)
              // jsonObject.get("JobDetails")).get("jobId");
              // System.out.println("incidentid"+incidentId1);
              //long jobId = incidentEntity.getJobId();
              //System.out.println("Job Id is:" + jobId);
              //System.out.println("jobid" + jobId);

              //JobEntity jobEntity = new JobEntity();
              //jobEntity.getJobId();
       //     System.out.println(jobEntity);
             
            // yenti.setJobEntity(jobEntity);
              //yenti.setJobEntity(jobEntity);
           /*  Boolean flag;
              //System.out.println(jobEntity);
             	YascaJobEntity newyascaentity=new YascaJobEntity();
              newyascaentity= yRepo.ifappNameExists(applicationName);
              if( newyascaentity!=null)
              {
                    flag=false;
              }
              else
              {
                    flag=true;
              }
              if(flag==true){
            	  System.out.println("value for first value="+yenti.getSeverityCritical());
            	  String severityCritical=yenti.getSeverityCritical();
            	  System.out.println("severityCritical:"+severityCritical);
            	  newyascaentity.setSeverityCritical(severityCritical);
            	  newyascaentity.setSeverityHigh(yenti.getSeverityHigh());
            	  newyascaentity.setSeverityLow(yenti.getSeverityLow());
            	  newyascaentity.setSeverityWarning(yenti.getSeverityWarning());
            	  newyascaentity.setSeverityInformational(yenti.getSeverityInformational());
            	  yRepo.save(yenti);
              }
              else{ */ 
              	long jobId = jobRepo.fetchJobId(yascajobv1);
              	JobEntity jobEntity = new JobEntity();
              	jobEntity=jobRepo.findByAppName1(yascajobv1);
              	jobEntity.getJobId();
              	System.out.println("jobentity for jobid is "+jobEntity.getJobId());
              		newyasca2.setJobEntity(jobEntity);
              
              		newyasca2.setYascaJobId((int) jobId);
              		newyasca2.setEmpId(1);
              		newyasca2.setJobName(yascajobv1);
              		newyasca2.setSeverityCritical(yenti.getSeverityCritical());
              		newyasca2.setSeverityHigh(yenti.getSeverityHigh());
              		newyasca2.setSeverityLow(yenti.getSeverityLow());
              		newyasca2.setSeverityWarning(yenti.getSeverityWarning());
              		newyasca2.setSeverityInformational(yenti.getSeverityInformational());
              		newyasca2.setYascaBuildStatus("Success");
              		newyasca2.setApplicationName(jobEntity.getApplicationName());
              		newyasca2.setProjectId(jobEntity.getProjectId());
              		
              		
              		yRepo.save(newyasca2);
              }
             

       

       public void fetchRegressionTestReport(JSONObject jsonObject, String applicationName) {
    	   JobEntity incidentEntity=new JobEntity();
              XmlReadUtil xmlReadUtil = new XmlReadUtil();
              RegressionJobEntity regressionentity = new RegressionJobEntity();
              try {
            	  String projectId=jsonObject.get("ProjectId").toString();
            	  System.out.println("Application name :"+applicationName);
                  long jobnewid=jobRepo.findByAppName(applicationName);
                  //jobRepo.findByJobId(jobnewid);
                  incidentEntity.setJobId(jobnewid);
                  incidentEntity.getJobId();
                  regressionentity.setJobEntity(incidentEntity);
                  regressionentity.setJobName(applicationName);
                  regressionentity.setRegressionId((int) jobnewid);
                  regressionentity.setJobEntity(incidentEntity);
                String applicationNamenew=applicationName+"_Regression";
                     DevOpsWorkFlowUtil devOpsWorkFlowUtil = new DevOpsWorkFlowUtil(jsonObject.get("JenkinsUsername").toString(),
                                  jsonObject.get("JenkinsPassword").toString());
                     String jenkinsUrl = PropertyUtil.getPropValue("jenkinsUrlForRegression");
                     String jenkinsRegrssionUrlTest = jenkinsUrl.replace("[project_name]", applicationName);
                     String xmlRegressionRecords = null;
                     xmlRegressionRecords = devOpsWorkFlowUtil.postURL(jenkinsRegrssionUrlTest);
                     String rootNodeRegressionTest = "result";
                     String failRegressionCountTest = "failCount";
                     String passRegressionCountTest = "passCount";
                     String skippedRegressionCountTest = "skipCount";
                     
                     String regressionfailcount = xmlReadUtil.readTestXML(xmlRegressionRecords, rootNodeRegressionTest,
                                  failRegressionCountTest);
                     String regressionpasscount = xmlReadUtil.readTestXML(xmlRegressionRecords, rootNodeRegressionTest,
                                  passRegressionCountTest);
                     String regressionskipcount = xmlReadUtil.readTestXML(xmlRegressionRecords, rootNodeRegressionTest,
                                  skippedRegressionCountTest);
                     // String incidentId1 = (String) ((HashMap)
                     // jsonObject.get("JobDetails")).get("jobId");
                     // System.out.println("incidentid"+incidentId1);
                     regressionentity.setRegressionFailCount(regressionfailcount);
                     regressionentity.setRegressionPassCount(regressionpasscount);
                     regressionentity.setRegressionSkipCount(regressionskipcount);
              } catch (IOException e) {
                     e.printStackTrace();
              } catch (ParserConfigurationException e) {
                     e.printStackTrace();

              } catch (SAXException e) {
                     e.printStackTrace();
              }
              rRepo.save(regressionentity);
       }

       public void getPerformanceJobName(JSONObject jsonObject, String projectName) {
              PerformanceJobEntity pentity = new PerformanceJobEntity();
              try {
                     DevOpsWorkFlowUtil devOpsWorkFlowUtil = new DevOpsWorkFlowUtil(jsonObject.get("JenkinsUsername").toString(),
                                  jsonObject.get("JenkinsPassword").toString());
                     XmlReadUtil xmlReadUtil = new XmlReadUtil();
                     // String incidentId1 = (String) ((HashMap)
                     // jsonObject.get("JobDetails")).get("jobId");
                     // System.out.println("incidentid"+incidentId1);
                     long jobId=jobRepo.findByAppName(projectName);
                    // long jobId = incidentEntity.getJobId();
                     System.out.println("jobid" + jobId);

                     JobEntity jobEntity = new JobEntity();
                     //jobEntity.setJobId(jobRepo.findByJobId(jobId));
                     System.out.println(jobEntity);
                     pentity.setPerformanceId((int) jobId);
                     pentity.setJobEntity(jobEntity);
                      projectName=projectName+"_Performance";
                     String performancePdfUrl = PropertyUtil.getPropValue("jenkinsUrlForPerformancePdf");
                     String PerformanceProjectName = performancePdfUrl.replace("[project_name]", projectName);
                     String result = devOpsWorkFlowUtil.postURL(PerformanceProjectName);

                     String xmlresult = xmlReadUtil.readTestXML(result, "freeStyleBuild", "timestamp");

                     String date = xmlresult;
                     Double unixDate = Double.parseDouble(date);
                     unixDate = unixDate / 1000;

                     Date date1 = new Date((long) (unixDate * 1000L));
                     SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

                     String finalDate = sdf.format(date1);
                     finalDate = "Performance_" + finalDate;
                     pentity.setPerformancePdfName(finalDate);
                     String performanceReportXML = PropertyUtil.getPropValue("urltoreadperformance");
                     String performanceProject = performanceReportXML.replace("[project_name]", projectName);
                     String finalperformanceProject = performanceProject.replace("[report_name]", finalDate);
                     String xmlReport = devOpsWorkFlowUtil.postURL(finalperformanceProject);
                     String rootNode = "memoryInformations";
                     String childNode = "usedMemory";
                     String maxMemory = "maxMemory";
                     String maxPermGen = "maxPermGen";
                     String memoryDetailsNode = "memoryDetails";
                     String usedNonHeapMemory = "usedNonHeapMemory";
                     String loadedClassesCount = "loadedClassesCount";
                     String usedPhysicalMemorySize = "usedPhysicalMemorySize";
                     String usedSwapSpaceSize = "usedSwapSpaceSize";
                     String usedMemory = xmlReadUtil.readTestXML(xmlReport, rootNode, childNode);
                     String finalMaxMemory = xmlReadUtil.readTestXML(xmlReport, rootNode, maxMemory);
                     String maxPermGenMemory = xmlReadUtil.readTestXML(xmlReport, rootNode, maxPermGen);
                     String usedNonHeap = xmlReadUtil.readTestXML(xmlReport, rootNode, usedNonHeapMemory);
                     String loadedClass = xmlReadUtil.readTestXML(xmlReport, rootNode, loadedClassesCount);
                     String usedPhysicalMemory = xmlReadUtil.readTestXML(xmlReport, rootNode, usedPhysicalMemorySize);
                     String usedSwapSpace = xmlReadUtil.readTestXML(xmlReport, rootNode, usedSwapSpaceSize);
                     String memoryDetails = xmlReadUtil.readTestXML(xmlReport, rootNode, memoryDetailsNode);

                     double usedMemoryInByte = Integer.parseInt(usedMemory);
                     double usedMemoryInKB = usedMemoryInByte / 1024;
                     double usedMemoryInMB = Math.ceil(usedMemoryInKB / 1024);
                     String convertedUsedMemory = String.valueOf(usedMemoryInMB);

                     if (convertedUsedMemory.equals("") || convertedUsedMemory == null) {
                           pentity.setUsedMemory("-");
                     } else {
                           pentity.setUsedMemory(convertedUsedMemory);
                     }
                     double maxMemoryInBytes = Integer.parseInt(finalMaxMemory);
                     double maxMemoryInKB = maxMemoryInBytes / 1024;
                     double maxMemoryInMB = Math.ceil(maxMemoryInKB / 1024);
                     String convertedMaxMemory = String.valueOf(maxMemoryInMB);
                     if (convertedMaxMemory.equals("") || convertedMaxMemory == null) {
                           pentity.setFinalMaxMamory("-");
                     } else {
                           pentity.setFinalMaxMamory(convertedMaxMemory);
                     }

                     double usedNonHeapInBytes = Integer.parseInt(usedNonHeap);
                     double usedNonHeapInKB = usedNonHeapInBytes / 1024;
                     double usedNonInMB = Math.ceil(usedNonHeapInKB / 1024);
                     String convertedNonHeap = String.valueOf(usedNonInMB);
                     if (convertedNonHeap.equals("") || convertedNonHeap == null) {
                           pentity.setUsedNonHeapMemory("-");
                     } else {
                           pentity.setUsedNonHeapMemory(convertedNonHeap);
                     }
                     long usedPhysicalMemoryInBytes = Long.parseLong(usedPhysicalMemory);
                     long usedPhysicalMemoryInKB = usedPhysicalMemoryInBytes / 1024;
                     long usedPhysicalMemoryInMB = (long) Math.ceil(usedPhysicalMemoryInKB / 1024);
                     String convertedusedPhysicalMemory = String.valueOf(usedPhysicalMemoryInMB);
                     if (convertedusedPhysicalMemory.equals("") || convertedusedPhysicalMemory == null) {
                           pentity.setUsedPhysicalMemorySize("-");
                     } else {
                           pentity.setUsedPhysicalMemorySize(convertedusedPhysicalMemory);
                     }
                     long usedSwapSpaceInBytes = Long.parseLong(usedSwapSpace);
                     long usedSwapSpaceInKB = usedSwapSpaceInBytes / 1024;
                     long usedSwapSpaceInMB = (long) Math.ceil(usedSwapSpaceInKB / 1024);
                     String convertedusedSwapSpace = String.valueOf(usedSwapSpaceInMB);

                     if (convertedusedSwapSpace.equals("") || convertedusedSwapSpace == null) {
                           pentity.setUsedSwapSpaceSize("-");
                     } else {
                           pentity.setUsedSwapSpaceSize(convertedusedSwapSpace);
                     }
                     pentity.setMaxPerGenMemory(maxPermGenMemory);
                     pentity.setMemoryDetails(memoryDetails);
                     pentity.setLoadedClassesCount(loadedClass);
              } catch (FileNotFoundException e) {
                     e.printStackTrace();
              } catch (IOException e) {
                     e.printStackTrace();
              } catch (ParserConfigurationException e) {
                     e.printStackTrace();
              } catch (SAXException e) {
                     e.printStackTrace();
              }

       }

       @Override
       public void fetchRegressionBuildStatus(JSONObject jsonObject, String projectName) {
              // TODO Auto-generated method stub

       }

       @Override
       public MessageDTO buildDeployJob(JSONObject jsonObject, String projectName) {
              boolean status = false;
              try {

                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jsonObject.get("JenkinsUsername").toString(),
                                  jsonObject.get("JenkinsPassword").toString());

                     final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuild");

                     String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", projectName);
                     String statusString = workFlowUtil.postURL(jenkinsUrlBuild);

                     if (statusString.isEmpty()) {
                           status = true;
                     }

              } catch (FileNotFoundException e) {

                     e.printStackTrace();
              } catch (IOException e) {
                     e.printStackTrace();

              }

              return messageDTO;
       }

       @Override
       public MessageDTO submitDeployCfJob(JSONObject jsonObject) {
              JobEntity incidentEntity = new JobEntity();
              WorkflowMasterEntity wentity = null;
              JSONObject jobj = new JSONObject();
              DeployCloudFoundryJobEntity dcf=new DeployCloudFoundryJobEntity();
              // String incidentId1 = (String) ((HashMap)
              // jsonObject.get("JobDetails")).get("jobId");
              String jenkinsusername = null;
              String jenkinspassword = null;
              String sourcecode=null;
              String svnURL = null;
              String module = null;
              String cvsRoot = null;
              String cvsPassword = null;
              String branchName = null;
              String tagName = null;
              String remoteName = null;
              String localName = null;
              String locationType = null;
              String gitURL =null;
              String gitBranch = null;
              String projectBranch = null;
              String jobName= jsonObject.get("jobName").toString();
              JobEntity deployjob=jobRepo.findByAppName1(jobName);
              jenkinsusername=deployjob.getJenkinsUsername();
              jenkinspassword=deployjob.getJenkinsPassword();
              sourcecode=deployjob.getCodeBase();
              svnURL = deployjob.getSvnUrl();
              module = deployjob.getLocalModuleDirectory();
              cvsRoot = deployjob.getCvsRoot();
              cvsPassword = deployjob.getCvsPassword();
              branchName = deployjob.getBranchLocationName();
              tagName = deployjob.getTagLocationName();
              remoteName = deployjob.getRemoteName();
              localName = deployjob.getLocalName();
              locationType = deployjob.getCvsLocation();
              gitURL =deployjob.getGitUrl();
              gitBranch = deployjob.getGitBranch();
              projectBranch = deployjob.getProjectPathBranch();
              // System.out.println("Aish"+incidentId1);
              long idd=deployjob.getJobId();
              incidentEntity = new JobEntity();
              wentity = new WorkflowMasterEntity();

              String stg = (String) jsonObject.get("Stage");
              deployjob.setStage("DeployCfJob");
              deployjob.setCurrentState("DeployCfJob");
              
              boolean status = false;
              
              MessageDTO response = new MessageDTO();
              
              if ("DeployCf".equalsIgnoreCase((String) jsonObject.get("Stage"))) {

                     String projectNamePatten = "^[a-zA-Z]{3,25}?_Deploy$";
                     Pattern r = Pattern.compile(projectNamePatten);
                     Matcher m = r.matcher(jobName);
                     if (m.find()) {
                           // boolean validJobName = validateJobName(jsonObject,
                           // projectName);
                           incidentEntity.setJobName(jobName.split("_Deploycf", 2)[0]);
                           jobName = incidentEntity.getJobName();

                     } else {
                           String suffix = "_Deploycf";

                           String jobNameNew = jobName.concat(suffix);
                           incidentEntity.setJobName(jobNameNew);
                           jobName = incidentEntity.getJobName();// addition of
                                                                                                              // suffix in
                           System.out.println(jobNameNew); // app name
                           // validJobName = validateJobName(jsonObject, jobNameNew);
                     }

              }
              String[] temp;
              String[] temp1;
              String[] temp2;
              String[] temp3;
              String[] temp4;
              String[] temp5;
              String[] temp6;

              String war = (String) jsonObject.get("WarFilePath");
              String contextPath = (String) jsonObject.get("ContextPath");
              String delimiter = "\\,";

              try {
                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jenkinsusername,
                                  jenkinspassword);
                     
                     String target = (String) jsonObject.get("TargetDeployCf");
                     String organization = (String) jsonObject.get("OrganisationDeployCf");
                     String space = (String) jsonObject.get("SpaceDeployCf");
                     String serviceName = (String) jsonObject.get("ServiceNameDeployCf");
                     String serviceType = (String) jsonObject.get("ServiceTypeDeployCf");
                     String servicePlan = (String) jsonObject.get("ServicePlanDeployCf");

                     String DeployCfconfig = (String) jsonObject.get("DeployCfconfig");
                     String manifestDeployCf = (String) jsonObject.get("ManifestDeployCf");
                     String applicationDeployCf = (String) jsonObject.get("ApplicationDeployCf");

                     String memoryDeployCf = (String) jsonObject.get("MemoryDeployCf");
                     String hostnameDeployCf = (String) jsonObject.get("HostnameDeployCf");

                     String instancesDeployCf = (String) jsonObject.get("InstancesDeployCf");
                     String timeoutDeployCf = (String) jsonObject.get("TimeoutDeployCf");
                     String custombuildpackDeployCf = (String) jsonObject.get("CustombuildpackDeployCf");
                     String customstackDeployCf = (String) jsonObject.get("CustomstackDeployCf");
                     
                     JobEntity clouddjobb=new JobEntity();
                           System.out.println("idd is "+idd);
                           clouddjobb.setJobId(idd);
                           clouddjobb.getJobId();
                           
                           dcf.setJobEntity(clouddjobb);
                           dcf.setDeployJobIdCf(idd);
                           dcf.setOrganisationDeployCf(organization);
                           dcf.setSpaceDeployCf(space);
                           dcf.setServiceNameDeployCf(serviceName);
                           dcf.setServiceTypeDeployCf(serviceType);
                           dcf.setServicePlanDeployCf(servicePlan);
                           dcf.setDeployCfconfig(DeployCfconfig);
                           dcf.setManifestDeployCf(manifestDeployCf);
                           dcf.setApplicationDeployCf(applicationDeployCf);
                           dcf.setMemoryDeployCf(memoryDeployCf);
                           dcf.setHostnameDeployCf(hostnameDeployCf);
                           dcf.setInstancesDeployCf(instancesDeployCf);
                           dcf.setTimeoutDeployCf(timeoutDeployCf);
                           dcf.setCustombuildpackDeployCf(custombuildpackDeployCf);
                           dcf.setCustomstackDeployCf(customstackDeployCf);
                           
                           dcf.setEmpId(1);
                     String encryptedPassword = "";

                     String strXMLFilenameMaven = null;

                     if ("SVN".equalsIgnoreCase(sourcecode)) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployCf");
                     } else if ("CVS".equalsIgnoreCase(sourcecode)) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployCfCVS");
                     } else if ("GIT".equalsIgnoreCase(sourcecode)) {
                           strXMLFilenameMaven = PropertyUtil.getPropValue("xmlConfigDeployCfGIT");
                     }

                     File xmlFile = new File(strXMLFilenameMaven);
                     DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                     DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                     Document doc = dBuilder.parse(xmlFile);

                     /*
                     * String strURL1 = PropertyUtil.getPropValue("jenkinsUrl"); String
                     * strURL = strURL1.concat(deployCfStringJobName);
                     */

                     NodeList permissionList = doc.getElementsByTagName("permission");
                     Node workspacePermission = permissionList.item(0);
                     workspacePermission.setTextContent("hudson.model.Item.Workspace:" + jsonObject.get("JenkinsUsername"));
                     Node buildPermission = permissionList.item(1);
                     buildPermission.setTextContent("hudson.model.Item.Build:" + jsonObject.get("JenkinsUsername"));
                     Node updatePermission = permissionList.item(2);
                     updatePermission.setTextContent("hudson.model.Run.Update:" + jsonObject.get("JenkinsUsername"));
                     Node readPermission = permissionList.item(3);
                     readPermission.setTextContent("hudson.model.Item.Read:" + jsonObject.get("JenkinsUsername"));
                     Node tagPermission = permissionList.item(4);
                     tagPermission.setTextContent("hudson.scm.SCM.Tag:" + jsonObject.get("JenkinsUsername"));
                     Node configurePermission = permissionList.item(5);
                     configurePermission.setTextContent("hudson.model.Item.Configure:" + jsonObject.get("JenkinsUsername"));
                     Node discoverPermission = permissionList.item(6);
                     discoverPermission.setTextContent("hudson.model.Item.Discover:" + jsonObject.get("JenkinsUsername"));

                     if ("SVN".equalsIgnoreCase(sourcecode)) {
                           
                           NodeList nodeListLocation = doc.getElementsByTagName("locations");
                           Node nodeLoc = nodeListLocation.item(0);
                           Element locations = (Element) nodeLoc;

                           if (!svnURL.isEmpty()) {
                                  temp = svnURL.split(delimiter);
                                  temp1 = module.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {

                                         Element moduleNode = doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                                         locations.appendChild(moduleNode);

                                         Element remoteNode = doc.createElement("remote");
                                         remoteNode.setTextContent(temp[i]);
                                         moduleNode.appendChild(remoteNode);

                                         Element local = doc.createElement("local");
                                         local.setTextContent(temp1[i]);
                                         moduleNode.appendChild(local);
                                         Element depth = doc.createElement("depthOption");
                                         depth.setTextContent("infinity");
                                         moduleNode.appendChild(depth);
                                         Element ignoreExternalsOption = doc.createElement("ignoreExternalsOption");
                                         ignoreExternalsOption.setTextContent("false");
                                         moduleNode.appendChild(ignoreExternalsOption);
                                  }

                                  /*
                                  * jobBean.setAddMicroservice(fetchHasMicroservice(jobBean))
                                  * ; System.out.println(jobBean.getAddMicroservice());
                                  * 
                                   * if("YES".equalsIgnoreCase(jobBean.getAddMicroservice()))
                                  * { String[] svnUrl=fetchSvnUrl(jobBean).split(delimiter);
                                  * String[]
                                  * localModule=fetchLocalModule(jobBean).split(delimiter);
                                  * 
                                   * 
                                   * for (int i = 0; i < svnUrl.length; i++) { Element
                                  * moduleNode = doc
                                  * .createElement("hudson.scm.SubversionSCM_-ModuleLocation"
                                  * ); locations.appendChild(moduleNode); Element remoteNode
                                  * = doc.createElement("remote");
                                  * remoteNode.setTextContent(svnUrl[i]);
                                  * moduleNode.appendChild(remoteNode); Element local =
                                  * doc.createElement("local");
                                  * local.setTextContent(localModule[i]);
                                  * moduleNode.appendChild(local); Element depth =
                                  * doc.createElement("depthOption");
                                  * depth.setTextContent("infinity");
                                  * moduleNode.appendChild(depth); Element
                                  * ignoreExternalsOption = doc
                                  * .createElement("ignoreExternalsOption");
                                  * ignoreExternalsOption.setTextContent("false");
                                  */
                           }

                     } else if ("CVS".equalsIgnoreCase(sourcecode)) {
                           
                           
                           NodeList nodeListRepositories = doc.getElementsByTagName("repositories");
                           Node nodeRepositories = nodeListRepositories.item(0);
                           Element repositories = (Element) nodeRepositories;

                           if (!cvsRoot.isEmpty()) {
                                  temp = cvsRoot.split(delimiter);
                                  temp1 = cvsPassword.split(delimiter);
                                  temp2 = branchName.split(delimiter);
                                  temp3 = remoteName.split(delimiter);
                                  temp4 = localName.split(delimiter);
                                  temp5 = locationType.split(delimiter);
                                  temp6 = tagName.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {

                                         Element cvsRepository = doc.createElement("hudson.scm.CvsRepository");
                                         repositories.appendChild(cvsRepository);

                                         Element cvsRootXml = doc.createElement("cvsRoot");
                                         cvsRootXml.setTextContent(temp[i]);
                                         cvsRepository.appendChild(cvsRootXml);

                                         Element repositoryItems = doc.createElement("repositoryItems");
                                         cvsRepository.appendChild(repositoryItems);

                                         Element cvsRepositoryItem = doc.createElement("hudson.scm.CvsRepositoryItem");
                                         repositoryItems.appendChild(cvsRepositoryItem);

                                         Element modules = doc.createElement("modules");
                                         cvsRepositoryItem.appendChild(modules);

                                         Element cvsModule = doc.createElement("hudson.scm.CvsModule");
                                         modules.appendChild(cvsModule);

                                         Element localName1 = doc.createElement("localName");
                                         localName1.setTextContent(temp4[i]);
                                         cvsModule.appendChild(localName1);

                                         Element remoteName1 = doc.createElement("remoteName");
                                         remoteName1.setTextContent(temp3[i]);
                                         cvsModule.appendChild(remoteName1);

                                         Element location = doc.createElement("location");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$BranchRepositoryLocation");
                                         }
                                         if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$TagRepositoryLocation");
                                         }
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                location.setAttribute("class", "hudson.scm.CvsRepositoryLocation$HeadRepositoryLocation");
                                         }
                                         cvsRepositoryItem.appendChild(location);

                                         Element locationType1 = doc.createElement("locationType");
                                         locationType1.setTextContent(temp5[i]);
                                         location.appendChild(locationType1);

                                         Element locationName1 = doc.createElement("locationName");
                                         if ("BRANCH".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp2[i]);
                                         } else if ("TAG".equalsIgnoreCase(temp5[i])) {
                                                locationName1.setTextContent(temp6[i]);
                                         }
                                         location.appendChild(locationName1);

                                         Element useHeadIfNotFound = doc.createElement("useHeadIfNotFound");
                                         if ("HEAD".equalsIgnoreCase(temp5[i])) {
                                                useHeadIfNotFound.setTextContent("false");
                                         } else {
                                                useHeadIfNotFound.setTextContent("true");
                                         }
                                         location.appendChild(useHeadIfNotFound);

                                         Element compressionLevel = doc.createElement("compressionLevel");
                                         compressionLevel.setTextContent("-1");
                                         cvsRepository.appendChild(compressionLevel);

                                         Element excludedRegions = doc.createElement("excludedRegions");
                                         cvsRepository.appendChild(excludedRegions);

                                         Element excludedRegion = doc.createElement("hudson.scm.ExcludedRegion");
                                         excludedRegions.appendChild(excludedRegion);

                                         Element pattern = doc.createElement("pattern");
                                         excludedRegion.appendChild(pattern);

                                         Element cvsPassword1 = doc.createElement("password");
                                         cvsPassword1.setTextContent(temp1[i]);
                                         cvsRepository.appendChild(cvsPassword1);

                                         Element passwordRequired = doc.createElement("passwordRequired");
                                         passwordRequired.setTextContent("true");
                                         cvsRepository.appendChild(passwordRequired);

                                  }
                           }
                     }

                     else if ("GIT".equalsIgnoreCase(sourcecode)) {

                           
                     
                           NodeList nodeListRepositories11 = doc.getElementsByTagName("userRemoteConfigs");
                           Node nodeRepositories11 = nodeListRepositories11.item(0);
                           Element userRemoteConfigs = (Element) nodeRepositories11;

                           if (!gitURL.isEmpty()) {

                                  temp = gitURL.split(delimiter);
                                  temp1 = gitBranch.split(delimiter);
                                  temp2 = projectBranch.split(delimiter);

                                  for (int i = 0; i < temp.length; i++) {
                                         Element moduleNode11 = doc.createElement("hudson.plugins.git.UserRemoteConfig");
                                         userRemoteConfigs.appendChild(moduleNode11);

                                         Element remoteNode11 = doc.createElement("url");
                                         remoteNode11.setTextContent(temp[i]);
                                         moduleNode11.appendChild(remoteNode11);

                                         NodeList nodeListRepositories13 = doc.getElementsByTagName("branches");
                                         Node nodeRepositories13 = nodeListRepositories13.item(0);
                                         Element branches = (Element) nodeRepositories13;

                                         Element moduleNode12 = doc.createElement("hudson.plugins.git.BranchSpec");
                                         branches.appendChild(moduleNode12);

                                         Element remoteNode12 = doc.createElement("name");
                                         remoteNode12.setTextContent(temp1[i]);
                                         moduleNode12.appendChild(remoteNode12);

                                         if (projectBranch.equalsIgnoreCase(",")) {

                                                Element element = (Element) doc
                                                              .getElementsByTagName("hudson.plugins.git.extensions.impl.SparseCheckoutPaths")
                                                              .item(0);

                                                Node parent = element.getParentNode();

                                                parent.removeChild(element);

                                                parent.normalize();

                                         } else {
                                                NodeList nodeListRepositories12 = doc.getElementsByTagName("sparseCheckoutPaths");
                                                Node nodeRepositories12 = nodeListRepositories12.item(0);
                                                Element sparseCheckoutPaths = (Element) nodeRepositories12;
                                                Element moduleNode13 = doc
                                                              .createElement("hudson.plugins.git.extensions.impl.SparseCheckoutPath");

                                                sparseCheckoutPaths.appendChild(moduleNode13);
                                                Element nodeListRepositories22 = doc.createElement("path");
                                                nodeListRepositories22.setTextContent(temp2[i]);
                                                moduleNode13.appendChild(nodeListRepositories22);
                                         }
                                  }
                           }
                     }

                     NodeList nodeListTest = doc.getElementsByTagName("target");
                     Node nodeName = nodeListTest.item(0);
                     Element targettag = (Element) nodeName;
                     targettag.setTextContent(target);

                     NodeList nodeListTeam = doc.getElementsByTagName("organization");
                     Node nodeTeam = nodeListTeam.item(0);
                     Element team = (Element) nodeTeam;
                     team.setTextContent(organization);

                     NodeList nodeListPreset = doc.getElementsByTagName("cloudSpace");
                     Node nodePreset = nodeListPreset.item(0);
                     Element preset = (Element) nodePreset;
                     preset.setTextContent(space);

                     /*
                     * Element moduleNode =
                     * doc.createElement("hudson.scm.SubversionSCM_-ModuleLocation");
                     * locations.appendChild(moduleNode);
                     * 
                      * Element remoteNode = doc.createElement("remote");
                     * remoteNode.setTextContent(temp[i]);
                     * moduleNode.appendChild(remoteNode);
                     * 
                      * Element local = doc.createElement("local");
                     * local.setTextContent(temp1[i]); moduleNode.appendChild(local);
                     * Element depth = doc.createElement("depthOption");
                     * depth.setTextContent("infinity"); moduleNode.appendChild(depth);
                     * Element ignoreExternalsOption = doc
                     * .createElement("ignoreExternalsOption");
                     * ignoreExternalsOption.setTextContent("false");
                     * moduleNode.appendChild(ignoreExternalsOption);
                     */

                     NodeList nodeListLocation = doc.getElementsByTagName("servicesToCreate");
                     Node nodeLoc = nodeListLocation.item(0);
                     Element servicesToCreate = (Element) nodeLoc;

                     String delimiterService = ",";
                     if (!serviceName.isEmpty() && !serviceType.isEmpty() && !servicePlan.isEmpty()) {
                           temp = serviceName.split(delimiterService);
                           temp1 = serviceType.split(delimiterService);
                           temp2 = servicePlan.split(delimiterService);

                           for (int i = 0; i < temp.length; i++) {
                                  Element moduleNode = doc
                                                .createElement("com.hpe.cloudfoundryjenkins.CloudFoundryPushPublisher_-Service");
                                  servicesToCreate.appendChild(moduleNode);
                                  Element remoteNode = doc.createElement("name");
                                  remoteNode.setTextContent(temp[i]);
                                  moduleNode.appendChild(remoteNode);

                                  Element type = doc.createElement("type");
                                  type.setTextContent(temp1[i]);
                                  moduleNode.appendChild(type);

                                  Element plan = doc.createElement("plan");
                                  plan.setTextContent(temp2[i]);
                                  moduleNode.appendChild(plan);

                                  Element resetService = doc.createElement("resetService");
                                  resetService.setTextContent("false");
                                  moduleNode.appendChild(resetService);

                           }

                     }

                     NodeList nodeListRepositories11 = doc.getElementsByTagName("manifestChoice");
                     Node nodeRepositories11 = nodeListRepositories11.item(0);
                     Element manifestChoice = (Element) nodeRepositories11;
                     /*
                     * NodeList nodeListPreset23 =
                     * doc.getElementsByTagName("manifestChoice"); NodeList
                     * nodeListPreset24 = doc.getElementsByTagName("value");
                     */

                     NodeList nodeListPreset23 = doc.getElementsByTagName("value");
                     Node nodePreset23 = nodeListPreset23.item(0);
                     Element preset23 = (Element) nodePreset23;
                     preset23.setTextContent(DeployCfconfig);

                     if (DeployCfconfig.equalsIgnoreCase("jenkinsConfig")) {

                           /*
                           * Element moduleNode11 =
                           * doc.createElement("hudson.plugins.git.UserRemoteConfig");
                           * userRemoteConfigs.appendChild(moduleNode11);
                           * 
                            * Element remoteNode11 = doc.createElement("url");
                           * remoteNode11.setTextContent(temp[i]);
                           * moduleNode11.appendChild(remoteNode11);
                           */
                           /*
                           * Element remoteNode12 = doc.createElement("manifestFile");
                           * remoteNode12.setTextContent("manifest.yml");
                           * manifestChoice.appendChild(remoteNode12);
                           */

                           Element remoteNode13 = doc.createElement("appName");

                           remoteNode13.setTextContent(applicationDeployCf);
                           manifestChoice.appendChild(remoteNode13);

                           Element remoteNode14 = doc.createElement("memory");
                           remoteNode14.setTextContent(memoryDeployCf);
                           manifestChoice.appendChild(remoteNode14);

                           Element remoteNode15 = doc.createElement("hostname");
                           remoteNode15.setTextContent(hostnameDeployCf);
                           manifestChoice.appendChild(remoteNode15);

                           Element remoteNode16 = doc.createElement("instances");
                           remoteNode16.setTextContent(instancesDeployCf);
                           manifestChoice.appendChild(remoteNode16);

                           Element remoteNode17 = doc.createElement("timeout");
                           remoteNode17.setTextContent(timeoutDeployCf);
                            manifestChoice.appendChild(remoteNode17);

                           Element remoteNode18 = doc.createElement("noRoute");
                           remoteNode18.setTextContent("false");
                           manifestChoice.appendChild(remoteNode18);

                           Element remoteNode28 = doc.createElement("appPath");
                           remoteNode28.setTextContent(" ");
                           manifestChoice.appendChild(remoteNode28);

                           Element remoteNode19 = doc.createElement("buildpack");
                           remoteNode19.setTextContent(custombuildpackDeployCf);
                           manifestChoice.appendChild(remoteNode19);

                           Element remoteNode20 = doc.createElement("stack");

                           remoteNode20.setTextContent(customstackDeployCf);
                           manifestChoice.appendChild(remoteNode20);

                           Element remoteNode27 = doc.createElement("command");
                           remoteNode27.setTextContent(" ");
                           manifestChoice.appendChild(remoteNode27);

                           Element remoteNode26 = doc.createElement("domain");
                           remoteNode26.setTextContent(" ");
                           manifestChoice.appendChild(remoteNode26);

                     } else {

                           Element remoteNode23 = doc.createElement("manifestFile");

                           remoteNode23.setTextContent(manifestDeployCf);
                           manifestChoice.appendChild(remoteNode23);

                           Element remoteNode14 = doc.createElement("memory");
                           remoteNode14.setTextContent("0");
                           manifestChoice.appendChild(remoteNode14);

                           Element remoteNode16 = doc.createElement("instances");
                           remoteNode16.setTextContent("0");
                           manifestChoice.appendChild(remoteNode16);

                           Element remoteNode17 = doc.createElement("timeout");
                           remoteNode17.setTextContent("0");
                           manifestChoice.appendChild(remoteNode17);

                           Element remoteNode18 = doc.createElement("noRoute");
                           remoteNode18.setTextContent("false");
                           manifestChoice.appendChild(remoteNode18);

                     }

                     String strURL1 = PropertyUtil.getPropValue("jenkinsUrl");
                     String strURL = strURL1.concat(jobName);

                     status = workFlowUtil.postXML(strURL, doc);

              } catch (FileNotFoundException e) {

                     e.printStackTrace();
              } catch (IOException e) {
                     e.printStackTrace();

              } catch (ParserConfigurationException e) {
                     e.printStackTrace();
              } catch (SAXException e) {
                     e.printStackTrace();
              }
              dcfRepo.save(dcf);
              return messageDTO;

       }

       @Override
       public MessageDTO buildDeployCfJob(JSONObject jsonObject, String projectName) {
              boolean status = false;
              try {

                     DevOpsWorkFlowUtil workFlowUtil = new DevOpsWorkFlowUtil(jsonObject.get("JenkinsUsername").toString(),
                                  jsonObject.get("JenkinsPassword").toString());

                     System.err.println("deploy jib name*****" + jsonObject.get("JenkinsUsername").toString());
                     System.err.println("deploy jib name*****" + jsonObject.get("JenkinsPassword").toString());
                     System.err.println("deploy jib name*****" + projectName);
                     final String jenkinsUrlBuildWithParameters = PropertyUtil.getPropValue("jenkinsUrlBuild");

                     String jenkinsUrlBuild = jenkinsUrlBuildWithParameters.replace("[project_name]", projectName);
                     String statusString = workFlowUtil.postURL(jenkinsUrlBuild);

                     if (statusString.isEmpty()) {
                           status = true;
                     }

              } catch (FileNotFoundException e) {

                     e.printStackTrace();
              } catch (IOException e) {
                     e.printStackTrace();

              }

              return messageDTO;
       }

       public boolean isTCGUser(String empId) {

              boolean result = false;
              try {
                     Class.forName("org.postgresql.Driver");
              } catch (ClassNotFoundException e1) {
                     // TODO Auto-generated catch block
                     e1.printStackTrace();
              }
              Connection conn = null;
              try {
                     conn = DriverManager.getConnection("jdbc:postgresql//localhost:5432/devops", "postgres", "root");
              } catch (SQLException e1) {
                     // TODO Auto-generated catch block
                     e1.printStackTrace();
              }
              try {

                     PreparedStatement statement = conn.prepareStatement(selectSQLIsTCGUser);
                     statement.setInt(1, Integer.parseInt(empId));
                     ResultSet rs = statement.executeQuery();
                     while (rs.next()) {
                           String groupName = rs.getString("group_id");

                           if (groupName.equalsIgnoreCase("TCGGroup")) {

                                  result = true;
                           } else {
                                  result = false;
                           }
                     }
              } catch (Exception e) {
                     e.printStackTrace();
              } finally {
                     try {
                           conn.close();
                     } catch (SQLException e) {
                           // TODO Auto-generated catch block
                           e.printStackTrace();
                     }
              }
              return result;
       }

       @Override
       public List<JobEntity> fetchjobsofusers() {
              // List<JobDTO> jobDTOList = new ArrayList<JobDTO>();
              List<JobEntity> details = new ArrayList<JobEntity>();
              details = jobRepo.fetchusers();
              /*
              * for (JobEntity jobEntity : details) { JobDTO jobDto = new JobDTO();
              * jobDto.setJobId(jobEntity.getJobId());
              * jobDto.setApplicationName(jobEntity.getApplicationName());
              * jobDto.setProjectId(jobEntity.getProjectId());
              * jobDto.setStage(jobEntity.getStage());
              * 
               * jobDTOList.add(jobDto); }
              */
              
              System.out.println(details);
              return details;
       }

	@Override
	public List<CodeQualityJobEntity> fetchCodeQualityApplication(String microservicename) {

		List<CodeQualityJobEntity> codeQualityData=cRepo.getDetailsByAppName(microservicename);
		
          return codeQualityData;
       }

       
       @Override
       public YascaJobEntity fetchYascaApplication(String microservicename) {

    	   
    	   YascaJobEntity yentity = new YascaJobEntity();
    	   
    	   yentity=yRepo.getDetailsByAppName1(microservicename);
    	   
    	 //Threshold values

    	   final double highThresold=10;
    	   final double lowThresold=50;
    	   
    	   double critical = 0,high = 0,low = 0;
           String appHealth = null;
           double avgHealth = 0;
           
           
     	  critical=Double.parseDouble(yentity.getSeverityCritical());
     	  System.out.println(critical);
     	  
     	 high=Double.parseDouble(yentity.getSeverityHigh());
     	 System.out.println(high);
     	 
     	 low=Double.parseDouble(yentity.getSeverityLow());
     	 System.out.println(low);
    	   
           if(critical!= 0)
   		 {
   			 appHealth="Risk";
   			 
   		 }
            else
            {
          	  double highThresoldPer=(((highThresold-high)/highThresold)*100);
          	  System.out.println(highThresoldPer);
                
                double lowThresoldPer=(((lowThresold-low)/lowThresold)*100);
               
                System.out.println(lowThresoldPer);
                
                avgHealth=((highThresoldPer+lowThresoldPer)/2);
                 
                 System.out.println("Avg Health"+avgHealth);
                 
                if(avgHealth>=95.0)
		         {
		       	  appHealth="Good";
		         }
                else if(avgHealth>30.0 && avgHealth<95.0)
		         {
		       	  appHealth="Need to be Resolved";
		         }
                else if(avgHealth<30.0)
		         {
		       	  appHealth="Risk";
		         }
                 
            }
           
           String finalAvgHealth = Double.toString(avgHealth);
     	  System.out.println(finalAvgHealth);
            yentity.setYascaAvgHealth(finalAvgHealth);
            yentity.setAppHealth(appHealth);
            
            yRepo.save(yentity);
               
               System.out.println("befor Return saving "+yentity);
               return yentity;
              //return null;

       }
       
   
       @Override
       public List<CheckMarxJobentity> fetchCheckMarxApplication(String applicationName) {
              
              List<CheckMarxJobentity> appDetails = new ArrayList<CheckMarxJobentity>();

              appDetails = cmRepo.getDetailsByAppName(applicationName);

              System.out.println("after appDetails" + appDetails);

              System.out.println("befor Return" + appDetails);

              return appDetails;
       }

       @Override
       public List<DeployChefJobEntity> fetchDeployChefApplication(String applicationName) {
              List<DeployChefJobEntity> appDetails = new ArrayList<DeployChefJobEntity>();

              appDetails = dcRepo.getDetailsByAppName(applicationName);

              System.out.println("after appDetails" + appDetails);

              System.out.println("befor Return" + appDetails);

              return appDetails;
       }

       @Override
       public List<DeployCloudFoundryJobEntity> fetchDeployCloudFoundryApplication(String applicationName) {
              List<DeployCloudFoundryJobEntity> appDetails = new ArrayList<DeployCloudFoundryJobEntity>();

              appDetails = dcfRepo.getDetailsByAppName(applicationName);

              System.out.println("after appDetails" + appDetails);

              System.out.println("befor Return" + appDetails);

              return appDetails;
       }

       @Override
       public List<DeployJenkinsJobEntity> fetchDeployJenkinsApplication(String applicationName) {
              List<DeployJenkinsJobEntity> appDetails = new ArrayList<DeployJenkinsJobEntity>();

              appDetails = djRepo.getDetailsByAppName(applicationName);

              System.out.println("after appDetails" + appDetails);

              System.out.println("befor Return" + appDetails);

              return appDetails;
       }

       @Override
       public List<PerformanceJobEntity> fetchPerformanceApplication(String applicationName) {
              List<PerformanceJobEntity> appDetails = new ArrayList<PerformanceJobEntity>();

              appDetails = perRepo.getDetailsByAppName(applicationName);

              System.out.println("after appDetails" + appDetails);

              System.out.println("befor Return" + appDetails);

              return appDetails;
       }

       @Override
       public List<RegressionJobEntity> fetchRegressionApplication(String applicationName) {
              List<RegressionJobEntity> appDetails = new ArrayList<RegressionJobEntity>();

              appDetails = rRepo.getDetailsByAppName(applicationName);

              System.out.println("after appDetails" + appDetails);

              System.out.println("befor Return" + appDetails);

              return appDetails;
       }

       @Override
       public List<SahiJobEntity> fetchSahiApplication(String applicationName) {
              List<SahiJobEntity> appDetails = new ArrayList<SahiJobEntity>();

              appDetails = sRepo.getDetailsByAppName(applicationName);

              System.out.println("after appDetails" + appDetails);

              System.out.println("befor Return" + appDetails);

              return appDetails;
       }

       @Override
       public List<SoapUiJobEntity> fetchSoapUiApplication(String applicationName) {
              List<SoapUiJobEntity> appDetails = new ArrayList<SoapUiJobEntity>();

              appDetails = suiRepo.getDetailsByAppName(applicationName);

              System.out.println("after appDetails" + appDetails);

              System.out.println("befor Return" + appDetails);

              return appDetails;
       }

       @Override
       public boolean isExists(String appName, String stage) {
              
              boolean flag = false;
              
              System.out.println("Inside isExist stage is"+stage);
              if(stage.equalsIgnoreCase("null"))
              {
            	  flag = false;
              }
              else if(stage.equalsIgnoreCase("CodeQuality"))
              {
                     List<CodeQualityJobEntity> appDetails = new ArrayList<CodeQualityJobEntity>();
                     
                     appDetails = cRepo.getDetailsByAppName(appName);
                     
                     if(appDetails.isEmpty())
                     {
                           flag=false;
                     }
                     else
                     {
                           flag=true;
                     }
                     System.out.println("flag is "+flag);
              }
              else if(stage.equalsIgnoreCase("JUnitSonarEmma"))
              {
                     List<CodeQualityJobEntity> appDetails = new ArrayList<CodeQualityJobEntity>();
                     
                     appDetails = cRepo.getDetailsByAppName(appName);
                     
                     if(appDetails.isEmpty())
                     {
                           flag=false;
                     }
                     else
                     {
                           flag=true;
                     }
                     System.out.println("flag is "+flag);
              }
              else if(stage.equalsIgnoreCase("Yasca"))
              {
                     List<YascaJobEntity> appDetails = new ArrayList<YascaJobEntity>();
                     
                     appDetails = yRepo.getDetailsByAppName(appName);
                     
                     if(appDetails.isEmpty())
                     {
                           flag=false;
                     }
                     else
                     {
                           flag=true;
                     }
                     System.out.println("flag is "+flag);
              }
              else if(stage.equalsIgnoreCase("Checkmarx"))
              {
                     List<CheckMarxJobentity> appDetails = new ArrayList<CheckMarxJobentity>();
                     
                     appDetails = cmRepo.getDetailsByAppName(appName);
                     
                     if(appDetails.isEmpty())
                     {
                           flag=false;
                     }
                     else
                     {
                           flag=true;
                     }
                     System.out.println("flag is "+flag);
              }
              else if(stage.equalsIgnoreCase("Regression"))
              {
                     List<RegressionJobEntity> appDetails = new ArrayList<RegressionJobEntity>();
                     
                     appDetails = rRepo.getDetailsByAppName(appName);
                     
                     if(appDetails.isEmpty())
                     {
                           flag=false;
                     }
                     else
                     {
                           flag=true;
                     }
                     System.out.println("flag is "+flag);
              }
              // TODO Auto-generated method stub
              return flag;
       }
       
       
    @Override
    public List<ProjectInformationEntity> getSubAccounts(String accountName) 
    {
           
           return pRepo.fetchSubAccounts(accountName);
    }

    @Override
    public List<ProjectInformationEntity> getSubAccountDetails(String subAccountName) {
           
           return pRepo.fetchSubAccountDetails(subAccountName);
    }



       @Override
       public List<ProjectInformationEntity> fetchProjectDetails() {
              List<ProjectInformationEntity> pdetails = pRepo.fetchProjectInfo();
              return pdetails;
       }
       
       
    @Override
    public List<ProjectInformationEntity> getProjectID(String subAccountName) 
    {
           
           System.out.println(pRepo.fetchProjectId(subAccountName));
           return pRepo.fetchProjectId(subAccountName);
    }

    @Override
    public List<ProjectInformationEntity> getProjectName(String subAccountName) {
           System.out.println(pRepo.fetchProjectName(subAccountName));
           return pRepo.fetchProjectName(subAccountName);
    }

    @Override
    public List<ProjectInformationEntity> getApplicationName(String projectId) {
           System.out.println(pRepo.fetchApplicationName(projectId));
           return pRepo.fetchApplicationName(projectId);
    }
    @Override
    public List<ProjectInformationEntity> getProjectReleaseDate(String applicationName) 
    {
           System.out.println(pRepo.fetchReleaseDate(applicationName));
           return pRepo.fetchReleaseDate(applicationName);
    }

    @Override
    public int fetchAppsCount(String accountname) 
    {
     
           
           
                  int count=pRepo.fetchAppCount(accountname);
                
          
           
           return count;
    }

	@Override
	public List<ProjectInformationEntity> getWebapps(String applicationName) {
		System.out.println(pRepo.fetchwebapps(applicationName));
        return pRepo.fetchwebapps(applicationName);
 
		
	}

	@Override
	public JSONObject isJobExists(String jobName) 
	{	JSONObject jsonObj=new JSONObject();
		String codequalitystatus=cRepo.fetchjobstatus(jobName);
		jsonObj.put("jobName",jobName.toString());
		jsonObj.put("CodeQuality",codequalitystatus);
		String yascastatus=yRepo.fetchjobstatus(jobName);
		jsonObj.put("Yasca",yascastatus);
		String checkmarxstatus=chRepo.fetchjobstatus(jobName);
		jsonObj.put("Checkmarx",checkmarxstatus);
		String deployjenkins=djRepo.fetchjobstatus(jobName);
		jsonObj.put("Deployjenkins",deployjenkins);
		String deploycloudstatus=dcfRepo.fetchjobstatus(jobName);
		jsonObj.put("DeployCloud",deploycloudstatus);
		String deploychef=dcRepo.fetchjobstatus(jobName);
		jsonObj.put("DeployChef",deploychef);
		String deployperformance=perRepo.fetchjobstatus(jobName);
		jsonObj.put("Performance",deployperformance);
		String deployRegression=rRepo.fetchjobstatus(jobName);
		jsonObj.put("Regression",deployRegression);
		
		return jsonObj;
	}

	@Override
	public List<ProjectInformationEntity> getApplicationName1(String subAccountName) {
		System.out.println(pRepo.fetchApplicationName1(subAccountName));
        return pRepo.fetchApplicationName1(subAccountName);
	}

	@Override
	public List<ProjectInformationEntity> getWebapps1(String applicationName, String subAccount) {
		
		System.out.println(pRepo.fetchwebapps1(applicationName,subAccount));
        return pRepo.fetchwebapps1(applicationName,subAccount);

	}

	@Override
	public String getBuildStatus(String jobName, String stage) 
	{
		// TODO Auto-generated method stub
		String status = null;
		switch (stage) {
		case "CodeQuality":
			status=cRepo.getBuildStatus(jobName);
			break;
		case "Yasca":
			status=yRepo.getBuildStatus(jobName);	
			break;
		case "CheckMark":
			status=cmRepo.getBuildStatus(jobName);
			break;
		case "DeployCfJob":
			status=dcfRepo.getBuildStatus(jobName);
			break;
		case "Performance":
			status=perRepo.getBuildStatus(jobName);
			break;
		}
		
		return status;
	}
    
	 @Override
	    public double fetchYascaAverage(String applicationName) 
	    {
	     double result= 0.0;
	           if("ConnectedContainer".equals(applicationName)){
	        	   return  50.5;
	        			   
	           } else if("DigitalSeer".equals(applicationName)){
	        	   return  96.5;
	        	   
	           }else if("IDA".equals(applicationName)){
	        	   
	           }else if("FSM".equals(applicationName)){
	        	   return  90;
	        	   
	           }else if("SmartParking".equals(applicationName)){
	        	   return 81.33;
	           }
			return result;
		

	    }

	@Override
	public JSONArray getAllJobs(String applicationName) 
	{
		return jobRepo.getAllJobs(applicationName);
	
	}
	

	@Override
	public double getSonarAvgHealth(String applicationName) 
	{
		double jobHealth = 0;
		JSONArray jobNames =getAllJobs(applicationName);
		for (int i = 0; i <jobNames.size(); i++) {
			
		 jobHealth=cRepo.getSonarAvgHealth((String) jobNames.get(i));
		System.out.println("Job Healith "+jobHealth);
			
		}
	
		return jobHealth;
	}

	public String getCodeQualityAppHealth(String applicationName)
	{
		JSONArray jobNames = jobRepo.getAllJobs(applicationName);
		double finalJobHealth;
		double finalAvgAppHealth;
		double totalAppHealth = 0;
		
		int noOfJobs=jobNames.size();
		int count=0;
		
		String avgAppHealth;
		
		System.out.println("total Number of Jobs  "+noOfJobs);
		
		for (int i = 0; i < noOfJobs; i++) {
			
			//System.out.println(jobNames.get(i));
			String jobName=(String) jobNames.get(i);
			String jobHealth=cRepo.getSonarAvgHealth1(jobName);
			
			if(jobHealth!=null)
			{
				System.out.println("  JobName is  "+jobName);
				count++;
				finalJobHealth=Double.parseDouble(jobHealth);
				
				totalAppHealth=totalAppHealth+finalJobHealth;
				
				
				
				System.out.println("  JobName is  "+jobName+"  job Health is  "+finalJobHealth);
				
				System.out.println("total App Health is "+totalAppHealth);
				
			}
			
		
			
		}
		
		
		finalAvgAppHealth=((totalAppHealth/count));
		avgAppHealth=String.valueOf(Math.round(finalAvgAppHealth));
		
		System.out.println("Final Avg App Health is "+finalAvgAppHealth);
		return avgAppHealth;
		//return applicationName;
		
	}
	
	public String getYascaAppHealth(String applicationName)
	{
		JSONArray jobNames = jobRepo.getAllJobs(applicationName);
		double finalJobHealth;
		double finalAvgAppHealth;
		double totalAppHealth = 0;
		
		int noOfJobs=jobNames.size();
		int count=0;
		
		String avgAppHealth;
		
		System.out.println("total Number of Jobs  "+noOfJobs);
		
		for (int i = 0; i < noOfJobs; i++) {
			
			//System.out.println(jobNames.get(i));
			String jobName=(String) jobNames.get(i);
			String jobHealth=yRepo.getYascaAvgHealth(jobName);
			System.out.println("  jobHealth  "+jobHealth);
			
			if(jobHealth!=null)
			{
				System.out.println("  JobName is  "+jobName);
				count++;
				finalJobHealth=Double.parseDouble(jobHealth);
				
				totalAppHealth=totalAppHealth+finalJobHealth;
				
				
				
				System.out.println("  JobName is  "+jobName+"  job Health is  "+finalJobHealth);
				
				System.out.println("total App Health is "+totalAppHealth);
				
			}
			
		
			
		}
		
		
		finalAvgAppHealth=((totalAppHealth/count));
		avgAppHealth=String.valueOf(Math.round(finalAvgAppHealth));
		
		System.out.println("Final Avg App Health is "+finalAvgAppHealth);
		return avgAppHealth;
		//return applicationName;
		
	}
	
	
	public String getRegressionAppHealth(String applicationName)
	{
		JSONArray jobNames = jobRepo.getAllJobs(applicationName);
		double finalJobHealth;
		double finalAvgAppHealth;
		double totalAppHealth = 0;
		
		int noOfJobs=jobNames.size();
		int count=0;
		
		String avgAppHealth;
		
		System.out.println("total Number of Jobs  "+noOfJobs);
		
		for (int i = 0; i < noOfJobs; i++) {
			
			//System.out.println(jobNames.get(i));
			String jobName=(String) jobNames.get(i);
			String jobHealth=rRepo.getRegAvgHealth(jobName);
			
			if(jobHealth!=null)
			{
				System.out.println("  JobName is  "+jobName);
				count++;
				finalJobHealth=Double.parseDouble(jobHealth);
				
				totalAppHealth=totalAppHealth+finalJobHealth;
				
				
				
				System.out.println("  JobName is  "+jobName+"  job Health is  "+finalJobHealth);
				
				System.out.println("total App Health is "+totalAppHealth);
				
			}
			
		
			
		}
		
		
		finalAvgAppHealth=((totalAppHealth/count));
		avgAppHealth=String.valueOf(Math.round(finalAvgAppHealth));
		
		System.out.println("Final Avg App Health is "+finalAvgAppHealth);
		return avgAppHealth;
		//return applicationName;
		
	}
	
	
	@Override
	public JSONObject fetchApplicationHealth(String applicationName) 
	{
		
		JSONObject appHealth = new JSONObject();
		String codeQualityAppHealth=getCodeQualityAppHealth(applicationName);
		String yascaAppHealth=getYascaAppHealth(applicationName);
		String regressionAppHealth=getRegressionAppHealth(applicationName);
		/*pEntity=fetchPerformanceDetailsByAppName(applicationName);
		System.out.println("Performance  "+pEntity);*/
		String performanceAppHealth=fetchPerformanceDetailsByAppName(applicationName);
		System.out.println("Performance %"+performanceAppHealth);
		appHealth.put("codeQualityAppHealth",codeQualityAppHealth);
		appHealth.put("yascaAppHealth", yascaAppHealth);
		appHealth.put("regressionAppHealth", regressionAppHealth);
		appHealth.put("performanceAppHealth", performanceAppHealth);
		
		 if("ConnectedContainer".equals(applicationName)){
			 appHealth.put("junitAppHealth","50");
		     appHealth.put("regressionAppHealth", "100");
			 
      			   
         } else if("DigitalSeer".equals(applicationName)){
        	 appHealth.put("junitAppHealth","50");
        	 //appHealth.put("selenium", "86");
      	   
         }else if("IDA".equals(applicationName)){
        	 appHealth.put("junitAppHealth", "50");
         //appHealth.put("selenium", "NA");
         }else if("FSM".equals(applicationName)){
      	 
        	 appHealth.put("junitAppHealth","50");
        //appHealth.put("selenium", "100");
         }else if("SmartParking".equals(applicationName)){
        	 appHealth.put("junitAppHealth", "50");
        	 //appHealth.put("selenium", "100");
         }else if("BlockChain".equals(applicationName)){
        	 appHealth.put("junitAppHealth", "50");
        	 //appHealth.put("selenium", "In Progress");
         }else if("IDA".equals(applicationName)){
        	 appHealth.put("junitAppHealth", "50");
        	 //appHealth.put("selenium", "In Progress");
         }
		
		return appHealth;
		//return getYascaAppHealth(applicationName);
		
	}

	@Override
	public List<CodeQualityJobEntity> getCodeQualityApplicationDetails(String jobName) {
		// TODO Auto-generated method stub
		return cRepo.getDetailsByAppName(jobName);
	}
	
	@Override
	public List<YascaJobEntity> getYascaApplicationDetails(String jobName) {
		// TODO Auto-generated method stub
		return yRepo.getDetailsByAppName(jobName);
	}

	@Override
	public CodeQualityJobEntity fetchJunitDetails(String jobName) {
		
		 System.out.println("inside fetchJunitDetails ");
  	   CodeQualityJobEntity centity= new CodeQualityJobEntity();
         centity=cRepo.getDetailsByAppName1(jobName);
         
  	  
  	   
       double totalTestCases;
       double noOfPassTestCases;
       
       double avgHealth = 0;
       
       String appHealth = null;
       
       totalTestCases=Double.parseDouble(centity.getTotalTestCases());
       
       System.out.println("Total Test Cases :"+totalTestCases);
       
       noOfPassTestCases=Double.parseDouble(centity.getPassCount());
       
       System.out.println("Passes Test Cases :"+noOfPassTestCases);
      
       avgHealth=((noOfPassTestCases/totalTestCases)*100);
       
		if (avgHealth >= 80) {
			appHealth = "Good";
		} else if (avgHealth < 80 && avgHealth >30) {
			appHealth = "Need to be Resolved";
		} else if (avgHealth <= 30) {
			appHealth = "Risk";
		}
       
		 String finalAvgHealth = Double.toString(avgHealth);
     	 System.out.println(finalAvgHealth);
		centity.setJunitAvgHealth(finalAvgHealth);
        centity.setJunitAppHealth(appHealth);
        
        cRepo.save(centity);
        
        return centity;
	}
		
	@Override
	public RegressionJobEntity getRegAvgHealth(String jobName) {
	
		
		 System.out.println("inside fetchregDetails ");
		 RegressionJobEntity rentity= new RegressionJobEntity();
		 rentity=rRepo.getDetailsByAppName1(jobName);
         
  	  
  	   
       double totalTestCases;
       double noOfPassTestCases;
       
       double avgHealth = 0;
       
       String appHealth = null;
       
       totalTestCases=Double.parseDouble(rentity.getTotalTestCases());
       
       System.out.println("Total Test Cases :"+totalTestCases);
       
       noOfPassTestCases=Double.parseDouble(rentity.getRegressionPassCount());
       
       System.out.println("Passes Test Cases :"+noOfPassTestCases);
      
       avgHealth=((noOfPassTestCases/totalTestCases)*100);
       
		if (avgHealth >= 80) {
			appHealth = "Good";
		} else if (avgHealth < 80 && avgHealth >30) {
			appHealth = "Need to be Resolved";
		} else if (avgHealth <= 30) {
			appHealth = "Risk";
		}
        String finalAvgHealth = Double.toString(avgHealth);
     	 System.out.println(finalAvgHealth);
     	rentity.setRegAvgHealth(finalAvgHealth);
     	rentity.setAppHealth(appHealth);
     	
     	
     	 
       rRepo.save(rentity);
        
        return rentity;
		
	
		
		
	}

	@Override
	public PerformanceJobEntity fetchPerformanceDetails(String jobName) {
		System.out.println("inside fetchregDetails ");
		 PerformanceJobEntity pentity= new PerformanceJobEntity();
		 pentity=perRepo.getPerformanceDetails(jobName);
		return pentity;
	}

	@Override
	public String fetchPerformanceDetailsByAppName(String applicationName) {
		 String pen=perRepo.getPerformanceDetailsByAppName(applicationName);
			return pen;
	}
	
	public List<String> fetchProjectId() {
        List<String> idList = pRepo.fetchProjectID();
        return idList;
      
}

 @Override
 public List<String> fetchAppByProjId(String projectId) {
        List<String> appList = pRepo.fetchAppByProjId(projectId);
        return appList;
 }
  
 @Override
 public double fetchCompleteAppHealth(String applicationName) {
        JSONObject json=fetchApplicationHealth(applicationName);
        String codeQuality=(String) json.get("codeQualityAppHealth");
        String yasca=(String) json.get("yascaAppHealth");
        String regression=(String) json.get("regressionAppHealth");
        double codeQuality1 =Double.parseDouble(codeQuality);
        double yasca1 =Double.parseDouble(yasca);
        double regression1 =Double.parseDouble(regression);
        
        double completeAppHealth=((codeQuality1)+(yasca1)+(regression1));
        
        double avgCompleteHealth = Math.ceil(completeAppHealth/3);
        System.out.println("Code helth is  "+codeQuality+"  "+yasca+"  "+regression+"  "+avgCompleteHealth);
        return avgCompleteHealth;
 }

}

